package com.skhynix.builder;

public class TestConstant {
    public static String createApplicationUri = "/applications";
    public static String getMyApplicationUri = "/applications";
    public static String updateApplicationUri = "/applications/%s";
    public static String joinApplicationUri = "/application/users";
    public static String specificUserUri = "/application/users/%s";
    public static String setAuthorizationUri = "/authorizations";
    public static String getAuthorizationUri = "/authorizations/%s";
    public static String authorizationReqUri = "/authorizations/authorizationRequest";
    public static String authorizationReqAcceptUri = "/authorizations/authorizationRequest/accept";
    public static String authorizationReqDenyUri = "/authorizations/authorizationRequest/deny";
    public static String registerApplicationManager = "/application/managers";
    public static String createPageUri = "/pages";
    public static String pageCheckUri = "/pages/pageCheck";
}
