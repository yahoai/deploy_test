package com.skhynix.builder.scenario;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skhynix.builder.TestConstant;
import com.skhynix.builder.document.embedded.ApplicationManagerType;
import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.application.ApplicationManagerDTO;
import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqListDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqRespDTO;
import com.skhynix.builder.dto.common.ErrorResponse;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.page.*;
import com.skhynix.builder.dto.user.*;
import com.skhynix.builder.repository.mongo.*;
import com.skhynix.builder.util.TestUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@AutoConfigureMockMvc
@Slf4j
public class BaseTestController {
    @Autowired
    protected MockMvc mockMvc;
    @Autowired
    UserRepository userRepository;
    @Autowired
    ApplicationRepository applicationRepository;
    @Autowired
    AuthorizationRepository authorizationRepository;
    @Autowired
    ComponentRepository componentRepository;
    @Autowired
    DataStoreRepository dataStoreRepository;
    @Autowired
    FileUploadRepository fileUploadRepository;
    @Autowired
    PageRepository pageRepository;
    @Autowired
    ProductionPageRepository productionPageRepository;
    @Autowired
    ProtoTypeUserRepository protoTypeUserRepository;

    @BeforeAll
    static void setup () {

    }

    @BeforeEach
    @Transactional
    public void init() {
        userRepository.deleteAll();
        applicationRepository.deleteAll();
        authorizationRepository.deleteAll();
        componentRepository.deleteAll();
        dataStoreRepository.deleteAll();
        fileUploadRepository.deleteAll();
        pageRepository.deleteAll();
        productionPageRepository.deleteAll();
        protoTypeUserRepository.deleteAll();
    }

    @Test
    public void garbage() {

    }

    protected String generateNameFromIndex(int i) {
        return String.valueOf(i);
    }

    protected HashMap<String, Map<String, String>> createUser(int numberOfUser) {

        HashMap<String, Map<String, String>> createUserResult = new HashMap<>();
        IntStream.range(1, numberOfUser+1)
                .forEach(i -> {
                    try {
                        JoinProtoTypeUserRespDTO vo = new JoinProtoTypeUserRespDTO();
                        vo.setEmployeeNumber(String.valueOf(i));
                        vo.setName(String.valueOf(i));
                        ObjectMapper mapper = new ObjectMapper();
                        String body = TestUtil.convertObjectToString(vo);
                        MvcResult result = mockMvc.perform(
                                MockMvcRequestBuilders.post("/prototype/users/join")
                                        .content(body)
                                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                                .andDo(MockMvcResultHandlers.print())
                                .andExpect(MockMvcResultMatchers.status().isOk())
                                .andReturn();;
                        String tokenResponse = result.getResponse().getContentAsString();
                        SingleItemResponse<JoinProtoTypeUserRespDTO> response = TestUtil.convertStringToSingleItem(tokenResponse,
                                new TypeReference<SingleItemResponse<JoinProtoTypeUserRespDTO>>() {});
                        HashMap<String, String> userData = new HashMap<>();
                        userData.put("token", response.getData().getToken());
                        userData.put("id", response.getData().getId());
                        createUserResult.put(String.valueOf(i), userData);

                    } catch (Exception e) {

                    }
                });
        return createUserResult;
    }

    protected MvcResult executePost(String url, String body, String token, Map<String, String> params) throws Exception {
        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.post(url)
                .header("Authorization", "Bearer " + token)
                .content(body==null ? "": body)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .accept(MediaType.APPLICATION_JSON_VALUE);

        if(params != null) {
            params.keySet().stream()
                    .forEach(key -> {
                        builder.queryParam(key, params.get(key));
                    });
        }

        MvcResult result = mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
        return result;
    }

    protected MvcResult executeGet(String url, String token, Map<String, String> params) throws Exception {
        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get(url)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .accept(MediaType.APPLICATION_JSON_VALUE);

        if(token != null) {
            builder.header("Authorization", "Bearer " + token);
        }

        if(params != null) {
            params.keySet().stream()
                    .forEach(key -> {
                        builder.queryParam(key, params.get(key));
                    });
        }

        MvcResult result = mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
        return result;
    }

    protected MvcResult executePatch(String url, String body, String token, Map<String, String> params) throws Exception {
        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.patch(url)
                .header("Authorization", "Bearer " + token)
                .content(body==null ? "": body)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .accept(MediaType.APPLICATION_JSON_VALUE);

        if(params != null) {
            params.keySet().stream()
                    .forEach(key -> {
                        builder.queryParam(key, params.get(key));
                    });
        }

        MvcResult result = mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
        return result;
    }

    protected MvcResult executePut(String url, String body, String token, Map<String, String> params) throws Exception {
        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.put(url)
                .header("Authorization", "Bearer " + token)
                .content(body==null ? "": body)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .accept(MediaType.APPLICATION_JSON_VALUE);

        if(params != null) {
            params.keySet().stream()
                    .forEach(key -> {
                        builder.queryParam(key, params.get(key));
                    });
        }

        MvcResult result = mockMvc.perform(builder)
                .andDo(MockMvcResultHandlers.print())
                .andReturn();
        return result;
    }

    public ApplicationDTO createApplication(String uniqPath, String title, String token, int httpStatus) throws Exception {
        ApplicationDTO reqDTO = ApplicationDTO.builder().uniqPath(uniqPath).title(title).bassAppId("baseAppId")
                .frontData("frondData").customCss("customCss").description("application").build();

        String body = TestUtil.convertObjectToString(reqDTO);
        MvcResult result = executePost(TestConstant.createApplicationUri, body, token, null);

        assertEquals(httpStatus, result.getResponse().getStatus());
        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<ApplicationDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<ApplicationDTO>>() {});


        return response.getData();
    }

    public ErrorResponse createApplication4Error(String uniqPath, String title, String token, int httpStatus) throws Exception {
        ApplicationDTO reqDTO = ApplicationDTO.builder().uniqPath(uniqPath).title(title).bassAppId("baseAppId")
                .frontData("frondData").customCss("customCss").description("application").build();

        String body = TestUtil.convertObjectToString(reqDTO);
        MvcResult result = executePost(TestConstant.createApplicationUri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ErrorResponse response = TestUtil.convertStringToErrorResponse(responseStr, ErrorResponse.class);

        return response;
    }

    public List<ApplicationDTO> getMyApplication(String token, int httpStatus) throws Exception {
        MvcResult result = executeGet(TestConstant.getMyApplicationUri, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ListItemResponse<ApplicationDTO> response = TestUtil.convertStringToListItem(responseStr,
                new TypeReference<ListItemResponse<ApplicationDTO>>() {});

        return response.getData();
    }

    public ApplicationManagerDTO registerApplicationManager(String applicationId,
                                                            String userId,
                                                            ApplicationManagerType type,
                                                            String token, int httpStatus) throws Exception {
        AddApplicationManagerDTO request =
                AddApplicationManagerDTO.builder().applicationId(applicationId).protoTypeUserId(userId)
                        .type(type).build();

        String body = TestUtil.convertObjectToString(request);
        MvcResult result = executePost(TestConstant.registerApplicationManager, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<ApplicationManagerDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<ApplicationManagerDTO>>() {});

        return response.getData();
    }

    public ApplicationDTO patchApplication(String applicationId,
                                           Map<String, Object> applicationDTO,
                                           String token,
                                           int httpStatus) throws Exception {
        String uri = String.format(TestConstant.updateApplicationUri, applicationId);
        String body = TestUtil.convertObjectToString(applicationDTO);
        MvcResult result = executePatch(uri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<ApplicationDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<ApplicationDTO>>() {});

        return response.getData();
    }

    public ErrorResponse patchApplication4Error(String applicationId,
                                           Map<String, Object> applicationDTO,
                                           String token,
                                           int httpStatus) throws Exception {
        String uri = String.format(TestConstant.updateApplicationUri, applicationId);
        String body = TestUtil.convertObjectToString(applicationDTO);
        MvcResult result = executePatch(uri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ErrorResponse response = TestUtil.convertStringToErrorResponse(responseStr, ErrorResponse.class);

        return response;
    }

    public ApplicationDTO putApplication(String applicationId,
                                           Map<String, Object> applicationDTO,
                                           String token,
                                           int httpStatus) throws Exception {
        String uri = String.format(TestConstant.updateApplicationUri, applicationId);
        String body = TestUtil.convertObjectToString(applicationDTO);
        MvcResult result = executePut(uri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<ApplicationDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<ApplicationDTO>>() {});

        return response.getData();
    }

    public ErrorResponse putApplication4Error(String applicationId,
                                                Map<String, Object> applicationDTO,
                                                String token,
                                                int httpStatus) throws Exception {
        String uri = String.format(TestConstant.updateApplicationUri, applicationId);
        String body = TestUtil.convertObjectToString(applicationDTO);
        MvcResult result = executePut(uri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ErrorResponse response = TestUtil.convertStringToErrorResponse(responseStr, ErrorResponse.class);

        return response;
    }

    public JoinUserRespDTO applicationJoin(String applicationId, String employeeNumber,
                                           String name, String token, int httpStatus) throws Exception {
        UserDTO request = UserDTO.builder().applicationId(applicationId).employeeNumber(employeeNumber)
                .name(name).build();

        String body = TestUtil.convertObjectToString(request);
        MvcResult result = executePost(TestConstant.joinApplicationUri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<JoinUserRespDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<JoinUserRespDTO>>() {});

        return response.getData();
    }

    public List<UserRespDTO> getApplicationUsers(String applicationId, String token,
                                                 int httpStatus) throws Exception {
        Map<String, String> param = new HashMap<>();
        param.put("applicationId", applicationId);

        MvcResult result = executeGet(TestConstant.joinApplicationUri, token, param);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ListItemResponse<UserRespDTO> response = TestUtil.convertStringToListItem(responseStr,
                new TypeReference<ListItemResponse<UserRespDTO>>() {});

        return response.getData();
    }

    public List<AuthorizationDTO> setAuthorization(AuthorizationListDTO request,
                                                   String token,
                                                   int httpStatus) throws Exception {
        String body = TestUtil.convertObjectToString(request);
        MvcResult result = executePost(TestConstant.setAuthorizationUri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ListItemResponse<AuthorizationDTO> response = TestUtil.convertStringToListItem(responseStr,
                new TypeReference<ListItemResponse<AuthorizationDTO>>() {});

        return response.getData();
    }

    public List<AuthorizationDTO> getAuthorizationList(String applicationId,
                                                       String token,
                                                       int httpStatus) throws Exception {
        Map<String, String> param = new HashMap<>();
        param.put("applicationId", applicationId);

        MvcResult result = executeGet(TestConstant.setAuthorizationUri, token, param);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ListItemResponse<AuthorizationDTO> response = TestUtil.convertStringToListItem(responseStr,
                new TypeReference<ListItemResponse<AuthorizationDTO>>() {});

        return response.getData();
    }

    public AuthorizationDTO getAuthorization(String authorizationId,
                                                       String token,
                                                       int httpStatus) throws Exception {
        String uri = String.format(TestConstant.getAuthorizationUri, authorizationId);

        MvcResult result = executeGet(uri, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<AuthorizationDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<AuthorizationDTO>>() {});

        return response.getData();
    }

    public AuthorizationReqRespDTO authorizationRequest(AuthorizationReqDTO reqDTO,
                                                        String token,
                                                        int httpStatus) throws Exception {
        String body = TestUtil.convertObjectToString(reqDTO);
        MvcResult result = executePost(TestConstant.authorizationReqUri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<AuthorizationReqRespDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<AuthorizationReqRespDTO>>() {});

        return response.getData();
    }

    public List<AuthorizationReqRespDTO> getAuthorizationReqList(String applicationId,
                                                              String token,
                                                              int httpStatus) throws Exception {
        Map<String, String> param = new HashMap<>();
        param.put("applicationId", applicationId);
        MvcResult result = executeGet(TestConstant.authorizationReqUri,  token, param);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ListItemResponse<AuthorizationReqRespDTO> response = TestUtil.convertStringToListItem(responseStr,
                new TypeReference<ListItemResponse<AuthorizationReqRespDTO>>() {});

        return response.getData();
    }

    public void acceptAuthorizationReq(AuthorizationReqListDTO request,
                                       String token,
                                       int httpStatus) throws Exception {
        String body = TestUtil.convertObjectToString(request);
        MvcResult result = executePost(TestConstant.authorizationReqAcceptUri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());
    }

    public void denyAuthorizationReq(AuthorizationReqListDTO request,
                                       String token,
                                       int httpStatus) throws Exception {
        String body = TestUtil.convertObjectToString(request);
        MvcResult result = executePost(TestConstant.authorizationReqDenyUri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());
    }

    public PageRespDTO createDummyPage (String applicationId, String pageUrl,
                                        boolean allowAny, PageAuthorizationDTO authList,
                                        String token, int httpStatus) throws Exception {
        PageDTO page = PageDTO.builder()
                .applicationId(applicationId)
                .pageUrl(pageUrl)
                .authorizations(authList)
                .allowAnyUser(allowAny)
                .build();

        String body = TestUtil.convertObjectToString(page);

        MvcResult result = executePost(TestConstant.createPageUri, body, token, null);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<PageRespDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<PageRespDTO>>() {});

        return response.getData();
    }

    public PageCheckRespDTO pageCheck(String appUniqPath, String pageUrl,
                                      String token, int httpStatus) throws Exception {
        Map<String, String> param = new HashMap<>();
        param.put("applicationUniqPath", appUniqPath);
        param.put("pageUrl", pageUrl);
        param.put("target", "1");

        MvcResult result = executeGet(TestConstant.pageCheckUri, token, param);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<PageCheckRespDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<PageCheckRespDTO>>() {});

        return response.getData();
    }

    public ErrorResponse pageCheck4Error(String appUniqPath, String pageUrl,
                                      String token, int httpStatus) throws Exception {
        Map<String, String> param = new HashMap<>();
        param.put("applicationUniqPath", appUniqPath);
        param.put("pageUrl", pageUrl);
        param.put("target", "1");

        MvcResult result = executeGet(TestConstant.pageCheckUri, token, param);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        ErrorResponse response = TestUtil.convertStringToErrorResponse(responseStr,ErrorResponse.class);

        return response;
    }

    public UserRespDTO setUserAuth(String applicationId, String userId, List<String> authIdList,
                                   String token, int httpStatus) throws Exception {
        String uri = String.format(TestConstant.specificUserUri, userId);
        Map<String, String> param = new HashMap<>();
        param.put("applicationId", applicationId);

        Map<String, List<String>> patchUserBody = new HashMap<>();
        patchUserBody.put("authorizationIdList",authIdList);

        String body = TestUtil.convertObjectToString(patchUserBody);
        MvcResult result = executePatch(uri, body, token, param);
        assertEquals(httpStatus, result.getResponse().getStatus());

        String responseStr = result.getResponse().getContentAsString();
        SingleItemResponse<UserRespDTO> response = TestUtil.convertStringToSingleItem(responseStr,
                new TypeReference<SingleItemResponse<UserRespDTO>>() {});

        return response.getData();
    }
}
