package com.skhynix.builder.scenario;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.skhynix.builder.document.embedded.ApplicationManagerType;
import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.common.ErrorResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.util.TestUtil;
import com.sun.corba.se.spi.ior.ObjectKey;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ApplicationTest extends BaseTestController {
    @Test
    public void 어플리케이션_생성_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        assertNotNull(appResp);
        assertNotNull(appResp.getId());
        assertNotNull(appResp.getBassAppId());
        assertNotNull(appResp.getDescription());
        assertNotNull(appResp.getFrontData());
        assertNotNull(appResp.getCreatedAt());
        assertNotNull(appResp.getUpdatedAt());
        assertNotNull(appResp.getAllowPermission());
        assertNotNull(appResp.getUniqPath());
        assertNotNull(appResp.getTitle());
        assertNotNull(appResp.getOwner());
        assertEquals("1", appResp.getOwner().getEmployeeNumber());
        assertEquals("1", appResp.getOwner().getName());
    }

    @Test
    public void 중복_유니크_패스_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        ErrorResponse appResp2 = createApplication4Error("/app1", "app1", users.get("1").get("token"), 400);

        assertEquals(RCode.APPLICATION_UNIQ_PATH_EXIST.getResultCode(), appResp2.getErrorCode());
    }

    @Test
    public void 어플리케이션_목록_테스트_내가_만든_경우() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        ApplicationDTO appResp2 = createApplication("/app2", "app2", users.get("1").get("token"), 200);
        ApplicationDTO appResp3 = createApplication("/app3", "app3", users.get("1").get("token"), 200);
        ApplicationDTO appResp4 = createApplication("/app4", "app2", users.get("1").get("token"), 200);

        List<ApplicationDTO> response = getMyApplication(users.get("1").get("token"), 200);

        assertEquals(4, response.size());
    }

    @Test
    public void 어플리케이션_목록_테스트_내가_초대_된_경우() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        ApplicationDTO appResp2 = createApplication("/app2", "app2", users.get("1").get("token"), 200);
        ApplicationDTO appResp3 = createApplication("/app3", "app3", users.get("1").get("token"), 200);
        ApplicationDTO appResp4 = createApplication("/app4", "app2", users.get("1").get("token"), 200);

        List<ApplicationDTO> appListResponse = getMyApplication(users.get("1").get("token"), 200);

        assertEquals(4, appListResponse.size());

        registerApplicationManager(appResp.getId(), users.get("2").get("id"),
                ApplicationManagerType.MANAGER,users.get("1").get("token"), 200);

        registerApplicationManager(appResp2.getId(), users.get("2").get("id"),
                ApplicationManagerType.MANAGER,users.get("1").get("token"), 200);

        registerApplicationManager(appResp3.getId(), users.get("2").get("id"),
                ApplicationManagerType.MANAGER,users.get("1").get("token"), 200);

        appListResponse = getMyApplication(users.get("2").get("token"), 200);

        assertEquals(3, appListResponse.size());
    }

    @Test
    public void 어플리케이션_목록_테스트_내가_만든_것과_내가_초대_된_것() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        ApplicationDTO appResp2 = createApplication("/app2", "app2", users.get("1").get("token"), 200);
        ApplicationDTO appResp3 = createApplication("/app3", "app3", users.get("1").get("token"), 200);
        ApplicationDTO appResp4 = createApplication("/app4", "app2", users.get("1").get("token"), 200);

        List<ApplicationDTO> appListResponse = getMyApplication(users.get("1").get("token"), 200);

        assertEquals(4, appListResponse.size());

        ApplicationDTO appRes5 = createApplication("/app5", "app5", users.get("2").get("token"), 200);
        ApplicationDTO appResp6 = createApplication("/app6", "app6", users.get("2").get("token"), 200);
        ApplicationDTO appResp7 = createApplication("/app7", "app7", users.get("2").get("token"), 200);
        ApplicationDTO appResp8 = createApplication("/app8", "app8", users.get("2").get("token"), 200);

        List<ApplicationDTO> appListResponse2 = getMyApplication(users.get("2").get("token"), 200);

        assertEquals(4, appListResponse.size());

        registerApplicationManager(appResp.getId(), users.get("2").get("id"),
                ApplicationManagerType.MANAGER,users.get("1").get("token"), 200);

        registerApplicationManager(appResp2.getId(), users.get("2").get("id"),
                ApplicationManagerType.MANAGER,users.get("1").get("token"), 200);

        registerApplicationManager(appResp3.getId(), users.get("2").get("id"),
                ApplicationManagerType.MANAGER,users.get("1").get("token"), 200);

        appListResponse = getMyApplication(users.get("2").get("token"), 200);

        assertEquals(7, appListResponse.size());
    }

    @Test
    public void 어플리케이션_수정_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        Map<String, Object> request = new HashMap<>();
        request.put("uniqPath", "app1Modi");
        request.put("title", "titleModi");
        request.put("description", "descriptionModi");
        request.put("bassAppId", "bassAppIdModi");
        request.put("customCss", "customCssModi");
        request.put("frontData", "frontDataModi");
        request.put("allowPermission", false);

        ApplicationDTO response = patchApplication(appResp.getId(), request, users.get("1").get("token"), 200);

        assertEquals("app1Modi", response.getUniqPath());
        assertEquals("titleModi", response.getTitle());
        assertEquals("descriptionModi", response.getDescription());
        assertEquals("bassAppIdModi", response.getBassAppId());
        assertEquals("customCssModi", response.getCustomCss());
        assertEquals("frontDataModi", response.getFrontData());
        assertEquals(false, response.getAllowPermission());
    }

    @Test
    public void 어플리케이션_교체_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        Map<String, Object> request = new HashMap<>();
        request.put("uniqPath", "app1Modi");
        request.put("title", "titleModi");
        request.put("description", "descriptionModi");
        request.put("bassAppId", "bassAppIdModi");
        request.put("allowPermission", false);

        ApplicationDTO response = putApplication(appResp.getId(), request, users.get("1").get("token"), 200);
        assertEquals("app1Modi", response.getUniqPath());
        assertEquals("titleModi", response.getTitle());
        assertEquals("descriptionModi", response.getDescription());
        assertEquals("bassAppIdModi", response.getBassAppId());
        assertNull(response.getCustomCss());
        assertNull(response.getFrontData());
        assertEquals(false, response.getAllowPermission());
    }

    @Test
    public void 패치_어플리케이션_유니크_아이디_중복_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        ApplicationDTO appResp2 = createApplication("/app2", "app2", users.get("1").get("token"), 200);

        Map<String, Object> request = new HashMap<>();
        request.put("uniqPath", "/app2");

        ErrorResponse response = patchApplication4Error(appResp.getId(), request, users.get("1").get("token"), 400);
        assertEquals(RCode.APPLICATION_UNIQ_PATH_EXIST.getResultCode(), response.getErrorCode());
    }

    @Test
    public void 풋_어플리케이션_유니크_아이디_중복_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        ApplicationDTO appResp2 = createApplication("/app2", "app2", users.get("1").get("token"), 200);

        appResp.setUniqPath("/app2");

        Map<String, Object> request = new ObjectMapper()
                .readValue(TestUtil.convertObjectToString(appResp),
                        new TypeReference<Map<String, Object>>() {});
        ErrorResponse response = putApplication4Error(appResp.getId(), request, users.get("1").get("token"), 400);
        assertEquals(RCode.APPLICATION_UNIQ_PATH_EXIST.getResultCode(), response.getErrorCode());
    }
}
