package com.skhynix.builder.scenario;

import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import com.skhynix.builder.dto.common.ErrorResponse;
import com.skhynix.builder.dto.page.AuthorizationListDTO;
import com.skhynix.builder.dto.page.PageAuthorizationDTO;
import com.skhynix.builder.dto.page.PageCheckRespDTO;
import com.skhynix.builder.dto.page.PageRespDTO;
import com.skhynix.builder.dto.user.JoinUserRespDTO;
import com.skhynix.builder.dto.user.UserRespDTO;
import com.skhynix.builder.exception.RCode;
import lombok.var;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class PageCheckTest extends BaseTestController {

    @Test
    public void 비로그인_사용자_접속_허용_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        PageRespDTO page = createDummyPage(appResp.getId(), "/page1", true, null, users.get("1").get("token"), 200);

        PageCheckRespDTO pageResponse = pageCheck("/app1", "/page1",
                null, 200);
        assertNotNull(pageResponse);
        assertEquals(pageResponse.getId(), pageResponse.getId());
    }

    @Test
    public void 비로그인_사용자_접속_거절_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        PageRespDTO page = createDummyPage(appResp.getId(), "/page1", false, null, users.get("1").get("token"), 200);

        ErrorResponse pageResponse = pageCheck4Error("/app1", "/page1",
                null, 401);
        assertNotNull(pageResponse);
        assertEquals(pageResponse.getErrorCode(), RCode.UNAUTHORIZED.getResultCode());
    }

    @Test
    public void 없는_페이지_요청_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        //PageRespDTO page = createDummyPage(appResp.getId(), "/page1", false, users.get("1").get("token"), 200);

        ErrorResponse pageResponse = pageCheck4Error("/app1", "/page1",
                null, 400);
        assertNotNull(pageResponse);
        assertEquals(pageResponse.getErrorCode(), RCode.PAGE_NOT_FOUND.getResultCode());
    }

    @Test
    public void 모든_로그인_사용자_허용_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        PageRespDTO page = createDummyPage(appResp.getId(), "/page1", false, null, users.get("1").get("token"), 200);

        PageCheckRespDTO pageResponse = pageCheck("/app1", "/page1",
                users.get("1").get("token"), 200);
        assertNotNull(pageResponse);
        assertEquals(pageResponse.getId(), pageResponse.getId());
    }

    @Test
    public void 거절_목록_사용자_페이지_요청_거절_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1",  users.get("1").get("token"), 200);
        JoinUserRespDTO joinUserResponse = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        List<AuthorizationDTO> authList = new ArrayList();
        request.setAuthorizations(authList);
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        authList.add(auth1);

        List<AuthorizationDTO> response = setAuthorization(request, users.get("1").get("token"), 200);

        List<String> authIdList = new ArrayList<>();
        authIdList.add(response.get(0).getId());

        UserRespDTO userRespDTO = setUserAuth(appResp.getId(), joinUserResponse.getId(), authIdList, users.get("1").get("token"), 200);
        assertEquals(userRespDTO.getAuthorizations().size(), 1);
        assertEquals(userRespDTO.getAuthorizations().get(0).getId(), response.get(0).getId());

        HashSet<String> authSet = new HashSet<>();
        authSet.add(response.get(0).getId());
        PageAuthorizationDTO pageAuthList = PageAuthorizationDTO.builder()
                .deny(authSet).build();

        PageRespDTO page = createDummyPage(appResp.getId(), "/page1", false, pageAuthList, users.get("1").get("token"), 200);

        ErrorResponse pageResponse = pageCheck4Error("/app1", "/page1",
                null, 401);
        assertNotNull(pageResponse);
        assertEquals(pageResponse.getErrorCode(), RCode.UNAUTHORIZED.getResultCode());

    }

    @Test
    public void 허용_목록_사용자_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1",  users.get("1").get("token"), 200);
        JoinUserRespDTO joinUserResponse = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        List<AuthorizationDTO> authList = new ArrayList();
        request.setAuthorizations(authList);
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        authList.add(auth1);

        List<AuthorizationDTO> response = setAuthorization(request, users.get("1").get("token"), 200);

        List<String> authIdList = new ArrayList<>();
        authIdList.add(response.get(0).getId());

        UserRespDTO userRespDTO = setUserAuth(appResp.getId(), joinUserResponse.getId(), authIdList, users.get("1").get("token"), 200);
        assertEquals(userRespDTO.getAuthorizations().size(), 1);
        assertEquals(userRespDTO.getAuthorizations().get(0).getId(), response.get(0).getId());

        HashSet<String> authSet = new HashSet<>();
        authSet.add(response.get(0).getId());
        PageAuthorizationDTO pageAuthList = PageAuthorizationDTO.builder()
                .allow(authSet).build();

        PageRespDTO page = createDummyPage(appResp.getId(), "/page1", false, pageAuthList, users.get("1").get("token"), 200);

        PageCheckRespDTO pageResponse = pageCheck("/app1", "/page1",
                joinUserResponse.getToken(), 200);
        assertNotNull(pageResponse);
        assertEquals(pageResponse.getId(), pageResponse.getId());
    }
}
