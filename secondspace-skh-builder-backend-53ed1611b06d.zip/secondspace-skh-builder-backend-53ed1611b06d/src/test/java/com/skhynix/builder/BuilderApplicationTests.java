package com.skhynix.builder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@SpringBootTest
class BuilderApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    public void mapTest() {
        List<String> ddd = new ArrayList<>();
        ddd.add("a");
        ddd.add("b");
        ddd.add("c");

        ddd = ddd.stream().map(d -> {
            if("a".equals(d))
                return null;
            return d;
        }).filter(Objects::nonNull).collect(Collectors.toList());

        System.out.println(ddd);
    }

}
