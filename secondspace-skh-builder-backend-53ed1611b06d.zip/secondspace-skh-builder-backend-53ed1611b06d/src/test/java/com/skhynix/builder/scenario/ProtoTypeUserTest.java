package com.skhynix.builder.scenario;

public class ProtoTypeUserTest extends BaseTestController {

}
