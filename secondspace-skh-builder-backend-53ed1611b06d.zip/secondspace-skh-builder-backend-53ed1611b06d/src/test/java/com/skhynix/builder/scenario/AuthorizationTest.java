package com.skhynix.builder.scenario;

import com.skhynix.builder.TestConstant;
import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqListDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqRespDTO;
import com.skhynix.builder.dto.page.AuthorizationListDTO;
import com.skhynix.builder.dto.page.PageDTO;
import com.skhynix.builder.dto.page.PageRespDTO;
import com.skhynix.builder.dto.user.JoinUserRespDTO;
import com.skhynix.builder.util.TestUtil;
import lombok.var;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class AuthorizationTest extends BaseTestController {
    /*
    권한은 생성, 수정, 삭제가 별도로 존재하는 것이 아니라 하나의 API로 처리한다.
    */

    @Test
    public void 기본_권한_생성_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        var auth2 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth2").description("auth2 desc").fid("fid2").build();
        var auth3 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth3").description("auth3 desc").fid("fid3").build();
        var auth4 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth4").description("auth4 desc").fid("fid4").build();
        List<AuthorizationDTO> authList = new ArrayList();
        authList.add(auth1);
        authList.add(auth2);
        authList.add(auth3);
        authList.add(auth4);

        request.setAuthorizations(authList);

        List<AuthorizationDTO> response = setAuthorization(request, users.get("1").get("token"), 200);
        assertEquals(4, response.size());
    }

    @Test
    public void 권한_4개_생성_후_하나_업데이트_셋_교체() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        var auth2 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth2").description("auth2 desc").fid("fid2").build();
        var auth3 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth3").description("auth3 desc").fid("fid3").build();
        var auth4 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth4").description("auth4 desc").fid("fid4").build();
        List<AuthorizationDTO> authList = new ArrayList();
        authList.add(auth1);
        authList.add(auth2);
        authList.add(auth3);
        authList.add(auth4);

        request.setAuthorizations(authList);

        List<AuthorizationDTO> response = setAuthorization(request, users.get("1").get("token"), 200);
        assertEquals(4, response.size());

        //Id를 입력하면 업데이트가 된다.
        List<AuthorizationDTO> updateRequestList = new ArrayList<>();
        var auth5 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth5").description("auth5 desc").fid("fid4").build();
        updateRequestList.add(response.get(0));
        updateRequestList.add(response.get(1));
        updateRequestList.add(response.get(2));
        //새롭게 추가
        updateRequestList.add(auth5);

        response.get(0).setName("auth1Modi");
        response.get(1).setName("auth2Modi");
        response.get(2).setName("auth3Modi");

        request.setAuthorizations(updateRequestList);

        List<AuthorizationDTO> updateResult = setAuthorization(request, users.get("1").get("token"), 200);

        List<AuthorizationDTO> response2 = setAuthorization(request, users.get("1").get("token"), 200);

        boolean existAuth4 = response2.stream().anyMatch(m -> response.get(3).getId().equals(m.getId()));
        assertFalse(existAuth4);

        boolean existAuth1 = response2.stream()
                .anyMatch(m -> response.get(0).getId().equals(m.getId()) && "auth1Modi".equals(m.getName()));
        assertTrue(existAuth1);
        boolean existAuth2 = response2.stream()
                .anyMatch(m -> response.get(1).getId().equals(m.getId()) && "auth2Modi".equals(m.getName()));
        assertTrue(existAuth2);
        boolean existAuth3 = response2.stream()
                .anyMatch(m -> response.get(2).getId().equals(m.getId()) && "auth3Modi".equals(m.getName()));
        assertTrue(existAuth3);
    }

    @Test
    public void 권한_목록_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        var auth2 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth2").description("auth2 desc").fid("fid2").build();
        var auth3 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth3").description("auth3 desc").fid("fid3").build();
        var auth4 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth4").description("auth4 desc").fid("fid4").build();
        List<AuthorizationDTO> authList = new ArrayList();
        authList.add(auth1);
        authList.add(auth2);
        authList.add(auth3);
        authList.add(auth4);

        request.setAuthorizations(authList);

        setAuthorization(request, users.get("1").get("token"), 200);
        List<AuthorizationDTO> response = getAuthorizationList(appResp.getId(), users.get("1").get("token"), 200);
        assertEquals(4, response.size());

        boolean existAuth1 = response.stream()
                .anyMatch(m -> response.get(0).getId().equals(m.getId()) && "auth1".equals(m.getName()));
        assertTrue(existAuth1);
        boolean existAuth2 = response.stream()
                .anyMatch(m -> response.get(1).getId().equals(m.getId()) && "auth2".equals(m.getName()));
        assertTrue(existAuth2);
        boolean existAuth3 = response.stream()
                .anyMatch(m -> response.get(2).getId().equals(m.getId()) && "auth3".equals(m.getName()));
        assertTrue(existAuth3);
        boolean existAuth4 = response.stream()
                .anyMatch(m -> response.get(3).getId().equals(m.getId()) && "auth4".equals(m.getName()));
        assertTrue(existAuth4);
    }

    @Test
    public void 권한_겟_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        var auth2 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth2").description("auth2 desc").fid("fid2").build();
        var auth3 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth3").description("auth3 desc").fid("fid3").build();
        var auth4 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth4").description("auth4 desc").fid("fid4").build();
        List<AuthorizationDTO> authList = new ArrayList();
        authList.add(auth1);
        authList.add(auth2);
        authList.add(auth3);
        authList.add(auth4);

        request.setAuthorizations(authList);

        List<AuthorizationDTO> setAuthResponse = setAuthorization(request, users.get("1").get("token"), 200);
        AuthorizationDTO response = getAuthorization(setAuthResponse.get(0).getId(), users.get("1").get("token"), 200);
        assertEquals(setAuthResponse.get(0).getId(), response.getId());
        assertEquals(setAuthResponse.get(0).getName(), response.getName());
        assertEquals(setAuthResponse.get(0).getFid(), response.getFid());
        assertEquals(setAuthResponse.get(0).getDescription(), response.getDescription());
        assertEquals(setAuthResponse.get(0).getFid(), response.getFid());
    }

    @Test
    public void 어플리케이션_유저_권한_요청_생성_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);
        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        JoinUserRespDTO user1 = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);
        /*JoinUserRespDTO user2 = applicationJoin(appResp.getId(), "aaaab", "aaaab",
                users.get("1").get("token"), 200);
        JoinUserRespDTO user3 = applicationJoin(appResp.getId(), "aaaac", "aaaac",
                users.get("1").get("token"), 200);
        JoinUserRespDTO user4 = applicationJoin(appResp.getId(), "aaaad", "aaaad",
                users.get("1").get("token"), 200);*/

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        var auth2 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth2").description("auth2 desc").fid("fid2").build();
        var auth3 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth3").description("auth3 desc").fid("fid3").build();
        var auth4 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth4").description("auth4 desc").fid("fid4").build();

        List<AuthorizationDTO> authList = new ArrayList<>();
        authList.add(auth1);
        authList.add(auth2);
        authList.add(auth3);
        authList.add(auth4);
       request.setAuthorizations(authList);

        List<AuthorizationDTO> setAuthResponse = setAuthorization(request, users.get("1").get("token"), 200);

        AuthorizationReqDTO authReq1 = AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .applicationUserId(user1.getId())
                .authorizationId(setAuthResponse.get(0).getId()).build();

        AuthorizationReqRespDTO authReqResp = authorizationRequest(authReq1, users.get("1").get("token"), 200 );
        assertEquals(authReqResp.getApplicationId(), auth1.getApplicationId());
        assertEquals(authReqResp.getAuthorization().getId(), setAuthResponse.get(0).getId());
        assertEquals(authReqResp.getApplicationUser().getId(), user1.getId());

    }

    @Test
    public void 어플리케이션_유저_권한_요청_목록_조회_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);
        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        JoinUserRespDTO user1 = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);
        JoinUserRespDTO user2 = applicationJoin(appResp.getId(), "aaaab", "aaaab",
                users.get("1").get("token"), 200);
        JoinUserRespDTO user3 = applicationJoin(appResp.getId(), "aaaac", "aaaac",
                users.get("1").get("token"), 200);
        JoinUserRespDTO user4 = applicationJoin(appResp.getId(), "aaaad", "aaaad",
                users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        var auth2 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth2").description("auth2 desc").fid("fid1").build();
        var auth3 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth3").description("auth3 desc").fid("fid1").build();
        var auth4 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth4").description("auth4 desc").fid("fid1").build();
        List<AuthorizationDTO> authList = new ArrayList();
        authList.add(auth1);
        authList.add(auth2);
        authList.add(auth3);
        authList.add(auth4);


        request.setAuthorizations(authList);

        List<AuthorizationDTO> setAuthResponse = setAuthorization(request, users.get("1").get("token"), 200);

        AuthorizationReqDTO authReq1 = AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .applicationUserId(user1.getId())
                .authorizationId(setAuthResponse.get(0).getId()).build();

        AuthorizationReqDTO authReq2 = AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .applicationUserId(user2.getId())
                .authorizationId(setAuthResponse.get(1).getId()).build();

        AuthorizationReqDTO authReq3 = AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .applicationUserId(user3.getId())
                .authorizationId(setAuthResponse.get(2).getId()).build();

        AuthorizationReqDTO authReq4 = AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .applicationUserId(user4.getId())
                .authorizationId(setAuthResponse.get(3).getId()).build();

        AuthorizationReqRespDTO authReqResp1 = authorizationRequest(authReq1, users.get("1").get("token"), 200 );
        AuthorizationReqRespDTO authReqResp2 = authorizationRequest(authReq2, users.get("1").get("token"), 200 );
        AuthorizationReqRespDTO authReqResp3 = authorizationRequest(authReq3, users.get("1").get("token"), 200 );
        AuthorizationReqRespDTO authReqResp4 = authorizationRequest(authReq4, users.get("1").get("token"), 200 );

        List<AuthorizationReqRespDTO> authListResp = getAuthorizationReqList(appResp.getId(), users.get("1").get("token"), 200);
        assertEquals(4, authListResp.size());
    }

    @Test
    public void 권한_수락_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);
        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        JoinUserRespDTO user1 = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        List<AuthorizationDTO> authList = new ArrayList();
        request.setAuthorizations(authList);
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        authList.add(auth1);

        List<AuthorizationDTO> setAuthResponse = setAuthorization(request, users.get("1").get("token"), 200);

        AuthorizationReqDTO authReq1 = AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .applicationUserId(user1.getId())
                .authorizationId(setAuthResponse.get(0).getId()).build();

        AuthorizationReqRespDTO authReqResp1 = authorizationRequest(authReq1, users.get("1").get("token"), 200 );

        AuthorizationReqListDTO authAcceptReq = new AuthorizationReqListDTO();
        List<AuthorizationReqDTO> authAcceptReqList = new ArrayList<>();
        authAcceptReq.setAuthorizationReqs(authAcceptReqList);

        authAcceptReqList.add(AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .authorizationId(setAuthResponse.get(0).getId())
                .applicationUserId(user1.getId()).build());

        acceptAuthorizationReq(authAcceptReq, users.get("1").get("token"), 200);

        user1 = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);

        assertNotNull(user1.getAuthorizations());
        assertEquals(1, user1.getAuthorizations().size());
        assertEquals("auth1", user1.getAuthorizations().get(0).getName());
        assertEquals("fid1", user1.getAuthorizations().get(0).getFid());

        List<AuthorizationReqRespDTO> authListResp = getAuthorizationReqList(appResp.getId(), users.get("1").get("token"), 200);
        assertEquals(0, authListResp.size());
    }

    @Test
    public void 권한_거절_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(1);
        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);

        JoinUserRespDTO user1 = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);

        AuthorizationListDTO request = new AuthorizationListDTO();
        request.setApplicationId(appResp.getId());
        List<AuthorizationDTO> authList = new ArrayList();
        request.setAuthorizations(authList);
        var auth1 = AuthorizationDTO.builder().applicationId(appResp.getId())
                .name("auth1").description("auth1 desc").fid("fid1").build();
        authList.add(auth1);

        List<AuthorizationDTO> setAuthResponse = setAuthorization(request, users.get("1").get("token"), 200);

        AuthorizationReqDTO authReq1 = AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .applicationUserId(user1.getId())
                .authorizationId(setAuthResponse.get(0).getId()).build();

        AuthorizationReqRespDTO authReqResp1 = authorizationRequest(authReq1, users.get("1").get("token"), 200 );

        List<AuthorizationReqRespDTO> authListResp = getAuthorizationReqList(appResp.getId(), users.get("1").get("token"), 200);
        assertEquals(1, authListResp.size());

        AuthorizationReqListDTO authDenyReq = new AuthorizationReqListDTO();
        List<AuthorizationReqDTO> authAcceptReqList = new ArrayList<>();
        authDenyReq.setAuthorizationReqs(authAcceptReqList);

        authAcceptReqList.add(AuthorizationReqDTO.builder()
                .applicationId(appResp.getId())
                .authorizationId(setAuthResponse.get(0).getId())
                .applicationUserId(user1.getId()).build());

        denyAuthorizationReq(authDenyReq, users.get("1").get("token"), 200);

        authListResp = getAuthorizationReqList(appResp.getId(), users.get("1").get("token"), 200);
        assertEquals(0, authListResp.size());
    }
}
