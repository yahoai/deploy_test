package com.skhynix.builder.scenario;

import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.user.JoinUserRespDTO;
import com.skhynix.builder.dto.user.UserRespDTO;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ApplicationUserTest extends BaseTestController {
    @Test
    public void 어플리케이션_가입_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        JoinUserRespDTO response = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);


        List<UserRespDTO> userListResp = getApplicationUsers(appResp.getId(), users.get("1").get("token"), 200);
        assertEquals(1, userListResp.size());
        assertEquals(response.getId(), userListResp.get(0).getId());
        assertEquals(response.getApplicationId(), appResp.getId());
        assertEquals(response.getEmployeeNumber(), response.getEmployeeNumber());
        assertEquals(response.getName(), response.getName());
    }

    @Test
    public void 어플리케이션_가입자_조회_테스트() throws Exception {
        Map<String, Map<String, String>> users = createUser(2);

        ApplicationDTO appResp = createApplication("/app1", "app1", users.get("1").get("token"), 200);
        JoinUserRespDTO response1 = applicationJoin(appResp.getId(), "aaaaa", "aaaaa",
                users.get("1").get("token"), 200);
        JoinUserRespDTO response2 = applicationJoin(appResp.getId(), "aaaab", "baaaa",
                users.get("1").get("token"), 200);
        JoinUserRespDTO response3 = applicationJoin(appResp.getId(), "aaaac", "caaaa",
                users.get("1").get("token"), 200);
        JoinUserRespDTO response4 = applicationJoin(appResp.getId(), "aaaad", "daaaa",
                users.get("1").get("token"), 200);
        JoinUserRespDTO response5 = applicationJoin(appResp.getId(), "aaaae", "eaaaa",
                users.get("1").get("token"), 200);

        List<UserRespDTO> userListResp = getApplicationUsers(appResp.getId(), users.get("1").get("token"), 200);
        assertEquals(5, userListResp.size());
    }
}
