package com.skhynix.builder.dto.component;

import com.skhynix.builder.dto.validator.DocumentId;
import lombok.Data;

@Data
public class ComponentInfoDTO {
    private String i;
    @DocumentId
    private String id;
}
