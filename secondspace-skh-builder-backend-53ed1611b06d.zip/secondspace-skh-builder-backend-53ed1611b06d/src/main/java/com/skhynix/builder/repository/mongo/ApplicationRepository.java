package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.Application;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ApplicationRepository extends MongoRepository<Application, String> {
    List<Application> findByTitleContaining(String title);
    Application findByUniqPath(String uniqPath);
}
