package com.skhynix.builder.service;

import com.skhynix.builder.document.*;
import com.skhynix.builder.document.embedded.AuthUpdateActionType;
import com.skhynix.builder.dto.authorization.AuthorizationReqListDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqRespDTO;
import com.skhynix.builder.dto.authorization.AuthorizationReqDTO;
import com.skhynix.builder.dto.page.AuthorizationListDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.repository.mongo.*;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AuthorizationRequestService {
    private AuthorizationRequestRepository authorizationRequestRepository;
    private ApplicationRepository applicationRepository;
    private AuthorizationRepository authorizationRepository;
    private UserRepository userRepository;
    private AuthorizationHistoryRepository authorizationHistoryRepository;

    @Autowired
    public void setAuthorizationHistoryRepository(AuthorizationHistoryRepository authorizationHistoryRepository) {
        this.authorizationHistoryRepository = authorizationHistoryRepository;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Autowired
    public void setAuthorizationRequestRepository(AuthorizationRequestRepository authorizationRequestRepository) {
        this.authorizationRequestRepository = authorizationRequestRepository;
    }

    public AuthorizationReqRespDTO createAuthRequest(AuthorizationReqDTO authReqDTO) {
        try {
            AuthorizationRequest existAuthReq = authorizationRequestRepository
                    .findByApplicationIdAndApplicationUserIdAndAuthorizationId(
                            new ObjectId(authReqDTO.getApplicationId()),
                            new ObjectId(authReqDTO.getApplicationUserId()),
                            new ObjectId(authReqDTO.getAuthorizationId())
                    );

            User user = userRepository.findById(authReqDTO.getApplicationUserId())
                    .orElseThrow(() -> new BuilderException(RCode.USER_NOT_EXISTS, authReqDTO.getApplicationUserId()));
            if(!authReqDTO.getApplicationId().equals(user.getApplicationId().toString()))
                throw new BuilderException(RCode.USER_NOT_EXISTS, authReqDTO.getApplicationUserId());

            Application app = applicationRepository.findById(authReqDTO.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, authReqDTO.getApplicationId()));

            Authorization auth = authorizationRepository.findById(authReqDTO.getAuthorizationId())
                    .orElseThrow(() -> new BuilderException(RCode.AUTHORIZATION_NOT_FOUND, authReqDTO.getAuthorizationId()));
            if(!auth.getAllowAuthRequest())
                throw new BuilderException(RCode.CAN_NOT_REQUEST_AUTH);

            if(auth.getNeedReason() && authReqDTO.getReason() == null) {
                throw new BuilderException(RCode.PARAMETER_REQUIRED, "reason");
            }
            if(!authReqDTO.getApplicationId().equals(auth.getApplicationId().toString()))
                throw new BuilderException(RCode.USER_NOT_EXISTS, authReqDTO.getApplicationUserId());

            AuthorizationRequest authReq;
            if(existAuthReq != null) {
                authReq = existAuthReq;
            } else {
                authReq = AuthorizationRequest.of(authReqDTO);
                authReq = authorizationRequestRepository.save(authReq);
            }

            Application application =  applicationRepository.findById(authReqDTO.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND,
                            authReqDTO.getApplicationId()));
            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            try {
                AuthorizationHistory ah = new AuthorizationHistory();
                ah.setApplicationId(user.getApplicationId());
                ah.setApplicationUserId(new ObjectId(user.getId()));
                ah.setActionType(AuthUpdateActionType.request);
                ah.setRequestAuthorizationName(auth.getName());
                ah.setUpdatedAt(System.currentTimeMillis());

                authorizationHistoryRepository.save(ah);
            } catch (Exception e) {

            }

            return AuthorizationReqRespDTO.of(authReq.getId(),
                    authReqDTO.getApplicationId(),
                    user,
                    auth,
                    authReq.getCreatedAt());

        } catch (BuilderException e ) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<AuthorizationReqRespDTO> getAuthorizationReqList(String applicationId) throws BuilderException {
        try {
            List<AuthorizationRequest> authReqList =
                    authorizationRequestRepository.findAllByApplicationIdOrderByIdDesc(new ObjectId(applicationId));

            return authReqList.stream()
                    .map(ar -> {
                        User user = userRepository.findById(ar.getApplicationUserId().toString())
                                .orElse(null);
                        if(user == null) {
                            authorizationRequestRepository.delete(ar);
                            return null;
                        }

                        Application app = applicationRepository.findById(ar.getApplicationId().toString())
                                .orElse(null);
                        if(app == null) {
                            authorizationRequestRepository.delete(ar);
                            return null;
                        }

                        Authorization auth = authorizationRepository.findById(ar.getAuthorizationId().toString())
                                .orElse(null);
                        if(auth == null) {
                            authorizationRequestRepository.delete(ar);
                            return null;
                        }

                        return AuthorizationReqRespDTO.of(ar.getId(), applicationId, user, auth, ar.getCreatedAt());
                    }).filter(Objects::nonNull).collect(Collectors.toList());
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void acceptAuthorizationRequest(AuthorizationReqListDTO authReqDTOList) throws BuilderException {
        try {
            for(AuthorizationReqDTO authReqDTO : authReqDTOList.getAuthorizationReqs()) {
                AuthorizationRequest existAuthReq = authorizationRequestRepository
                        .findByApplicationIdAndApplicationUserIdAndAuthorizationId(
                                new ObjectId(authReqDTO.getApplicationId()),
                                new ObjectId(authReqDTO.getApplicationUserId()),
                                new ObjectId(authReqDTO.getAuthorizationId())
                        );

                if (existAuthReq == null) {
                    throw new BuilderException(RCode.AUTHORIZATION_REQ_NOT_FOUND);
                }

                User user = userRepository.findById(authReqDTO.getApplicationUserId())
                        .orElseThrow(() -> new BuilderException(RCode.USER_NOT_EXISTS, authReqDTO.getApplicationUserId()));
                if (!authReqDTO.getApplicationId().equals(user.getApplicationId().toString()))
                    throw new BuilderException(RCode.USER_NOT_EXISTS, authReqDTO.getApplicationUserId());

                Application app = applicationRepository.findById(authReqDTO.getApplicationId())
                        .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, authReqDTO.getApplicationId()));

                Authorization auth = authorizationRepository.findById(authReqDTO.getAuthorizationId())
                        .orElseThrow(() -> new BuilderException(RCode.AUTHORIZATION_NOT_FOUND, authReqDTO.getAuthorizationId()));
                if (!authReqDTO.getApplicationId().equals(auth.getApplicationId().toString()))
                    throw new BuilderException(RCode.USER_NOT_EXISTS, authReqDTO.getApplicationUserId());

                Set<ObjectId> authIdList = user.getAuthorizations();
                if (authIdList == null) {
                    authIdList = new HashSet<>();
                    user.setAuthorizations(authIdList);
                }

                authIdList.add(new ObjectId(authReqDTO.getAuthorizationId()));


                app.setUpdatedAt(System.currentTimeMillis());
                applicationRepository.save(app);

                userRepository.save(user);
                authorizationRequestRepository.delete(existAuthReq);

                try {
                    AuthorizationHistory ah = new AuthorizationHistory();
                    ah.setApplicationId(user.getApplicationId());
                    ah.setApplicationUserId(new ObjectId(user.getId()));
                    ah.setActionType(AuthUpdateActionType.accept);
                    ah.setAcceptAuthorizationName(auth.getName());
                    ah.setUpdatedAt(System.currentTimeMillis());

                    authorizationHistoryRepository.save(ah);
                } catch (Exception e) {

                }
            }
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void denyAuthorizationRequest(AuthorizationReqListDTO authReqListDTO) {
        try {
            for (AuthorizationReqDTO authReqDTO : authReqListDTO.getAuthorizationReqs()) {
                User user = userRepository.findById(authReqDTO.getApplicationUserId()).orElse(null);

                AuthorizationRequest existAuthReq = authorizationRequestRepository
                        .findByApplicationIdAndApplicationUserIdAndAuthorizationId(
                                new ObjectId(authReqDTO.getApplicationId()),
                                new ObjectId(authReqDTO.getApplicationUserId()),
                                new ObjectId(authReqDTO.getAuthorizationId())
                        );

                Authorization auth = authorizationRepository.findById(authReqDTO.getAuthorizationId()).orElse(null);

                if(user != null && existAuthReq != null && auth != null) {
                    try {
                        AuthorizationHistory ah = new AuthorizationHistory();
                        ah.setApplicationId(user.getApplicationId());
                        ah.setApplicationUserId(new ObjectId(user.getId()));
                        ah.setActionType(AuthUpdateActionType.deny);
                        ah.setDenyAuthorizationName(auth.getName());
                        ah.setUpdatedAt(System.currentTimeMillis());

                        authorizationHistoryRepository.save(ah);
                    } catch (Exception e) {

                    }
                }

                if (existAuthReq != null) {
                    authorizationRequestRepository.delete(existAuthReq);
                }


            }
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
