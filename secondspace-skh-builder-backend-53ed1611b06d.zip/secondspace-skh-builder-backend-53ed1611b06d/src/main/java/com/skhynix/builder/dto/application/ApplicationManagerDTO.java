package com.skhynix.builder.dto.application;

import com.skhynix.builder.document.ProtoTypeUser;
import com.skhynix.builder.document.embedded.ApplicationManagerType;
import com.skhynix.builder.document.embedded.ApplicationMember;
import com.skhynix.builder.dto.user.ProtoTypeUserSummaryDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApplicationManagerDTO {
    private ProtoTypeUserSummaryDTO userInfo;
    private ApplicationManagerType applicationManagerType;
    private Long createdAt;

    public static ApplicationManagerDTO of(ApplicationMember member, ProtoTypeUser user) {
        return ApplicationManagerDTO.builder()
                .userInfo(ProtoTypeUserSummaryDTO.of(user))
                .applicationManagerType(member.getApplicationManagerType())
                .createdAt(member.getCreatedAt())
                .build();
    }
}
