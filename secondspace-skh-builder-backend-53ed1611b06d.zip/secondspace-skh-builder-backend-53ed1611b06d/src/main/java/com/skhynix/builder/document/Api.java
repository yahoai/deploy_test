package com.skhynix.builder.document;

import com.skhynix.builder.document.embedded.ApiType;
import com.skhynix.builder.dto.api.ApiDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

@Document("api")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Api {
    @Id
    private String id;
    @Indexed
    private ObjectId applicationId;
    private String apiName;
    private Object type;
    private Object sendData;
    private Object filter;
    private Object sort;
    private String connectStoreData;
    private Object method;
    private String key;
    private String componentName;
    private String documentType;
    private Long createdAt;
    private Long updatedAt;

    public static Api of(ApiDTO apiDTO) {
        return Api.builder()
                .applicationId(new ObjectId(apiDTO.getApplicationId()))
                .apiName(apiDTO.getApiName())
                .type(apiDTO.getType())
                .sendData(apiDTO.getSendData())
                .filter(apiDTO.getFilter())
                .sort(apiDTO.getSort())
                .method(apiDTO.getMethod())
                .key(apiDTO.getKey())
                .documentType(apiDTO.getDocumentType())
                .componentName(apiDTO.getComponentName())
                .connectStoreData(apiDTO.getConnectStoreData())
                .build();
    }
}
