package com.skhynix.builder.dto.application;

import com.skhynix.builder.document.embedded.ApplicationManagerType;
import com.skhynix.builder.dto.validator.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JoinApplicationDTO {
    @NotNull
    @DocumentId
    private String protoTypeUserId;
    private ApplicationManagerType applicationManagerType;
}
