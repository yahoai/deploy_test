package com.skhynix.builder.dto.authorization;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.User;
import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.user.SimpleUserDTO;
import com.skhynix.builder.dto.user.UserDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthorizationReqRespDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    private String applicationId;
    private AuthorizationDTO authorization;
    private SimpleUserDTO applicationUser;
    private String placeHolder;
    private String title;
    private String reason;
    private Long createdAt;


    public static AuthorizationReqRespDTO of(String id, String applicationId,
                                             User user, Authorization auth,
                                             Long createdAt) {
        return AuthorizationReqRespDTO.builder()
                .id(id)
                .applicationId(applicationId)
                .applicationUser(SimpleUserDTO.of(user))
                .authorization(AuthorizationDTO.of(auth))
                .createdAt(createdAt)
                .build();
    }
}
