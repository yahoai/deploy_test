package com.skhynix.builder.dto.component;

import com.skhynix.builder.document.embedded.ComponentInfo;
import lombok.Data;
import org.openapitools.jackson.nullable.JsonNullable;

import javax.validation.Valid;
import java.util.List;
@Data
public class ComponentPatchDTO {
    private JsonNullable<String> title;
    private JsonNullable<String> description;
    private JsonNullable<List<String>> tags;
    private JsonNullable<String> componentName;
    private JsonNullable<Object> componentData;
    private JsonNullable<Integer> componentType;
    private JsonNullable<Object> componentConditionAction;
    private JsonNullable<Object> componentEvent;
    private JsonNullable<Object> builderLayouts;
    private JsonNullable<Object> childLayoutsList;
    private JsonNullable<@Valid ComponentInfoDTO> componentInfo;
    private JsonNullable<Object> options;
}
