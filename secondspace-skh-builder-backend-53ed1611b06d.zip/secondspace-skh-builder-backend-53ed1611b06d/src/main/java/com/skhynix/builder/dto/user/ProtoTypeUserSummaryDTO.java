package com.skhynix.builder.dto.user;

import com.skhynix.builder.document.ProtoTypeUser;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProtoTypeUserSummaryDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    @NotNull
    private String employeeNumber;
    private String name;
    private String organization;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    @ApiModelProperty(readOnly = true)
    private Long updatedAt;

    public static ProtoTypeUserSummaryDTO of(ProtoTypeUser u) {

        return ProtoTypeUserSummaryDTO.builder()
                .id(u.getId())
                .employeeNumber(u.getUserUniqId())
                .name(u.getName())
                .createdAt(u.getCreatedAt())
                .updatedAt(u.getUpdatedAt() != null ? u.getUpdatedAt() : u.getCreatedAt())
                .build();
    }

}