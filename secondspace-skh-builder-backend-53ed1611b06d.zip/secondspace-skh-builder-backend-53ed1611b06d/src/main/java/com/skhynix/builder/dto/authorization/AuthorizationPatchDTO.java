package com.skhynix.builder.dto.authorization;

import com.skhynix.builder.dto.validator.DocumentId;
import lombok.Data;
import org.openapitools.jackson.nullable.JsonNullable;

import javax.validation.Valid;

@Data
public class AuthorizationPatchDTO {
    private JsonNullable<String> name;
    private JsonNullable<String> fid;
    private JsonNullable<@Valid @DocumentId String> description;
}
