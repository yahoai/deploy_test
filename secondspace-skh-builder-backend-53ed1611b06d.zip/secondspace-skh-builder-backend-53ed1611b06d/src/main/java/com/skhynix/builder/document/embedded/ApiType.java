package com.skhynix.builder.document.embedded;

public enum ApiType {
    legacy,
    mongo
}
