package com.skhynix.builder.document.embedded;

public enum AuthUpdateActionType {
    update,
    request,
    accept,
    deny
}
