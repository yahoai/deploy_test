package com.skhynix.builder.document;

import com.skhynix.builder.dto.authorization.AuthorizationReqDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

@Document("authorization_request")
@Data
@CompoundIndex(def = "{'applicationId':1, 'applicationUserId':1, 'authorizationId':1}", unique = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AuthorizationRequest {
    @Id
    private String id;
    @Indexed
    private ObjectId applicationId;
    private ObjectId applicationUserId;
    private String reason;
    @Indexed
    private ObjectId authorizationId;
    private Long createdAt;

    public static AuthorizationRequest of(AuthorizationReqDTO dto) {
        return AuthorizationRequest.builder()
                .applicationId(new ObjectId(dto.getApplicationId()))
                .applicationUserId(new ObjectId(dto.getApplicationUserId()))
                .authorizationId(new ObjectId(dto.getAuthorizationId()))
                .reason(dto.getReason())
                .createdAt(System.currentTimeMillis())
                .build();
    }
}
