package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.Page;
import com.skhynix.builder.document.embedded.ComponentInfo;
import com.skhynix.builder.document.embedded.PageAuthorization;
import com.skhynix.builder.dto.component.ComponentInfoDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.ReadOnlyProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.stream.Collectors;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PageDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    private String title;
    private String description;
    private Object componentData;
    private Object componentConditionAction;
    private Object componentEvent;
    private Object builderLayouts;
    private Object childLayoutsList;
    @NotNull
    @DocumentId
    private String applicationId;
    private String applicationTitle;
    private String applicationUniqPath;
    private String pageUrl;
    private String masterPage;
    @ApiModelProperty(readOnly = true)
    private Long updatedAt;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    @ApiModelProperty(readOnly = true)
    private Long publishedAt;
    private PageAuthorizationDTO authorizations;
    @Valid
    private ComponentInfoDTO componentInfo;
    private Object pageParam;
    private Boolean allowAnyUser;
    private Object options;
    private Object frontData;
    private List<PageApiDTO> apiList;

    public static PageDTO of(Page p) {
        ComponentInfoDTO componentInfoDTO = new ComponentInfoDTO();

        if(p.getComponentInfo() != null) {
            componentInfoDTO.setI(p.getComponentInfo().getI());
            componentInfoDTO.setId(p.getComponentInfo().getId() != null ?
                    p.getComponentInfo().getId().toString() : null);
        }
        return PageDTO.builder()
                .id(p.getId())
                .title(p.getTitle())
                .description(p.getDescription())
                .componentData(p.getComponentData())
                .componentConditionAction(p.getComponentConditionAction())
                .componentEvent(p.getComponentEvent())
                .builderLayouts(p.getBuilderLayouts())
                .childLayoutsList(p.getChildLayoutsList())
                .applicationId(p.getApplicationId() != null ? p.getApplicationId().toString() : null)
                .applicationTitle(p.getApplicationTitle())
                .applicationUniqPath(p.getApplicationUniqPath())
                .pageUrl(p.getPageUrl())
                .componentInfo(componentInfoDTO)
                .pageParam(p.getPageParam())
                .updatedAt(p.getUpdatedAt())
                .createdAt(p.getCreatedAt())
                .authorizations(PageAuthorizationDTO.of(p.getAuthorizations()))
                .allowAnyUser(p.getAllowAnyUser())
                .masterPage(p.getMasterPage() != null ? p.getMasterPage().toString() : null)
                .options(p.getOptions())
                .apiList(p.getApiList() == null || p.getApiList().size() == 0 ? null
                        : p.getApiList().stream().map(
                                api -> new PageApiDTO(api.getApiId().toString(), api.getData()))
                        .collect(Collectors.toList()))
                .frontData(p.getFrontData())
                .build();
    }
}
