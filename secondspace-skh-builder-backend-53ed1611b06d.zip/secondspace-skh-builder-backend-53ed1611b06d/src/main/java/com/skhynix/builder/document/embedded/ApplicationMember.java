package com.skhynix.builder.document.embedded;

import lombok.Data;
import org.bson.types.ObjectId;

@Data
public class ApplicationMember {
    //ProtoTypeUserId
    private ObjectId userId;
    private ApplicationManagerType applicationManagerType;
    private Long createdAt;
}
