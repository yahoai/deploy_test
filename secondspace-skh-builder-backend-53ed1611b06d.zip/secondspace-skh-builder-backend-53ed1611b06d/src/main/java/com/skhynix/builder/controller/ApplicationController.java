package com.skhynix.builder.controller;

import com.skhynix.builder.auth.CurrentUser;
import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.dto.application.JoinApplicationDTO;
import com.skhynix.builder.dto.common.EmptyResponse;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.application.ApplicationDetailDTO;
import com.skhynix.builder.dto.application.ApplicationPatchDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.ApplicationService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/applications")
@Slf4j
@Validated
public class ApplicationController extends BuilderExceptionHandler {
    private ApplicationService applicationService;

    @Autowired
    public void setApplicationService(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @PostMapping
    @ApiOperation(value = "createApplication", notes = "어플리케이션을 생성합니다. owner는 readOnly입니다.")
    public ResponseEntity<SingleItemResponse<ApplicationDTO>> createApplication(
            @CurrentUser UserPrincipal currentUser,
            @RequestBody @Valid ApplicationDTO applicationDTO) throws BuilderException {

        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", applicationDTO.toString());
        ApplicationDTO response = applicationService.createApplication(currentUser, applicationDTO);
        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @GetMapping
    public ResponseEntity<ListItemResponse<ApplicationDTO>> getMyApplication(
            @CurrentUser UserPrincipal currentUser) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", "");

        List<ApplicationDTO> response = applicationService.getApplications(currentUser);
        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @PatchMapping("/{applicationId}")
    public ResponseEntity<SingleItemResponse<ApplicationDTO>> patchApplication(
            @CurrentUser UserPrincipal currentUser,
            @PathVariable @DocumentId String applicationId,
            @RequestBody ApplicationPatchDTO applicationPatchDTO) throws BuilderException {

        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", applicationPatchDTO.toString());

        ApplicationDTO response = applicationService.patchApplication(applicationId,applicationPatchDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @GetMapping("/{applicationId}")
    public ResponseEntity<SingleItemResponse<ApplicationDetailDTO>> getApplication(
            @CurrentUser UserPrincipal currentUser,
            @PathVariable @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        ApplicationDetailDTO response = applicationService.getApplication(applicationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PutMapping("/{applicationId}")
    public ResponseEntity<SingleItemResponse<ApplicationDTO>> replaceApplication(
            @PathVariable @DocumentId String applicationId,
            @RequestBody @Valid ApplicationDTO applicationDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, applicationDTO.toString());

        ApplicationDTO response = applicationService.replaceApplication(applicationId, applicationDTO);
        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    public ResponseEntity<EmptyResponse> joinApplicationManager(
            @PathVariable @DocumentId String applicationId,
            @RequestBody JoinApplicationDTO joinApplicationDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, joinApplicationDTO.toString());

        applicationService.joinApplicationManager(applicationId, joinApplicationDTO);
        return ResponseEntity.ok(EmptyResponse.create());
    }


    @DeleteMapping("/{applicationId}")
    public ResponseEntity<EmptyResponse> deleteService(
            @PathVariable @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");
        applicationService.deleteApplication(applicationId);
        return ResponseEntity.ok(EmptyResponse.create());
    }
}
