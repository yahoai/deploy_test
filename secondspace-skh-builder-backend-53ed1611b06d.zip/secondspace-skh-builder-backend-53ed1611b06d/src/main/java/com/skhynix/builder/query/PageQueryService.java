package com.skhynix.builder.query;

import com.skhynix.builder.document.*;
import com.skhynix.builder.dto.page.PageDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.repository.mongo.PageRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.FindAndReplaceOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.core.query.UpdateDefinition;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Service
public class PageQueryService {
    private MongoTemplate mongoTemplate;
    private PageRepository pageRepository;

    @Autowired
    public void setPageRepository(PageRepository pageRepository) {
        this.pageRepository = pageRepository;
    }

    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public List<Page> getPages(String applicationId,
                               String title,
                               String applicationTitle,
                               String applicationUniqPath,
                               String pageUrl,
                               String componentId) throws BuilderException {
        Query query = new Query();

        Criteria criteria = null;

        if(title != null) {
            criteria = Criteria.where("title").is(title);
        }

        if(applicationId != null) {
            if(criteria == null) {
                criteria = Criteria.where("applicationId").is(new ObjectId(applicationId));
            } else {
                criteria = criteria.and("applicationId").is(new ObjectId(applicationId));
            }
        }

        if(applicationTitle != null) {
            if(criteria == null) {
                criteria = Criteria.where("applicationTitle").is(applicationTitle);
            } else {
                criteria = criteria.and("applicationTitle").is(applicationTitle);
            }
        }

        if(applicationUniqPath != null) {
            if(criteria == null) {
                criteria = Criteria.where("applicationUniqPath").is(applicationUniqPath);
            } else {
                criteria = criteria.and("applicationUniqPath").is(applicationUniqPath);
            }
        }

        if(pageUrl != null) {
            if(criteria == null) {
                criteria = Criteria.where("pageUrl").is(pageUrl);
            } else {
                criteria = criteria.and("pageUrl").in(pageUrl);
            }
        }

        if(componentId != null) {
            if(criteria == null) {
                criteria = Criteria.where("componentInfo.id").is(new ObjectId(componentId));
            } else {
                criteria = criteria.and("componentInfo.id").is(new ObjectId(componentId));
            }
        }

        if(criteria != null) {
            query.addCriteria(criteria);
            return mongoTemplate.find(query, Page.class);
        } else {
            return mongoTemplate.findAll(Page.class);
        }
    }

    public Page replacePage(String pageId, Page page) {
        Query query = new Query();

        Criteria criteria = Criteria.where("id").is(pageId);
        query.addCriteria(criteria);

        mongoTemplate.findAndReplace(query, page);
        Page result = mongoTemplate.findOne(query, Page.class);

        return result;
    }

    public ProductionPage replaceProductionPage(String pageId, ProductionPage productionPage) {
        Query query = new Query();

        Criteria criteria = Criteria.where("id").is(pageId);
        query.addCriteria(criteria);
        FindAndReplaceOptions options = new FindAndReplaceOptions().upsert().returnNew();


        ProductionPage newPage = mongoTemplate.findAndReplace(query, productionPage, options);

        return newPage;
    }

    @Transactional
    public void replaceAllPage(String applicationId) {
        ObjectId applicationObjId = new ObjectId(applicationId);
        BulkOperations bulkOperations4Prd = mongoTemplate.bulkOps(BulkOperations.BulkMode.ORDERED, ProductionPage.class);
        List<Page> allPage = pageRepository.findByApplicationId(applicationObjId);

        boolean shouldBeExecuted = false;
        long curr = System.currentTimeMillis();

        for(Page page : allPage) {
            ProductionPage pp = ProductionPage.of(page);
            Query query = new Query();

            Criteria criteria = Criteria.where("id").is(page.getId());
            query.addCriteria(criteria);
            pp.setPublishedAt(curr);
            FindAndReplaceOptions options = new FindAndReplaceOptions().upsert().returnNew();

            bulkOperations4Prd.replaceOne(query, pp, options);
            shouldBeExecuted = true;
        }

        if(shouldBeExecuted) bulkOperations4Prd.execute();


        Query query = new Query();

        Criteria criteria = Criteria.where("applicationId").is(applicationObjId);
        query.addCriteria(criteria);
        Update update = new Update();

        update.set("publishedAt", curr);
        mongoTemplate.updateMulti(query, update, Page.class);
    }

}
