package com.skhynix.builder.query;

import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.DataStore;
import com.skhynix.builder.document.User;
import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import com.skhynix.builder.dto.datastore.DataStoreDTO;
import com.skhynix.builder.dto.page.AuthorizationListDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.repository.mongo.AuthorizationRepository;
import com.skhynix.builder.repository.mongo.UserRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.BulkOperationException;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserQueryService {
    private MongoTemplate mongoTemplate;
    private UserRepository userRepository;
    private AuthorizationRepository authorizationRepository;

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void removeAuthorization(String applicationId, List<String> authIdList) {
        Query query = new Query();
        Criteria criteria = Criteria.where("applicationId").is(new ObjectId(applicationId));
        query.addCriteria(criteria);
        mongoTemplate.updateMulti(query,
                new Update().pull("authorizations", authIdList.stream().map(ObjectId::new).toArray()), User.class);
    }

    @Transactional
    public int bulkWriteAuthorization(AuthorizationListDTO authListDto) throws BuilderException {
        try {
            boolean authShouldBeExecuted = false;
            boolean userShouldBeExecuted = false;
            ObjectId appObjectId = new ObjectId(authListDto.getApplicationId());

            BulkOperations userBulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.ORDERED, User.class);
            BulkOperations authBulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.ORDERED, Authorization.class);


            //널이 뒬 수 없음. 왜냐하면 스트림이니까.
            List<String> currentAuthIdList = authorizationRepository.findAllByApplicationId(appObjectId)
                    .stream().map(Authorization::getId).collect(Collectors.toList());


            List<String> updatedAuthIdList = authListDto.getAuthorizations() != null ?
                    authListDto.getAuthorizations().stream().map(AuthorizationDTO::getId)
                    .filter(Objects::nonNull).collect(Collectors.toList()) : new ArrayList<>();

            Collection<String> toBeRemoved = CollectionUtils.subtract(currentAuthIdList, updatedAuthIdList);
            List<String> toBeRemovedList = new ArrayList<>(toBeRemoved);

            if(toBeRemovedList.size() != 0) {
                Query query = new Query();
                Criteria criteria = Criteria.where("id").in(toBeRemovedList);
                query.addCriteria(criteria);
                authBulkOperations.remove(query);
                authShouldBeExecuted = true;
            }


            if(authListDto.getAuthorizations() != null) {
                for(AuthorizationDTO dto : authListDto.getAuthorizations()) {
                    if(dto.getId() != null) {
                        Authorization authorization = authorizationRepository.findById(dto.getId())
                                .orElseThrow(() -> new BuilderException(RCode.AUTHORIZATION_NOT_FOUND, dto.getId()));
                        Query query = new Query();

                        Criteria criteria = Criteria.where("id").is(dto.getId());
                        Update update = new Update()
                                .set("applicationId", appObjectId)
                                .set("name", dto.getName())
                                .set("fid", dto.getFid())
                                .set("description", dto.getDescription());
                        query.addCriteria(criteria);
                        authBulkOperations.updateOne(query, update);
                        authShouldBeExecuted = true;
                    } else {
                        Authorization authorization = Authorization.of(dto);
                        authBulkOperations.insert(authorization);
                        authShouldBeExecuted = true;
                    }
                }
            }
            if(toBeRemovedList.size() != 0) {
                Query query = new Query();
                Criteria criteria = Criteria.where("applicationId").is(appObjectId);
                query.addCriteria(criteria);
                Object[] objs = toBeRemovedList.stream().map(ObjectId::new).toArray();
                userBulkOperations.updateMulti(query,
                        new Update().pullAll("authorizations", objs));
                userShouldBeExecuted = true;

            }

            if(authShouldBeExecuted) authBulkOperations.execute();
            if(userShouldBeExecuted) userBulkOperations.execute();

            return 0;
        } catch (BulkOperationException e) {
            throw new BuilderException(RCode.DATA_STORE_KEY_EXIST, e);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
