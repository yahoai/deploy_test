package com.skhynix.builder.document;

import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import javax.validation.constraints.Email;
import java.util.List;

@Document("authorization")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Authorization {
    @Id
    private String id;
    @Indexed
    private ObjectId applicationId;
    private String name;
    private String fid;
    private String description;
    private Boolean needReason;
    private Boolean allowAuthRequest;
    private String title;
    private String placeHolder;

    public static Authorization of(AuthorizationDTO dto) {
        ObjectId applicationId = new ObjectId(dto.getApplicationId());
        return Authorization.builder()
                .name(dto.getName())
                .applicationId(applicationId)
                .description(dto.getDescription())
                .fid(dto.getFid())
                .allowAuthRequest(dto.getAllowAuthRequest() == null || dto.getAllowAuthRequest())
                .needReason(dto.getNeedReason() != null && dto.getNeedReason())
                .title(dto.getTitle())
                .placeHolder(dto.getPlaceHolder())
                .build();
    }
}
