package com.skhynix.builder.service;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.DataStore;
import com.skhynix.builder.dto.datastore.DataStoreDTO;
import com.skhynix.builder.dto.datastore.DataStoreListDTO;
import com.skhynix.builder.dto.datastore.DataStorePatchDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.query.DataStoreQueryService;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.repository.mongo.DataStoreRepository;
import com.skhynix.builder.util.CommonUtil;
import org.bson.types.ObjectId;
import org.openapitools.jackson.nullable.JsonNullable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DataStoreService {
    private DataStoreQueryService dataStoreQueryService;
    private DataStoreRepository dataStoreRepository;
    private ApplicationRepository applicationRepository;

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Autowired
    public void setDataStoreRepository(DataStoreRepository dataStoreRepository) {
        this.dataStoreRepository = dataStoreRepository;
    }

    @Autowired
    public void setDataStoreQueryService(DataStoreQueryService dataStoreQueryService) {
        this.dataStoreQueryService = dataStoreQueryService;
    }

    public List<DataStoreDTO> setDataStore(DataStoreListDTO dto) throws BuilderException {
        try {
            Application application = applicationRepository.findById(dto.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, dto.getApplicationId()));

            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            dataStoreQueryService.bulkWriteDataStore4Upsert(dto.getApplicationId(), dto.getDataStoreDTOList());
            return dataStoreRepository.findAllByApplicationId(new ObjectId(dto.getApplicationId()))
                    .stream()
                    .map(DataStoreDTO::of)
                    .collect(Collectors.toList());

        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.DATA_STORE_KEY_EXIST, e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<DataStoreDTO> getDataStoreList(String applicationId) {
        try {
            return dataStoreRepository.findAllByApplicationId(new ObjectId(applicationId))
                    .stream()
                    .map(DataStoreDTO::of)
                    .collect(Collectors.toList());

        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.DATA_STORE_KEY_EXIST, e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<DataStoreDTO> createDataStore(DataStoreListDTO dataStoreListDTO) throws BuilderException {
        try {
            return dataStoreQueryService.bulkWriteDataStore4Create(dataStoreListDTO.getApplicationId(), dataStoreListDTO.getDataStoreDTOList())
                    .stream().map(DataStoreDTO::of).collect(Collectors.toList());
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void deleteDataStore(List<String> dataStoreIdList) throws BuilderException {
        try {
            List<ObjectId> dataStoreObjectIdList = dataStoreIdList.stream().map(ObjectId::new).collect(Collectors.toList());

            dataStoreRepository.deleteAllByIdIn(dataStoreObjectIdList);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public DataStoreDTO replaceDataStore(String dataStoreId, DataStoreDTO dataStoreDTO) throws BuilderException {
        try {
            DataStore previousDs = dataStoreRepository.findById(dataStoreId)
                    .orElseThrow(() -> new BuilderException(RCode.DATA_STORE_NOT_EXIST, dataStoreId));
            DataStore ds = DataStore.of(previousDs.getApplicationId().toString(), dataStoreDTO);

            return DataStoreDTO.of(dataStoreQueryService.replaceDataStore(dataStoreId, ds));
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public DataStoreDTO pathDataStore(String dataStoreId,
                                      DataStorePatchDTO dataStorePatchDTO) throws BuilderException {
        try {
            DataStore dataStore = dataStoreRepository.findById(dataStoreId)
                    .orElseThrow(() -> new BuilderException(RCode.DATA_STORE_NOT_EXIST, dataStoreId));

            CommonUtil.changeIfPresent(dataStorePatchDTO.getKeyName(), dataStore::setKeyName);
            CommonUtil.changeIfPresent(dataStorePatchDTO.getName(), dataStore::setName);
            CommonUtil.changeIfPresent(dataStorePatchDTO.getClassName(), dataStore::setClassName);
            CommonUtil.changeIfPresent(dataStorePatchDTO.getUse(), dataStore::setUse);
            CommonUtil.changeIfPresent(dataStorePatchDTO.getFid(), dataStore::setFid);
            CommonUtil.changeIfPresent(dataStorePatchDTO.getEdit(), dataStore::setEdit);

            return DataStoreDTO.of(dataStoreRepository.save(dataStore));

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
