package com.skhynix.builder.document.embedded;

import com.skhynix.builder.dto.api.ApiDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageApi {
    ObjectId apiId;
    Object data;
}
