package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.*;
import com.skhynix.builder.dto.api.ApiDTO;
import com.skhynix.builder.dto.component.ComponentInfoDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageCheckRespDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    private String title;
    private Object componentData;
    private Object componentConditionAction;
    private Object componentEvent;
    private Object builderLayouts;
    private Object childLayoutsList;
    private String applicationId;
    private String applicationTitle;
    private String applicationUniqPath;
    private String pageUrl;
    private MasterPageDTO masterPage;
    private ComponentInfoDTO componentInfo;
    private Object pageParam;
    private Boolean allowAnyUser;
    private Object options;
    private Object frontData;
    private List<PageApiRespDTO> apiList;

    public static PageCheckRespDTO of(Page p, MasterPage mp, List<PageApiRespDTO> apiList) {
        ComponentInfoDTO componentInfoDTO = new ComponentInfoDTO();

        if(p.getComponentInfo() != null) {
            componentInfoDTO.setI(p.getComponentInfo().getI());
            componentInfoDTO.setId(p.getComponentInfo().getId() != null ?
                    p.getComponentInfo().getId().toString() : null);
        }
        return PageCheckRespDTO.builder()
                .id(p.getId())
                .title(p.getTitle())
                .componentData(p.getComponentData())
                .componentConditionAction(p.getComponentConditionAction())
                .componentEvent(p.getComponentEvent())
                .builderLayouts(p.getBuilderLayouts())
                .childLayoutsList(p.getChildLayoutsList())
                .applicationId(p.getApplicationId() != null ? p.getApplicationId().toString() : null)
                .applicationTitle(p.getApplicationTitle())
                .applicationUniqPath(p.getApplicationUniqPath())
                .pageUrl(p.getPageUrl())
                .componentInfo(componentInfoDTO)
                .pageParam(p.getPageParam())
                .allowAnyUser(p.getAllowAnyUser())
                .masterPage(mp == null ? null : MasterPageDTO.of(mp, p.getApplicationId().toString()))
                .options(p.getOptions())
                .frontData(p.getFrontData())
                .apiList(apiList)
                .build();
    }

    public static PageCheckRespDTO of(ProductionPage p, MasterPage mp, List<PageApiRespDTO> apiList) {
        ComponentInfoDTO componentInfoDTO = new ComponentInfoDTO();

        if(p.getComponentInfo() != null) {
            componentInfoDTO.setI(p.getComponentInfo().getI());
            componentInfoDTO.setId(p.getComponentInfo().getId() != null ?
                    p.getComponentInfo().getId().toString() : null);
        }
        return PageCheckRespDTO.builder()
                .id(p.getId())
                .title(p.getTitle())
                .componentData(p.getComponentData())
                .componentConditionAction(p.getComponentConditionAction())
                .componentEvent(p.getComponentEvent())
                .builderLayouts(p.getBuilderLayouts())
                .childLayoutsList(p.getChildLayoutsList())
                .applicationId(p.getApplicationId() != null ? p.getApplicationId().toString() : null)
                .applicationTitle(p.getApplicationTitle())
                .applicationUniqPath(p.getApplicationUniqPath())
                .pageUrl(p.getPageUrl())
                .componentInfo(componentInfoDTO)
                .pageParam(p.getPageParam())
                .masterPage(mp == null ? null : MasterPageDTO.of(mp, p.getApplicationId().toString()))
                .options(p.getOptions())
                .frontData(p.getFrontData())
                .apiList(apiList)
                .build();
    }

}
