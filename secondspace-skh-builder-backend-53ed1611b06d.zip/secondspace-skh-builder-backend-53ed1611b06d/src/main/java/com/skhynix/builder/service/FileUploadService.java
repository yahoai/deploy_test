package com.skhynix.builder.service;

import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.FileUpload;
import com.skhynix.builder.dto.file.FileDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.repository.mongo.FileUploadRepository;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
@Slf4j
public class FileUploadService {
    private ApplicationRepository applicationRepository;
    private FileUploadRepository fileUploadRepository;

    @Autowired
    public void setFileRepository(FileUploadRepository fileUploadRepository) {
        this.fileUploadRepository = fileUploadRepository;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Value("${upload.path}")
    private String uploadPath;

    private String makeFileFullPath(String fileName) {
        return uploadPath+fileName;
    }

    private String makeFilePathForAPI(String fileName) {
        return "/files/"+fileName;
    }
    private String makeFilePath(String applicationId, String fileId, String originFileName) {
        StringBuilder path = new StringBuilder();

        return path
                .append(applicationId)
                .append("_")
                .append(fileId)
                .append("_")
                .append(originFileName)
                .toString();
    }

    public FileDTO uploadFile(String applicationId, MultipartFile file) {
        try {
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, applicationId));

            FileUpload fileUpload = new FileUpload();

            fileUpload.setApplicationId(new ObjectId(applicationId));
            fileUpload.setCreatedAt(System.currentTimeMillis());

            fileUploadRepository.save(fileUpload);

            String fileName = makeFilePath(applicationId, fileUpload.getId(), file.getOriginalFilename());
            String fileFullPath = makeFileFullPath(fileName);
            file.transferTo(new File(fileFullPath));
            Path path = new File(file.getOriginalFilename()).toPath();

            File storedFile = new File(fileName);
            URLConnection connection = storedFile.toURL().openConnection();
            String mimeType = connection.getContentType();

            fileUpload.setFilePath(makeFilePathForAPI(fileName));
            fileUpload.setMimeType(mimeType);
            fileUploadRepository.save(fileUpload);

            log.info("mimeType  = {}", mimeType);
            return FileDTO.of((fileUpload));

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }

    }
    private String getAppIdFromFileName(String fileName) {
        String[] result = fileName.split("_");

        return result[0];
    }

    private String getFileIdFromFileName(String fileName) {
        String[] result = fileName.split("_");

        return result[1];
    }

    public ResponseEntity<Resource> getFile(UserPrincipal currentUser, String fileName) {
        try {
            String applicationId = getAppIdFromFileName(fileName);
            String fileId = getFileIdFromFileName(fileName);
            String fileFullPath = makeFileFullPath(fileName);

            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, applicationId));

            FileUpload fileDocument = fileUploadRepository.findById(fileId)
                    .orElseThrow(() -> new BuilderException(RCode.FILE_NOT_FOUND, fileName));

            File file = new File(fileFullPath);

            InputStream is = new FileInputStream(file);

            return ResponseEntity.ok()
                    .contentType(MediaType
                            .parseMediaType(fileDocument.getMimeType()))
                    .body(new InputStreamResource(is));
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
