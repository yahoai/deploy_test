package com.skhynix.builder.dto.user;

import com.skhynix.builder.document.User;
import com.skhynix.builder.dto.validator.DocumentId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    @NotNull
    @DocumentId
    private String applicationId;
    @NotNull
    private String employeeNumber;
    private String name;
    private Set<@DocumentId String> authorizations;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    @ApiModelProperty(readOnly = true)
    private Long updatedAt;

    public static UserDTO of(User u) {
        Set<String> authorizations = null;
        if(u.getAuthorizations() != null) {
            authorizations = u.getAuthorizations().stream()
                    .map(ObjectId::toString).collect(Collectors.toSet());
        }
        return UserDTO.builder()
                .id(u.getId())
                .employeeNumber(u.getUserUniqId())
                .name(u.getName())
                .authorizations(authorizations)
                .applicationId(u.getApplicationId().toString())
                .createdAt(u.getCreatedAt())
                .updatedAt(u.getUpdatedAt() != null ? u.getUpdatedAt() : u.getCreatedAt())
                .build();
    }
}
