package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.embedded.Footer;
import com.skhynix.builder.document.embedded.Menu;

import com.skhynix.builder.dto.validator.DocumentId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.openapitools.jackson.nullable.JsonNullable;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MasterPagePatchDTO {
    @NotNull
    @DocumentId
    private String applicationId;
    private JsonNullable<Boolean> isDefault;
    private JsonNullable<String> title;
    private JsonNullable<String> desc;
    private JsonNullable<Boolean> usePermission;
    private JsonNullable<Object> header;
    private JsonNullable<Object> design;
    private JsonNullable<Footer> footer;
    private JsonNullable<Menu> menu;
    private JsonNullable<Object> frontData;
}
