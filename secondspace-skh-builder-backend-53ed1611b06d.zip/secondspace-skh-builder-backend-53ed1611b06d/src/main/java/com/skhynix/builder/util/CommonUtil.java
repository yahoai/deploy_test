package com.skhynix.builder.util;

import org.openapitools.jackson.nullable.JsonNullable;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.function.Consumer;

public class CommonUtil {
    public static <T> void patchDtoToEntity(Map<String, Object> dto, T target, Class<T> cls) {
        dto.forEach((k, v) -> {
            Field field = ReflectionUtils.findField(cls, k);
            field.setAccessible(true);
            ReflectionUtils.setField(field, target, v);
        });
    }

    public static <T> void putDtoToEntity(Map<String, Object> dto, T target, Class<T> cls) {
        dto.forEach((k, v) -> {
            Field field = ReflectionUtils.findField(cls, k);
            field.setAccessible(true);
            ReflectionUtils.setField(field, target, v);
        });
    }

    public static <T> void changeIfPresent(JsonNullable<T> nullable, Consumer<T> consumer) {
        if(nullable != null && nullable.isPresent()) {
            consumer.accept(nullable.get());
        }
    }

}
