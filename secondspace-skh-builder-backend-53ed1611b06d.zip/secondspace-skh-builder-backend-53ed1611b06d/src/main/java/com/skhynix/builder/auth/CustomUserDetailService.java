package com.skhynix.builder.auth;

import com.skhynix.builder.document.ProtoTypeUser;
import com.skhynix.builder.document.User;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.repository.mongo.ProtoTypeUserRepository;
import com.skhynix.builder.repository.mongo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CustomUserDetailService implements UserDetailsService {
    private ProtoTypeUserRepository protoTypeUserRepository;
    private UserRepository userRepository;

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Autowired
    public void setProtoTypeUserRepository(ProtoTypeUserRepository protoTypeUserRepository) {
        this.protoTypeUserRepository = protoTypeUserRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String userUniqId) throws UsernameNotFoundException {
        ProtoTypeUser user = protoTypeUserRepository.findByUserUniqId(userUniqId);
        if(user == null) throw new UsernameNotFoundException("User not found with userUniqId : " + userUniqId);

        return UserPrincipal.create(user);
    }

    @Transactional
    public UserDetails loadUserById(UserType userType, String id) {
        if(UserType.prototype_user == userType) {
            ProtoTypeUser user = protoTypeUserRepository.findById(id).orElseThrow(
                    () -> new BuilderException(RCode.USER_NOT_EXISTS, id)
            );
            return UserPrincipal.create(user);
        } else {
            User user = userRepository.findById(id).orElseThrow(
                    () -> new BuilderException(RCode.USER_NOT_EXISTS, id)
            );
            return UserPrincipal.create(user);
        }
    }
}