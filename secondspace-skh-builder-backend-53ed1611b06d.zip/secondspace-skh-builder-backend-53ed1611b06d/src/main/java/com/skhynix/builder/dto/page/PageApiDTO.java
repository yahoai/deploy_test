package com.skhynix.builder.dto.page;

import com.skhynix.builder.dto.api.ApiDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageApiDTO {
    @DocumentId
    String apiId;
    Object data;
}
