package com.skhynix.builder.service;

import com.skhynix.builder.document.Api;
import com.skhynix.builder.document.Application;
import com.skhynix.builder.dto.api.ApiDTO;
import com.skhynix.builder.dto.api.ApiPatchDTO;
import com.skhynix.builder.dto.api.CreateApiListDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.query.ApiQueryService;
import com.skhynix.builder.repository.ApiRepository;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.util.CommonUtil;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ApiService {
    private ApiRepository apiRepository;
    private ApplicationRepository applicationRepository;
    private ApiQueryService apiQueryService;

    @Autowired
    public void setApiQueryService(ApiQueryService apiQueryService) {
        this.apiQueryService = apiQueryService;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Autowired
    public void setApiRepository(ApiRepository apiRepository) {
        this.apiRepository = apiRepository;
    }

    public ApiDTO createApi(ApiDTO apiDTO) {
        try {
            Application application = applicationRepository.findById(apiDTO.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, apiDTO.getApplicationId()));

            Api api = Api.of(apiDTO);

            return ApiDTO.of(apiRepository.save(api));

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void deleteApi(List<String> apiId) throws BuilderException {
        try {
            apiRepository.deleteAllByIdIn(apiId);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public ApiDTO patchApi(String apiId, ApiPatchDTO apiPatchDTO) throws BuilderException {
        try {
            Api api = apiRepository.findById(apiId)
                    .orElseThrow(() -> new BuilderException(RCode.API_NOT_FOUND, apiId));

            CommonUtil.changeIfPresent(apiPatchDTO.getApiName(), api::setApiName);
            CommonUtil.changeIfPresent(apiPatchDTO.getSendData(), api::setSendData);
            CommonUtil.changeIfPresent(apiPatchDTO.getConnectStoreData(), api::setConnectStoreData);
            CommonUtil.changeIfPresent(apiPatchDTO.getFilter(), api::setFilter);
            CommonUtil.changeIfPresent(apiPatchDTO.getSort(), api::setSort);
            CommonUtil.changeIfPresent(apiPatchDTO.getType(), api::setType);
            CommonUtil.changeIfPresent(apiPatchDTO.getMethod(), api::setMethod);
            CommonUtil.changeIfPresent(apiPatchDTO.getKey(), api::setKey);
            CommonUtil.changeIfPresent(apiPatchDTO.getComponentName(), api::setComponentName);
            CommonUtil.changeIfPresent(apiPatchDTO.getDocumentType(), api::setDocumentType);


            return ApiDTO.of(apiRepository.save(api));
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public ApiDTO replaceApi(String apiId, ApiDTO apiDTO) throws BuilderException {
        try {
            Api api = apiRepository.findById(apiId)
                    .orElseThrow(() -> new BuilderException(RCode.API_NOT_FOUND, apiId));

            Api newApi = Api.of(apiDTO);
            newApi.setCreatedAt(api.getCreatedAt());
            newApi.setUpdatedAt(api.getUpdatedAt());

            return ApiDTO.of(apiQueryService.replaceApi(apiId, newApi));
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<ApiDTO> getApiList(String applicationId) throws BuilderException {
        try {
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, applicationId));

            return apiRepository.findByApplicationId(new ObjectId(applicationId)).stream()
                    .map(ApiDTO::of).collect(Collectors.toList());
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<ApiDTO> createApis(CreateApiListDTO apiDTO) throws BuilderException {
        try {
            Application application = applicationRepository.findById(apiDTO.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, apiDTO.getApplicationId()));

            List<String> insertedId = apiQueryService.bulkWriteApi4Create(apiDTO);

            List<Api> result= apiRepository.findAllByIdInOrderByIdAsc(insertedId);

            return result.stream().map(ApiDTO::of).collect(Collectors.toList());

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
