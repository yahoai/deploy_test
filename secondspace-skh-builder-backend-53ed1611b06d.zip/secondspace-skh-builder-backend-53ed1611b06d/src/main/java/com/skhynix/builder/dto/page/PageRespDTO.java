package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.Page;
import com.skhynix.builder.document.embedded.PageApi;
import com.skhynix.builder.dto.component.ComponentInfoDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PageRespDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    private String title;
    private String description;
    private Object componentData;
    private Object componentConditionAction;
    private Object componentEvent;
    private Object builderLayouts;
    private Object childLayoutsList;
    private String applicationId;
    private String applicationTitle;
    private String applicationUniqPath;
    private String pageUrl;
    private String masterPage;
    private Long updatedAt;
    private Long createdAt;
    private Long publishedAt;
    private PageAuthorizationRespDTO authorizations;
    private ComponentInfoDTO componentInfo;
    private Object pageParam;
    private Boolean allowAnyUser;
    private Object options;
    private Object frontData;
    private List<PageApiRespDTO> apiList;

    public static PageRespDTO of(Page p, Map<String, Authorization> authMap,List<PageApiRespDTO> apiList ) {
        ComponentInfoDTO componentInfoDTO = new ComponentInfoDTO();

        if(p.getComponentInfo() != null) {
            componentInfoDTO.setI(p.getComponentInfo().getI());
            componentInfoDTO.setId(p.getComponentInfo().getId() != null ?
                    p.getComponentInfo().getId().toString() : null);
        }
        return PageRespDTO.builder()
                .id(p.getId())
                .title(p.getTitle())
                .description(p.getDescription())
                .componentData(p.getComponentData())
                .componentConditionAction(p.getComponentConditionAction())
                .componentEvent(p.getComponentEvent())
                .builderLayouts(p.getBuilderLayouts())
                .childLayoutsList(p.getChildLayoutsList())
                .applicationId(p.getApplicationId() != null ? p.getApplicationId().toString() : null)
                .applicationTitle(p.getApplicationTitle())
                .applicationUniqPath(p.getApplicationUniqPath())
                .pageUrl(p.getPageUrl())
                .componentInfo(componentInfoDTO)
                .pageParam(p.getPageParam())
                .updatedAt(p.getUpdatedAt())
                .createdAt(p.getCreatedAt())
                .authorizations(PageAuthorizationRespDTO.of(p.getAuthorizations(), authMap))
                .allowAnyUser(p.getAllowAnyUser())
                .masterPage(p.getMasterPage() != null ? p.getMasterPage().toString() : null)
                .options(p.getOptions())
                .frontData(p.getFrontData())
                .apiList(apiList)
                .build();
    }
}

