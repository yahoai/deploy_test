package com.skhynix.builder.dto.validator;

import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Component
public class DocumentIdValidator implements ConstraintValidator<DocumentId, String> {
    public void initialize(DocumentId constraint) {
    }

    public boolean isValid(String obj, ConstraintValidatorContext context) {
        try {
            if(obj == null)
                return true;

            new ObjectId(obj);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
