package com.skhynix.builder.document.embedded;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Footer {
    private Boolean isUse;
    private FooterTitle title;
    private List<FooterLink> link;
    private Object bottomData;
}
