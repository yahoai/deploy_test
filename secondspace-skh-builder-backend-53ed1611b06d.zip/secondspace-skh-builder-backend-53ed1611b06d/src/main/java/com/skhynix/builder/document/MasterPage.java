package com.skhynix.builder.document;


import com.skhynix.builder.document.embedded.Footer;
import com.skhynix.builder.document.embedded.Menu;
import com.skhynix.builder.dto.page.MasterPageDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MasterPage {
    private Boolean isDefault;
    private String title;
    private String desc;
    private Boolean usePermission;
    private Object header;
    private Object design;
    private Footer footer;
    private Menu menu;
    private Object frontData;
    private Long createdAt;
    private Long updatedAt;

    public static MasterPage of(MasterPageDTO masterPageDTO) {
        return MasterPage.builder()
                .isDefault(masterPageDTO.getIsDefault())
                .title(masterPageDTO.getTitle())
                .usePermission(masterPageDTO.getUsePermission())
                .header(masterPageDTO.getHeader())
                .design(masterPageDTO.getDesign())
                .footer(masterPageDTO.getFooter())
                .menu(masterPageDTO.getMenu())
                .frontData(masterPageDTO)
                .createdAt(System.currentTimeMillis())
                .updatedAt(System.currentTimeMillis())
                .build();
    }
}
