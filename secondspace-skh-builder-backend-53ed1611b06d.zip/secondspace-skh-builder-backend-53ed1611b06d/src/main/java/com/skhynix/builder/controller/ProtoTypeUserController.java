package com.skhynix.builder.controller;

import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.user.JoinProtoTypeUserRespDTO;
import com.skhynix.builder.dto.user.ProtoTypeUserDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.UserService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/prototype/users")
@Validated
public class ProtoTypeUserController extends BuilderExceptionHandler {
    private UserService userService;

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/join")
    @ApiOperation(value = "joinProtoTypeUser", notes = "프로토타입 빌더를 사용하기 위해 사용자를 가입시키는 API 입니다 \n" +
            "프로토타입에 생성된 어플리케이션에 가입하는 API는 별도로 존재합니다. \n" +
            "가입이 완료된 후 토큰을 반환합니다.")
    public ResponseEntity<SingleItemResponse<JoinProtoTypeUserRespDTO>> joinProtoTypeUser(
            @RequestBody @Valid ProtoTypeUserDTO userDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", userDTO.toString());

        JoinProtoTypeUserRespDTO response = userService.joinProtoTypeUser(userDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @GetMapping
    @ApiOperation(value = "getProtoTypeUsers", notes = "프로토타입 빌더에 가입된 사용자를 반환합니다")
    public ResponseEntity<ListItemResponse<ProtoTypeUserDTO>> getProtoTypeUsers() throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", "");

        List<ProtoTypeUserDTO> response = userService.getProtoTypeUsers();

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(ListItemResponse.create(response));
    }
}
