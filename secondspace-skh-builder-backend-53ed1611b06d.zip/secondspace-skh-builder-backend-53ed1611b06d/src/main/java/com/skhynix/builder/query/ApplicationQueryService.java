package com.skhynix.builder.query;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.Component;
import com.skhynix.builder.logger.InfoLogger;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApplicationQueryService {
    private MongoTemplate mongoTemplate;

    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public Application replaceApplication(String applicationId, Application application)  {
        Query query = new Query();

        Criteria criteria = Criteria.where("id").is(applicationId);
        query.addCriteria(criteria);

        mongoTemplate.findAndReplace(query, application);

        Application application1 = mongoTemplate.findOne(query, Application.class);

        return application1;
    }

    public List<Application> findMyApplication(String protoTypeUserId)  {
        Query query = new Query();
        Criteria criteria = Criteria.where("members.userId").is(new ObjectId(protoTypeUserId));
        query.addCriteria(criteria).with(Sort.by(Sort.Direction.DESC, "updatedAt"));
        List<Application> result = mongoTemplate.find(query, Application.class);

        return result;
    }
}
