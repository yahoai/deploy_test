package com.skhynix.builder.dto.page;

import com.skhynix.builder.dto.component.ComponentInfoDTO;
import lombok.Data;
import org.bson.types.ObjectId;
import org.openapitools.jackson.nullable.JsonNullable;
import org.springframework.data.annotation.ReadOnlyProperty;

import javax.validation.Valid;
import java.util.List;

@Data
public class PagePatchDTO {
    @ReadOnlyProperty
    private JsonNullable<String> id;
    private JsonNullable<String> title;
    private JsonNullable<String> description;
    private JsonNullable<Object> componentData;
    private JsonNullable<Object> componentConditionAction;
    private JsonNullable<Object> componentEvent;
    private JsonNullable<Object> builderLayouts;
    private JsonNullable<Object> childLayoutsList;
    private JsonNullable<String> applicationId;
    private JsonNullable<String> pageUrl;
    private JsonNullable<PageAuthorizationDTO> authorizations;
    private JsonNullable<@Valid ComponentInfoDTO> componentInfo;
    private JsonNullable<Object> pageParam;
    private JsonNullable<Boolean> allowAnyUser;
    private JsonNullable<Object> options;
    private JsonNullable<String> masterPage;
    private JsonNullable<Object> frontData;
    private JsonNullable<List<@Valid PageApiDTO>> apiList;
}
