package com.skhynix.builder.dto.datastore;

import com.skhynix.builder.dto.validator.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.openapitools.jackson.nullable.JsonNullable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DataStorePatchDTO {
    private JsonNullable<String> keyName;
    private JsonNullable<String> name;
    private JsonNullable<String> className;
    private JsonNullable<String> use;
    private JsonNullable<String> fid;
    private JsonNullable<Boolean> edit;
}
