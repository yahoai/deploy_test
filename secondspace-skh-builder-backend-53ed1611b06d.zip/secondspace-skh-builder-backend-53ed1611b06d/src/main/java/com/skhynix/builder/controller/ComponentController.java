package com.skhynix.builder.controller;

import com.skhynix.builder.document.Component;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.component.ComponentDTO;
import com.skhynix.builder.dto.component.ComponentPatchDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.query.ComponentQueryService;
import com.skhynix.builder.repository.mongo.ComponentRepository;
import com.skhynix.builder.service.ComponentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/components")
@Validated
public class ComponentController extends BuilderExceptionHandler {
    private ComponentRepository componentRepository;
    private ComponentQueryService componentQueryService;
    private ComponentService componentService;

    @Autowired
    public void setComponentQueryService(ComponentQueryService componentQueryService) {
        this.componentQueryService = componentQueryService;
    }

    @Autowired
    public void setComponentService(ComponentService componentService) {
        this.componentService = componentService;
    }


    @Autowired
    public void setComponentRepository(ComponentRepository componentRepository) {
        this.componentRepository = componentRepository;
    }

    @PostMapping
    public ResponseEntity<SingleItemResponse<ComponentDTO>> createComponent(
            @RequestBody @Valid ComponentDTO componentDTO) {

        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", componentDTO.toString());

        Component component1 = Component.of(componentDTO);
        componentRepository.save(component1);

        ComponentDTO response = ComponentDTO.of(component1);

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    //페이징이 구현되어야 함
    @GetMapping
    public ResponseEntity<ListItemResponse<ComponentDTO>> getComponents(
            @RequestParam(required = false) Integer componentType,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String tags,
            @RequestParam(required = false) Set<@Valid @DocumentId String> id) {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        Map<String, Object> param = new HashMap<>();
        param.put("componentType", componentType);
        param.put("title", title);
        param.put("tags", tags);
        param.put("id", id);

        ApiAccLogger.api_req_acc_log(functionName, param.toString(), "");

        List<ComponentDTO> response = componentQueryService.getComponents(componentType, title, tags, id);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @PatchMapping("/{componentId}")
    public ResponseEntity<SingleItemResponse<ComponentDTO>> patchComponent(
            @PathVariable @DocumentId String componentId,
            @Valid @RequestBody ComponentPatchDTO componentDTO) {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, componentId, componentDTO.toString());

        ComponentDTO response = componentService.patchComponent(componentId, componentDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }


    @PutMapping("/{componentId}")
    public ResponseEntity<SingleItemResponse<ComponentDTO>> replaceComponent(
            @PathVariable @DocumentId String componentId,
            @Valid @RequestBody ComponentDTO componentDTO) {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, componentId, componentDTO.toString());

        ComponentDTO response = componentService.replaceComponent(componentId, componentDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }
}
