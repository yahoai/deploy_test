package com.skhynix.builder.document;

import com.skhynix.builder.document.embedded.ComponentInfo;
import com.skhynix.builder.document.embedded.PageApi;
import com.skhynix.builder.document.embedded.PageAuthorization;
import com.skhynix.builder.dto.component.ComponentInfoDTO;
import com.skhynix.builder.dto.page.PageAuthorizationDTO;
import com.skhynix.builder.dto.page.PageDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import java.util.List;

@Document("production_page")
@Data
@CompoundIndex(
        def = "{'authorizations.allow.userList': 1}")
@CompoundIndex(
        def = "{'authorizations.allow.authorizationList': 1}")
@CompoundIndex(
        def = "{'authorizations.deny.userList': 1}")
@CompoundIndex(
        def = "{'authorizations.deny.authorizationList': 1}")
@CompoundIndex(
        def = "{'componentInfo.id': 1}")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductionPage {
    @Id
    private String id;
    private String title;
    private String description;
    private Object componentData;
    private Object componentConditionAction;
    private Object componentEvent;
    private Object builderLayouts;
    private Object childLayoutsList;
    private ObjectId applicationId;
    private String applicationTitle;
    private String applicationUniqPath;
    private String pageUrl;
    private Long updatedAt;
    private Long publishedAt;
    private PageAuthorization authorizations;
    private ComponentInfo componentInfo;
    private Object pageParam;
    private Boolean allowAnyUser;
    private Object options;
    private Long createdAt;
    private ObjectId masterPage;
    private Object frontData;
    private List<PageApi> apiList;

    public static ProductionPage of(Page p) {
        return ProductionPage.builder()
                .id(p.getId())
                .title(p.getTitle())
                .description(p.getDescription())
                .componentData(p.getComponentData())
                .componentConditionAction(p.getComponentConditionAction())
                .componentEvent(p.getComponentEvent())
                .builderLayouts(p.getBuilderLayouts())
                .childLayoutsList(p.getChildLayoutsList())
                .applicationId(p.getApplicationId())
                .applicationTitle(p.getApplicationTitle())
                .applicationUniqPath(p.getApplicationUniqPath())
                .pageUrl(p.getPageUrl())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .publishedAt(p.getPublishedAt())
                .authorizations(p.getAuthorizations())
                .componentInfo(p.getComponentInfo())
                .pageParam(p.getPageParam())
                .allowAnyUser(p.getAllowAnyUser())
                .options(p.getOptions())
                .masterPage(p.getMasterPage())
                .frontData(p.getFrontData())
                .apiList(p.getApiList())
                .build();
    }
}
