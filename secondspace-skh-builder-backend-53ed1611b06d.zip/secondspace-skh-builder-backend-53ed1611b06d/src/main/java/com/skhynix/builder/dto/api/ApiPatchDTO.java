package com.skhynix.builder.dto.api;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.openapitools.jackson.nullable.JsonNullable;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApiPatchDTO {
    private JsonNullable<String> apiName;
    private JsonNullable<Object> type;
    private JsonNullable<Object> sendData;
    private JsonNullable<Object> filter;
    private JsonNullable<Object> sort;
    private JsonNullable<String> connectStoreData;
    private JsonNullable<String> method;
    private JsonNullable<String> key;
    private JsonNullable<String> documentType;
    private JsonNullable<String> componentName;
}
