package com.skhynix.builder.dto.component;

import com.skhynix.builder.document.Component;
import com.skhynix.builder.document.embedded.ComponentInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.ReadOnlyProperty;

import javax.validation.Valid;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComponentDTO {
    @ReadOnlyProperty
    private String id;
    private String title;
    private String description;
    private List<String> tags;
    private String componentName;
    private Object componentData;
    private Integer componentType;
    private Object componentConditionAction;
    private Object componentEvent;
    private Object builderLayouts;
    private Object childLayoutsList;
    @Valid
    private ComponentInfoDTO componentInfo;
    private Object options;
    private Long createdAt;

    public static ComponentDTO of(Component c) {
        ComponentInfoDTO componentInfoDTO = new ComponentInfoDTO();

        if(c.getComponentInfo() != null) {
            componentInfoDTO.setI(c.getComponentInfo().getI());
            componentInfoDTO.setId(c.getComponentInfo().getId() != null ?
                    c.getComponentInfo().getId().toString() : null);
        }
        return ComponentDTO.builder()
                .id(c.getId())
                .title(c.getTitle())
                .description(c.getDescription())
                .tags(c.getTags())
                .componentName(c.getComponentName())
                .componentData(c.getComponentData())
                .componentType(c.getComponentType())
                .componentConditionAction(c.getComponentConditionAction())
                .componentEvent(c.getComponentEvent())
                .builderLayouts(c.getBuilderLayouts())
                .childLayoutsList(c.getChildLayoutsList())
                .componentInfo(componentInfoDTO)
                .options(c.getOptions())
                .createdAt(c.getCreatedAt())
                .build();
    }
}
