package com.skhynix.builder.service;

import com.skhynix.builder.repository.mongo.ProtoTypeUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProtoTypeUserService {
    private ProtoTypeUserRepository protoTypeUserRepository;

    @Autowired
    public void setBuilderUserRepository(ProtoTypeUserRepository protoTypeUserRepository) {
        this.protoTypeUserRepository = protoTypeUserRepository;
    }
}
