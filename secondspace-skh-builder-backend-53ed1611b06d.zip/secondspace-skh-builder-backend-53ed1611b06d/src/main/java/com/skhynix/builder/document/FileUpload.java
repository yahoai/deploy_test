package com.skhynix.builder.document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

@Document("file_upload")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FileUpload {
    @Id
    private String id;
    @Indexed
    private ObjectId applicationId;
    private String filePath;
    private String mimeType;
    @Indexed(direction = IndexDirection.DESCENDING)
    private Long createdAt;
}
