package com.skhynix.builder.controller;

import com.skhynix.builder.auth.CurrentUser;
import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.dto.api.ApiDTO;
import com.skhynix.builder.dto.api.ApiPatchDTO;
import com.skhynix.builder.dto.api.CreateApiListDTO;
import com.skhynix.builder.dto.common.EmptyResponse;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.ApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/apis")
@Validated
public class ApiController extends BuilderExceptionHandler {
    private ApiService apiService;

    @Autowired
    public void setApiService(ApiService apiService) {
        this.apiService = apiService;
    }


    public ResponseEntity<SingleItemResponse<ApiDTO>> createApi(
            @CurrentUser UserPrincipal currentUser,
            @RequestBody ApiDTO apiDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", apiDTO.toString());

        ApiDTO response = apiService.createApi(apiDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PostMapping()
    public ResponseEntity<ListItemResponse<ApiDTO>> createApis(
            @CurrentUser UserPrincipal currentUser,
            @RequestBody CreateApiListDTO apiDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", apiDTO.toString());

        List<ApiDTO> response = apiService.createApis(apiDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @GetMapping
    public ResponseEntity<ListItemResponse<ApiDTO>> getApiList(
            @CurrentUser UserPrincipal userPrincipal,
            @RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        List<ApiDTO> response = apiService.getApiList(applicationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @PatchMapping("/{apiId}")
    public ResponseEntity<EmptyResponse> patchApi(
            @CurrentUser UserPrincipal currentUser,
            @PathVariable @DocumentId String apiId,
            @RequestBody ApiPatchDTO apiPatchDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, apiId, apiPatchDTO.toString());

        ApiDTO  response = apiService.patchApi(apiId, apiPatchDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(EmptyResponse.create());
    }

    @PutMapping("/{apiId}")
    public ResponseEntity<EmptyResponse> replaceApi(
            @CurrentUser UserPrincipal currentUser,
            @PathVariable @DocumentId String apiId,
            @RequestBody ApiDTO apiDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, apiId, apiDTO.toString());

        ApiDTO  response = apiService.replaceApi(apiId, apiDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(EmptyResponse.create());
    }

    @DeleteMapping
    public ResponseEntity<EmptyResponse> deleteApi(
            @CurrentUser UserPrincipal currentUser,
            @RequestParam List<@DocumentId String> apiIdList) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, apiIdList.toString(), "");

        apiService.deleteApi(apiIdList);

        return ResponseEntity.ok(EmptyResponse.create());
    }
}
