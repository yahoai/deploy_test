package com.skhynix.builder.query;

import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

@Service
public class AuthorizationQueryService {
    private MongoTemplate mongoTemplate;

    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public Authorization replaceAuthorization(String authId, Authorization authorization) {
        Query query = new Query();

        Criteria criteria = Criteria.where("id").is(authId);
        query.addCriteria(criteria);

        mongoTemplate.findAndReplace(query, authorization);

        Authorization result = mongoTemplate.findOne(query, Authorization.class);

        return result;
    }
}
