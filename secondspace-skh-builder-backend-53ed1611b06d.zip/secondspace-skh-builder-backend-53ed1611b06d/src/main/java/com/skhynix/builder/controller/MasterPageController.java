package com.skhynix.builder.controller;

import com.skhynix.builder.dto.common.EmptyResponse;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.page.MasterPageDTO;
import com.skhynix.builder.dto.page.MasterPagePatchDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.MasterPageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/masterPage")
@Validated
public class MasterPageController extends BuilderExceptionHandler {
    private MasterPageService masterPageService;

    @Autowired
    public void setMasterPageService(MasterPageService masterPageService) {
        this.masterPageService = masterPageService;
    }

    @GetMapping
    public ResponseEntity<SingleItemResponse<MasterPageDTO>> getMasterPage(
            @RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        MasterPageDTO response = masterPageService.getMasterPage(applicationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PutMapping
    public ResponseEntity<SingleItemResponse<MasterPageDTO>> replaceMasterPage(
            @RequestBody @Valid MasterPageDTO masterPageDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", masterPageDTO.toString());

        MasterPageDTO response = masterPageService.replaceMasterPage(masterPageDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PatchMapping
    public ResponseEntity<SingleItemResponse<MasterPageDTO>> replaceMasterPage(
            @RequestBody @Valid MasterPagePatchDTO masterPageDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", masterPageDTO.toString());

        MasterPageDTO response = masterPageService.patchMasterPage(masterPageDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }
}
