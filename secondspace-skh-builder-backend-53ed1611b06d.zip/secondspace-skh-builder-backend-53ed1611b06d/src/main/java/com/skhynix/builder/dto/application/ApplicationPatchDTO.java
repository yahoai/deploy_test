package com.skhynix.builder.dto.application;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.openapitools.jackson.nullable.JsonNullable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationPatchDTO {
    private JsonNullable<String> uniqPath;
    private JsonNullable<String> title;
    private JsonNullable<String> description;
    private JsonNullable<String> bassAppId;
    private JsonNullable<Object> customCss;
    private JsonNullable<Object> frontData;
    private JsonNullable<Boolean> allowPermission;
}
