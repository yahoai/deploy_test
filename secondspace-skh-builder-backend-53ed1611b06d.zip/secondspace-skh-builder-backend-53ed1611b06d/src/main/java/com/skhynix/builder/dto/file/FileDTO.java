package com.skhynix.builder.dto.file;

import com.skhynix.builder.document.FileUpload;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDTO {
    private String id;
    private String applicationId;
    private String filePath;
    private Long createdAt;

    public static FileDTO of(FileUpload f) {
        return FileDTO.builder()
                .id(f.getId())
                .applicationId(f.getApplicationId().toString())
                .filePath(f.getFilePath())
                .createdAt(f.getCreatedAt())
                .build();
    }
}
