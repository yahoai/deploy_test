package com.skhynix.builder.dto.user;

import com.skhynix.builder.document.embedded.ApplicationManagerType;
import com.skhynix.builder.dto.validator.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AddApplicationManagerDTO {
    @NotNull
    @DocumentId
    private String applicationId;
    @NotNull
    @DocumentId
    private String protoTypeUserId;
    private ApplicationManagerType type;
}
