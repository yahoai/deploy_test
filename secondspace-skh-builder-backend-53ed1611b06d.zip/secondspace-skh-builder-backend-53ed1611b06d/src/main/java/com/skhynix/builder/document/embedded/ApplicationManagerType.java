package com.skhynix.builder.document.embedded;

public enum ApplicationManagerType {
    OWNER,
    MANAGER,
    USER,
}
