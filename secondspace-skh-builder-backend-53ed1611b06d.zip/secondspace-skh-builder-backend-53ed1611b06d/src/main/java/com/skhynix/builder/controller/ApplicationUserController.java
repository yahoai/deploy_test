package com.skhynix.builder.controller;

import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.user.*;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.UserService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/application/users")
@Validated
public class ApplicationUserController extends BuilderExceptionHandler {
    private UserService userService;

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<SingleItemResponse<JoinUserRespDTO>> joinApplicationUser(
            @RequestBody @Valid UserDTO userDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", userDTO.toString());

        JoinUserRespDTO response = userService.joinApplication(userDTO);

        ApiAccLogger.api_req_acc_log(functionName, "", userDTO.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }


    @GetMapping
    @ApiOperation(value = "getAppUserList", notes = "배포된 어픒리케이션에 가입된 사용자 목록을 반환합니다.")
    public ResponseEntity<ListItemResponse<UserRespDTO>> getAppUserList(@RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        List<UserRespDTO> response = userService.getUserList(applicationId);
        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @GetMapping("/{userId}")
    @ApiOperation(value = "getApplicationUserInfo", notes = "어플리케이션 사용자 정보를 조회합니다.")
    public ResponseEntity<SingleItemResponse<UserRespDTO>> getApplicationUserInfo(
            @RequestParam @DocumentId String applicationId,
            @PathVariable @DocumentId String userId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        Map<String, Object> param = new HashMap<>();
        param.put("applicationId", applicationId);
        param.put("userId", userId);
        ApiAccLogger.api_req_acc_log(functionName, param.toString(), "");

        UserRespDTO response = userService.getApplicationUserInfo(applicationId, userId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PatchMapping("/{userId}")
    public ResponseEntity<SingleItemResponse<UserRespDTO>> patchApplicationUser(
            @RequestParam @DocumentId String applicationId,
            @PathVariable @DocumentId String userId,
            @RequestBody @Valid UserPatchDTO userPatchDto) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        Map<String, Object> param = new HashMap<>();
        param.put("applicationId", applicationId);
        param.put("userId", userId);

        ApiAccLogger.api_req_acc_log(functionName, param.toString(), userPatchDto.toString());

        UserRespDTO response = userService.patchApplicationUser(applicationId, userId, userPatchDto);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }
}
