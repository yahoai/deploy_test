package com.skhynix.builder.service;

import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.Page;
import com.skhynix.builder.document.ProductionPage;
import com.skhynix.builder.document.User;
import com.skhynix.builder.document.embedded.PageAuthorization;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.repository.mongo.AuthorizationRepository;
import com.skhynix.builder.repository.mongo.PageRepository;
import com.skhynix.builder.repository.mongo.UserRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PermissionCheckService {
    private ApplicationRepository applicationRepository;
    private PageRepository pageRepository;
    private UserRepository userRepository;
    private AuthorizationRepository authorizationRepository;

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Autowired
    public void setPageRepository(PageRepository pageRepository) {
        this.pageRepository = pageRepository;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    private <T> boolean isEmpty(Set<T> list) {
        return list == null || list.size() == 0;
    }

    private <T> Boolean isEmpty(Collection<T> list) {
        return list == null || list.size() == 0;
    }


    public Boolean isPermitted4Dev(String applicationUserId, Page page) throws BuilderException {
        if(page.getAllowAnyUser()) return true;

        PageAuthorization authList = page.getAuthorizations();
        List<Authorization> authorizations = authorizationRepository.findAllByApplicationId(page.getApplicationId());

        if(isEmpty(authorizations))
            return true;

        return isPermitted(applicationUserId, authList, authorizations);
    }

    public Boolean isPermitted4Prod(String applicationUserId, ProductionPage page) throws BuilderException {
        if(page.getAllowAnyUser()) return true;

        PageAuthorization authList = page.getAuthorizations();
        List<Authorization> authorizations = authorizationRepository.findAllByApplicationId(page.getApplicationId());

        if(isEmpty(authorizations))
            return true;

        return isPermitted(applicationUserId, authList, authorizations);
    }

    private Boolean isPermitted(String applicationUserId,  PageAuthorization authList, List<Authorization> authorizations) throws BuilderException {
        try {
            List<String> allAuthIdList = authorizations.stream()
                    .map(Authorization::getId).collect(Collectors.toList());
            List<String> denyList = new ArrayList<>();
            if(authList != null && !isEmpty(authList.getDeny())) {
                denyList = authList.getDeny().stream().map(ObjectId::toString).collect(Collectors.toList());
            }

            Collection<String> allowList = CollectionUtils.subtract(allAuthIdList, denyList);

            Set<ObjectId> authListToCheck;
            boolean returnValue;

            if(!isEmpty(allowList)) {
                if(applicationUserId == null) return false;

                authListToCheck = allowList.stream().map(ObjectId::new).collect(Collectors.toSet());
                returnValue = true;
            } else if(!isEmpty(denyList)) {
                if(applicationUserId == null) return false;

                authListToCheck = denyList.stream().map(ObjectId::new).collect(Collectors.toSet());
                returnValue = false;
            } else {
                return true;
            }

            User user = userRepository.findById(applicationUserId)
                    .orElseThrow(() -> new BuilderException(RCode.UNAUTHORIZED));

            Set<ObjectId> userAuthList = user.getAuthorizations();

            if(isEmpty(userAuthList)) {
                return !returnValue;
            }

            boolean matched = userAuthList.stream().anyMatch( authListToCheck::contains);

            if(matched)
                return returnValue;
            else
                return !returnValue;

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
