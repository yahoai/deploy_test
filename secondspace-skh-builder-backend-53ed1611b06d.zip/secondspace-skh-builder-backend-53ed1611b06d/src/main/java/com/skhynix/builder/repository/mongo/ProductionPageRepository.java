package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.Page;
import com.skhynix.builder.document.ProductionPage;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductionPageRepository extends MongoRepository<ProductionPage, String> {
    ProductionPage findByApplicationIdAndPageUrl(ObjectId applicationId, String pageUrl);
}
