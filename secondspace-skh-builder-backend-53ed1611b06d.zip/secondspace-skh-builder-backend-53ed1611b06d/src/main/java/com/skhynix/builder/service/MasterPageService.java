package com.skhynix.builder.service;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.MasterPage;
import com.skhynix.builder.dto.page.MasterPageDTO;
import com.skhynix.builder.dto.page.MasterPagePatchDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MasterPageService {
    private ApplicationRepository applicationRepository;
    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }


    public MasterPageDTO createMasterPage(MasterPageDTO masterPageDTO) throws BuilderException {
        try {
            Application application = applicationRepository.findById(masterPageDTO.getApplicationId())
                    .orElseThrow(
                            () -> new BuilderException(RCode.APPLICATION_NOT_FOUND, masterPageDTO.getApplicationId()
                            ));
            application.setUpdatedAt(System.currentTimeMillis());

            MasterPage masterPage = MasterPage.of(masterPageDTO);
            application.setMasterPage(masterPage);
            applicationRepository.save(application);


            return MasterPageDTO.of(masterPage, application.getId());

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public MasterPageDTO replaceMasterPage(MasterPageDTO masterPageDTO) throws BuilderException {
        try {
            Application application = applicationRepository.findById(masterPageDTO.getApplicationId())
                    .orElseThrow(
                            () -> new BuilderException(RCode.APPLICATION_NOT_FOUND, masterPageDTO.getApplicationId()
                            ));


            application.setUpdatedAt(System.currentTimeMillis());
            MasterPage masterPage = MasterPage.of(masterPageDTO);
            application.setMasterPage(masterPage);
            applicationRepository.save(application);

            return MasterPageDTO.of(application.getMasterPage(), application.getId());
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }


    public MasterPageDTO patchMasterPage(MasterPagePatchDTO mpp) {
        try {
            Application application = applicationRepository.findById(mpp.getApplicationId())
                    .orElseThrow(
                            () -> new BuilderException(RCode.APPLICATION_NOT_FOUND, mpp.getApplicationId()
                            ));
            MasterPage masterPage = application.getMasterPage();

            if(masterPage == null)
                masterPage = new MasterPage();

            CommonUtil.changeIfPresent(mpp.getDesc(), masterPage::setDesc);
            CommonUtil.changeIfPresent(mpp.getDesign(), masterPage::setDesign);
            CommonUtil.changeIfPresent(mpp.getFooter(), masterPage::setFooter);
            CommonUtil.changeIfPresent(mpp.getFrontData(), masterPage::setFrontData);
            CommonUtil.changeIfPresent(mpp.getHeader(), masterPage::setHeader);
            CommonUtil.changeIfPresent(mpp.getIsDefault(), masterPage::setIsDefault);
            CommonUtil.changeIfPresent(mpp.getMenu(), masterPage::setMenu);
            CommonUtil.changeIfPresent(mpp.getTitle(), masterPage::setTitle);
            CommonUtil.changeIfPresent(mpp.getUsePermission(), masterPage::setUsePermission);
            masterPage.setUpdatedAt(System.currentTimeMillis());

            application.setUpdatedAt(System.currentTimeMillis());
            application.setMasterPage(masterPage);
            applicationRepository.save(application);

            return MasterPageDTO.of(application.getMasterPage(), application.getId());

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public MasterPageDTO getMasterPage(String applicationId) throws BuilderException {
        try {

            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(
                            () -> new BuilderException(RCode.APPLICATION_NOT_FOUND, applicationId
                            ));
            if(application.getMasterPage() == null) {
                return new MasterPageDTO();
            }

            return MasterPageDTO.of(application.getMasterPage(), applicationId);

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
