package com.skhynix.builder.query;

import com.skhynix.builder.document.Component;
import com.skhynix.builder.dto.component.ComponentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ComponentQueryService {
    private MongoTemplate mongoTemplate;

    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public List<ComponentDTO> getComponents(Integer componentType, String title, String tags, Set<String> id) {
        Query query = new Query();

        Criteria criteria = null;

        if(componentType != null) {
            criteria = Criteria.where("componentType").is(componentType);
        }

        if(title != null) {
            if(criteria == null) {
                criteria = Criteria.where("title").is(title);
            } else {
                criteria = criteria.and("title").is(title);
            }
        }

        if(tags != null) {
            if(criteria == null) {
                criteria = Criteria.where("tags").is(tags);
            } else {
                criteria = criteria.and("tags").is(tags);
            }
        }

        if(id != null) {
            if(criteria == null) {
                criteria = Criteria.where("id").in(id);
            } else {
                criteria = criteria.and("id").in(id);
            }
        }
        List<Component> components = new ArrayList<>();

        if(criteria != null) {
            query.addCriteria(criteria);
            components = mongoTemplate.find(query, Component.class);
        } else {
            components = mongoTemplate.findAll(Component.class);
        }

        return components.stream()
                .map(ComponentDTO::of).collect(Collectors.toList());
    }


    public Component replaceComponent(String componentId, Component component)  {
        Query query = new Query();

        Criteria criteria = Criteria.where("id").is(componentId);
        query.addCriteria(criteria);

        mongoTemplate.findAndReplace(query, component);

        Component component1 = mongoTemplate.findOne(query, Component.class);

        return component1;
    }
}
