package com.skhynix.builder.document;


import com.skhynix.builder.dto.user.UserDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Document("user")
@Data
@CompoundIndex(def = "{'applicationId':1, 'userUniqId':1}", unique = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class User {
    @Id
    private String id;
    @Indexed(unique = false)
    private ObjectId applicationId;
    private String userUniqId;
    private String name;
    private Set<ObjectId> authorizations;
    private Long lastAuthorizationUpdatedAt;
    private Long createdAt;
    private Long updatedAt;

    public static User of(UserDTO u) {
        Set<ObjectId> authorizations = null;
        long createdAt = System.currentTimeMillis();

        if(u.getAuthorizations() != null) {
            authorizations = u.getAuthorizations().stream()
                    .map(ObjectId::new).collect(Collectors.toSet());
        }

        return User.builder()
                .userUniqId(u.getEmployeeNumber())
                .name(u.getName())
                .applicationId(new ObjectId(u.getApplicationId()))
                .authorizations(authorizations)
                .createdAt(createdAt)
                .updatedAt(createdAt)
                .build();
    }
}
