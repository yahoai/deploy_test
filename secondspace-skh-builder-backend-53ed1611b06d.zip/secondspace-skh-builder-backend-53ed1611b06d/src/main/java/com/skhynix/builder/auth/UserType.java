package com.skhynix.builder.auth;

public enum UserType {
    application_user,
    prototype_user
}
