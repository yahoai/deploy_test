package com.skhynix.builder.document.embedded;

import com.skhynix.builder.dto.page.AuthorizationListDTO;
import com.skhynix.builder.dto.page.PageAuthorizationDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageAuthorization {
    private Set<ObjectId> allow;
    private Set<ObjectId> deny;

    public static PageAuthorization of(PageAuthorizationDTO pa) {
        if(pa == null)
            return null;
        return PageAuthorization.builder()
                .allow(pa.getAllow() != null ?
                        pa.getAllow().stream().map(ObjectId::new).collect(Collectors.toSet()) : null)
                .deny(pa.getDeny() != null ?
                        pa.getDeny().stream().map(ObjectId::new).collect(Collectors.toSet()) : null)
                .build();
    }
}
