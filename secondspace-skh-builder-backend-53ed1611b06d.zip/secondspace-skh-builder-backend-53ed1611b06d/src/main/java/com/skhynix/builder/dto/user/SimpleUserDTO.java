package com.skhynix.builder.dto.user;

import com.skhynix.builder.document.User;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

import java.util.Set;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SimpleUserDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    private String applicationId;
    private String employeeNumber;
    private String name;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;

    public static SimpleUserDTO of(User u) {
        return SimpleUserDTO.builder()
                .id(u.getId())
                .employeeNumber(u.getUserUniqId())
                .name(u.getName())
                .applicationId(u.getApplicationId().toString())
                .createdAt(u.getCreatedAt())
                .build();
    }
}
