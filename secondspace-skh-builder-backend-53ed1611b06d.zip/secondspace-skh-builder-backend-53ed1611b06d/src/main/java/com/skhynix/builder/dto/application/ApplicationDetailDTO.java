package com.skhynix.builder.dto.application;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.Page;
import com.skhynix.builder.document.ProtoTypeUser;
import com.skhynix.builder.dto.page.PageDTO;
import com.skhynix.builder.dto.page.PageRespDTO;
import com.skhynix.builder.dto.user.ProtoTypeUserDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationDetailDTO {
    String id;
    String uniqPath;
    String title;
    String description;
    String bassAppId;
    Object customCss;
    Object frontData;
    Boolean allowPermission;
    ProtoTypeUserDTO owner;
    List<PageRespDTO> pages;

    public static ApplicationDetailDTO of(Application application, List<PageRespDTO> pageList) {
        return ApplicationDetailDTO.builder()
                .id(application.getId())
                .uniqPath(application.getUniqPath())
                .title(application.getTitle())
                .description(application.getDescription())
                .bassAppId(application.getBassAppId())
                .customCss(application.getCustomCss())
                .frontData(application.getFrontData())
                .allowPermission(application.getAllowPermission() != null ? application.getAllowPermission() : true)
                .pages(pageList)
                .build();
    }

    public static ApplicationDetailDTO of(Application application,
                                          ProtoTypeUser u, List<PageRespDTO> pageList) {
        return ApplicationDetailDTO.builder()
                .id(application.getId())
                .uniqPath(application.getUniqPath())
                .title(application.getTitle())
                .description(application.getDescription())
                .bassAppId(application.getBassAppId())
                .customCss(application.getCustomCss())
                .owner(ProtoTypeUserDTO.of(u))
                .frontData(application.getFrontData())
                .allowPermission(application.getAllowPermission() != null ? application.getAllowPermission() : true)
                .pages(pageList)
                .build();
    }
}
