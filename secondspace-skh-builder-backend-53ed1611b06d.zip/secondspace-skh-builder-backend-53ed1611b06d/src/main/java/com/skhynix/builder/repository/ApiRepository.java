package com.skhynix.builder.repository;

import com.skhynix.builder.document.Api;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ApiRepository extends MongoRepository<Api, String> {
    List<Api> findByApplicationId(ObjectId objectId);
    void deleteAllByIdIn(List<String> idList);
    List<Api> findAllByIdInOrderByIdAsc(List<String> idList);
}
