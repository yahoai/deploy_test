package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.User;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface UserRepository extends MongoRepository<User, String> {
    User findByApplicationIdAndUserUniqId(ObjectId applicationId, String employeeNumber);
    List<User> findAllByApplicationId(ObjectId applicationId);
}
