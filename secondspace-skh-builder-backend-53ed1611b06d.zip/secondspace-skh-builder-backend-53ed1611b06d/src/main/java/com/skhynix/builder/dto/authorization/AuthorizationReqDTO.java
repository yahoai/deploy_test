package com.skhynix.builder.dto.authorization;

import com.skhynix.builder.document.AuthorizationRequest;
import com.skhynix.builder.dto.validator.DocumentId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthorizationReqDTO {
    @NotNull
    @DocumentId
    private String applicationId;
    @NotNull
    @DocumentId
    private String authorizationId;
    @NotNull
    @DocumentId
    private String applicationUserId;
    private String reason;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;

    public static AuthorizationReqDTO of(AuthorizationRequest ar) {
        return AuthorizationReqDTO.builder()
                .applicationId(ar.getApplicationId().toString())
                .authorizationId(ar.getAuthorizationId().toString())
                .applicationUserId(ar.getApplicationUserId().toString())
                .reason(ar.getReason())
                .createdAt(ar.getCreatedAt())
                .build();
    }
}