package com.skhynix.builder.controller;

import com.skhynix.builder.auth.CurrentUser;
import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.dto.common.EmptyResponse;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.datastore.DataStoreDTO;
import com.skhynix.builder.dto.datastore.DataStoreListDTO;
import com.skhynix.builder.dto.datastore.DataStorePatchDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.DataStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/datastore")
@Validated
public class DataStoreController extends BuilderExceptionHandler {
    private DataStoreService dataStoreService;

    @Autowired
    public void setDataStoreService(DataStoreService dataStoreService) {
        this.dataStoreService = dataStoreService;
    }

    @PostMapping
    public ResponseEntity<ListItemResponse<DataStoreDTO>> createDataStore(
            @CurrentUser UserPrincipal currentUser,
            @RequestBody @Valid DataStoreListDTO dataStoreListDTO) throws BuilderException {
        try {
            String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
            ApiAccLogger.api_req_acc_log(functionName, "", dataStoreListDTO.toString());

            List<DataStoreDTO> response = dataStoreService.createDataStore(dataStoreListDTO);

            return ResponseEntity.ok(ListItemResponse.create(response));

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }


    public ResponseEntity<ListItemResponse<DataStoreDTO>> setDataStore(
            @RequestBody @Valid DataStoreListDTO dataStoreListDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", dataStoreListDTO.toString());

        List<DataStoreDTO> response = dataStoreService.setDataStore(dataStoreListDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @PutMapping("/{dataStoreId}")
    public ResponseEntity<SingleItemResponse<DataStoreDTO>> replaceDataStore(
            @CurrentUser UserPrincipal currentUser,
            @PathVariable @DocumentId String dataStoreId,
            @RequestBody @Valid DataStoreDTO dataStoreDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, dataStoreId, dataStoreDTO.toString());

        DataStoreDTO response = dataStoreService.replaceDataStore(dataStoreId, dataStoreDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PatchMapping("/{dataStoreId}")
    public ResponseEntity<SingleItemResponse<DataStoreDTO>> pathDataStore(
            @PathVariable @DocumentId String dataStoreId,
            @RequestBody @Valid DataStorePatchDTO dataStorePatchDTO) {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, dataStoreId, dataStorePatchDTO.toString());

        DataStoreDTO response = dataStoreService.pathDataStore(dataStoreId, dataStorePatchDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }


    @DeleteMapping
    public ResponseEntity<EmptyResponse> deleteDataStore(
            @CurrentUser UserPrincipal currentUser,
            @RequestParam List<@DocumentId String> dataStoreIdList) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, dataStoreIdList.toString(), "");

        dataStoreService.deleteDataStore(dataStoreIdList);

        return ResponseEntity.ok(EmptyResponse.create());
    }


    @GetMapping
    public ResponseEntity<ListItemResponse<DataStoreDTO>> getDataStoreList(
            @RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        List<DataStoreDTO> response = dataStoreService.getDataStoreList(applicationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(ListItemResponse.create(response));
    }
}
