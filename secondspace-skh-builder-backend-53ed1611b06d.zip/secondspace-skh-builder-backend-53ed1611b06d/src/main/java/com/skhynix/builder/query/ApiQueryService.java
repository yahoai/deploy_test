package com.skhynix.builder.query;

import com.mongodb.bulk.BulkWriteInsert;
import com.mongodb.bulk.BulkWriteResult;
import com.skhynix.builder.document.Api;
import com.skhynix.builder.document.DataStore;
import com.skhynix.builder.dto.api.ApiDTO;
import com.skhynix.builder.dto.api.CreateApiListDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;

import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.logger.InfoLogger;
import com.skhynix.builder.repository.ApiRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.BulkOperationException;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.FindAndReplaceOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@Service
public class ApiQueryService {
    private MongoTemplate mongoTemplate;
    private ApiRepository apiRepository;

    @Autowired
    public void setApiRepository(ApiRepository apiRepository) {
        this.apiRepository = apiRepository;
    }

    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public Api replaceApi(String apiId, Api api) {
        Query query = new Query();
        Criteria criteria = Criteria.where("id").is(apiId);
        query.addCriteria(criteria);

        FindAndReplaceOptions option = new FindAndReplaceOptions().returnNew();

        return mongoTemplate.findAndReplace(query, api, option);
    }

    @Transactional
    public List<String> bulkWriteApi4Create(CreateApiListDTO apiDTO) {
        boolean shouldBeExecuted = false;

        BulkOperations bulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.ORDERED, Api.class);


        for(ApiDTO dto : apiDTO.getApiList()) {
            Api api = Api.of(dto);
            bulkOperations.insert(api);
            shouldBeExecuted = true;
        }

        List<String> insertedList = new ArrayList<>();
        if (shouldBeExecuted) {
            BulkWriteResult result = bulkOperations.execute();
            InfoLogger.log_info("result = {}", result.getInserts().toString());
            insertedList = result.getInserts().stream()
                    .map(bulkWriteInsert -> bulkWriteInsert.getId().asObjectId().getValue().toString()).collect(Collectors.toList());
        }

        return insertedList;
    }
}
