package com.skhynix.builder.logger;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ApiAccLogger {
    private static final String delimiter = "§";
    public static void api_req_acc_log(String apiName, String params, String body) {
        StringBuilder sb = new StringBuilder();
        String logStr = sb.append("req")
                .append(delimiter)
                .append(apiName)
                .append(delimiter)
                .append(params)
                .append(delimiter)
                .append(body).toString();
        log.info(logStr);
    }

    public static void api_res_acc_log(String apiName, String response) {
        StringBuilder sb = new StringBuilder();
        String logStr = sb.append("res")
                .append(delimiter)
                .append(apiName)
                .append(delimiter)
                .append(response).toString();
        log.info(logStr);
    }

}
