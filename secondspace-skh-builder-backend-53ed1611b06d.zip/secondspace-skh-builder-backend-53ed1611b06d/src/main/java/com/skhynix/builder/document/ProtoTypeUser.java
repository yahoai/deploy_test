package com.skhynix.builder.document;

import com.skhynix.builder.document.embedded.ProtoTypeUserType;
import com.skhynix.builder.dto.user.ProtoTypeUserDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

@Document("proto_type_user")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProtoTypeUser {
    @Id
    private String id;
    @Indexed(unique = true)
    private String userUniqId;
    private String name;
    private ProtoTypeUserType userType;
    private String organization;
    @ApiModelProperty(readOnly = true)
    private Boolean isActiveUser = true;
    private Long createdAt;
    private Long updatedAt;

    public static ProtoTypeUser of(ProtoTypeUserDTO u) {
        long createdAt = System.currentTimeMillis();
        return ProtoTypeUser.builder()
                .userUniqId(u.getEmployeeNumber())
                .name(u.getName())
                .userType(u.getUserType() == null ? ProtoTypeUserType.user : u.getUserType())
                .organization(u.getOrganization())
                .isActiveUser(u.getIsActiveUser() == null || u.getIsActiveUser())
                .createdAt(createdAt)
                .updatedAt(createdAt)
                .build();
    }
}
