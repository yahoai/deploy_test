package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.Api;
import com.skhynix.builder.dto.api.ApiDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageApiRespDTO {
    ApiDTO api;
    Object data;

    public static PageApiRespDTO of(Api api, Object data) {
        return PageApiRespDTO.builder()
                .api(ApiDTO.of(api))
                .data(data)
                .build();
    }
}
