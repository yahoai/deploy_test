package com.skhynix.builder.dto.api;

import com.skhynix.builder.document.Api;
import com.skhynix.builder.dto.validator.DocumentId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApiDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    @NotNull
    @DocumentId
    private String applicationId;
    @NotNull
    private String apiName;
    @NotNull
    private Object type;
    private Object sendData;
    private Object filter;
    private String documentType;
    private Object sort;
    private String connectStoreData;
    private Object method;
    private String key;
    private String componentName;
    @ApiModelProperty(required = true)
    private Long createdAt;
    @ApiModelProperty(required = true)
    private Long updatedAt;

    public static ApiDTO of(Api a) {
        return ApiDTO.builder()
                .id(a.getId())
                .applicationId(a.getApplicationId().toString())
                .type(a.getType())
                .apiName(a.getApiName())
                .sendData(a.getSendData())
                .filter(a.getFilter())
                .sort(a.getSort())
                .method(a.getMethod())
                .documentType(a.getDocumentType())
                .key(a.getKey())
                .componentName(a.getComponentName())
                .connectStoreData(a.getConnectStoreData())
                .build();
    }
}
