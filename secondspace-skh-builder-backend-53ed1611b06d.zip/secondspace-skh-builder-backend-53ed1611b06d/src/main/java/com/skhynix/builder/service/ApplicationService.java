package com.skhynix.builder.service;

import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.document.*;
import com.skhynix.builder.document.embedded.ApplicationManagerType;
import com.skhynix.builder.document.embedded.ApplicationMember;
import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.application.ApplicationDetailDTO;
import com.skhynix.builder.dto.application.ApplicationPatchDTO;
import com.skhynix.builder.dto.application.JoinApplicationDTO;
import com.skhynix.builder.dto.page.PageApiRespDTO;
import com.skhynix.builder.dto.page.PageRespDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.logger.InfoLogger;
import com.skhynix.builder.query.ApplicationQueryService;
import com.skhynix.builder.query.AuthReqQueryService;
import com.skhynix.builder.repository.ApiRepository;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.repository.mongo.AuthorizationRepository;
import com.skhynix.builder.repository.mongo.PageRepository;
import com.skhynix.builder.repository.mongo.ProtoTypeUserRepository;
import com.skhynix.builder.util.CommonUtil;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ApplicationService {
    private ApplicationRepository applicationRepository;
    private ApplicationQueryService applicationQueryService;
    private PageRepository pageRepository;
    private AuthReqQueryService authReqQueryService;
    private ProtoTypeUserRepository protoTypeUserRepository;
    private AuthorizationRepository authorizationRepository;
    private ApiRepository apiRepository;
    private PageResponseService pageResponseService;

    @Autowired
    public void setPageResponseService(PageResponseService pageResponseService) {
        this.pageResponseService = pageResponseService;
    }

    @Autowired
    public void setApiRepository(ApiRepository apiRepository) {
        this.apiRepository = apiRepository;
    }

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Autowired
    public void setProtoTypeUserRepository(ProtoTypeUserRepository protoTypeUserRepository) {
        this.protoTypeUserRepository = protoTypeUserRepository;
    }

    @Autowired
    public void setAuthReqQueryService(AuthReqQueryService authReqQueryService) {
        this.authReqQueryService = authReqQueryService;
    }

    @Autowired
    public void setPageRepository(PageRepository pageRepository) {
        this.pageRepository = pageRepository;
    }

    @Autowired
    public void setApplicationQueryService(ApplicationQueryService applicationQueryService) {
        this.applicationQueryService = applicationQueryService;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    public ApplicationDTO createApplication(UserPrincipal currentUser, ApplicationDTO serviceDTO) throws BuilderException {
        try {
            Long currTime = System.currentTimeMillis();
            Application application = Application.of(serviceDTO,currTime);
            ProtoTypeUser user = protoTypeUserRepository.findById(currentUser.getId())
                    .orElseThrow(() -> new BuilderException(RCode.UNAUTHORIZED));


            ObjectId userObjId = new ObjectId(currentUser.getId());
            application.setOwner(userObjId);

            List<ApplicationMember> members = new ArrayList<>();
            ApplicationMember member = new ApplicationMember();
            member.setUserId(userObjId);
            member.setApplicationManagerType(ApplicationManagerType.OWNER);
            member.setCreatedAt(System.currentTimeMillis());
            members.add(member);

            application.setMembers(members);

            applicationRepository.save(application);
            return ApplicationDTO.of(application, user);
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.APPLICATION_UNIQ_PATH_EXIST, serviceDTO.getUniqPath(), e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<ApplicationDTO> getApplications(UserPrincipal currentUser) throws BuilderException {
        try {
            return applicationQueryService.findMyApplication(currentUser.getId()).stream()
                    .map(app -> {
                        ProtoTypeUser u = null;
                        if(app.getOwner() != null) {
                            u = protoTypeUserRepository.findById(app.getOwner().toString())
                                    .orElse(null);
                        }

                        if(u == null) return ApplicationDTO.of(app);
                        return ApplicationDTO.of(app, u);
                    }).filter(Objects::nonNull).collect(Collectors.toList());

        } catch (Exception e) {
            InfoLogger.log_error(e.getMessage());
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public ApplicationDTO patchApplication(String serviceId, ApplicationPatchDTO dto)  {
        try {
            Application application = applicationRepository.findById(serviceId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, serviceId));

            CommonUtil.changeIfPresent(dto.getTitle(), application::setTitle);
            CommonUtil.changeIfPresent(dto.getUniqPath(), application::setUniqPath);
            CommonUtil.changeIfPresent(dto.getDescription(), application::setDescription);
            CommonUtil.changeIfPresent(dto.getBassAppId(), application::setBassAppId);
            CommonUtil.changeIfPresent(dto.getCustomCss(), application::setCustomCss);
            CommonUtil.changeIfPresent(dto.getFrontData(), application::setFrontData);
            CommonUtil.changeIfPresent(dto.getAllowPermission(), application::setAllowPermission);
            ProtoTypeUser u = null;

            if(application.getOwner() != null) {
                u = protoTypeUserRepository.findById(application.getOwner().toString()).orElse(null);
            }
            application.setUpdatedAt(System.currentTimeMillis());

            if( u == null) return ApplicationDTO.of(applicationRepository.save(application));
            return ApplicationDTO.of(applicationRepository.save(application) , u);
        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.APPLICATION_UNIQ_PATH_EXIST, dto.getUniqPath().get(), e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public ApplicationDetailDTO getApplication(String serviceId) throws BuilderException {
        try {
            Application application = applicationRepository.findById(serviceId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, serviceId));
            ProtoTypeUser u = null;
            if(application.getOwner() != null)
                u = protoTypeUserRepository.findById(application.getOwner().toString()).orElse(null);

            List<Page> pageList = pageRepository.findByApplicationId(new ObjectId(application.getId()));

            List<PageRespDTO> pageRespDTOList = pageList.stream().map(page -> pageResponseService.getPageRespDTO(page))
                    .collect(Collectors.toList());

            if( u == null) return ApplicationDetailDTO.of(application, pageRespDTOList);
            return ApplicationDetailDTO.of(application, u, pageRespDTOList);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void deleteApplication(String applicationId) throws BuilderException {
        try {
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, applicationId));

           applicationRepository.delete(application);
            authReqQueryService.deleteAuthorizationReqByAppId(applicationId);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public ApplicationDTO replaceApplication(String applicationId, ApplicationDTO dto) {
        try {
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND,
                            applicationId));
            Application newApplication = Application.of(dto);
            newApplication.setMembers(application.getMembers());
            newApplication.setCreatedAt(application.getCreatedAt());
            newApplication.setUpdatedAt(System.currentTimeMillis());
            return  ApplicationDTO.of(
                    applicationQueryService.replaceApplication(applicationId, newApplication));
        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.APPLICATION_UNIQ_PATH_EXIST, dto.getUniqPath(), e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void joinApplicationManager(String applicationId, JoinApplicationDTO joinApplicationDTO) throws BuilderException {
        try {
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND,
                            applicationId));

            List<ApplicationMember> applicationMembers = application.getMembers();

            if(applicationMembers == null) applicationMembers = new ArrayList<>();

            boolean exist = applicationMembers.stream()
                    .anyMatch(m -> m.getUserId().toString().equals(joinApplicationDTO.getProtoTypeUserId()));

            if(!exist) {
                ApplicationMember member = new ApplicationMember();
                member.setUserId(new ObjectId(joinApplicationDTO.getProtoTypeUserId()));
                member.setApplicationManagerType(joinApplicationDTO.getApplicationManagerType() == null
                        ? ApplicationManagerType.USER : joinApplicationDTO.getApplicationManagerType());
                member.setCreatedAt(System.currentTimeMillis());

                applicationMembers.add(member);

                applicationRepository.save(application);
            }

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
