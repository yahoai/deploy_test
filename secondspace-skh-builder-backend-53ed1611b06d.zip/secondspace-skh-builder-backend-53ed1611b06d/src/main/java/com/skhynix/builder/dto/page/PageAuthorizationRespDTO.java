package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.embedded.PageAuthorization;
import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageAuthorizationRespDTO {
    private List<AuthorizationDTO> allow;
    private List<AuthorizationDTO> deny;

    public static PageAuthorizationRespDTO of(PageAuthorization pa, Map<String, Authorization> authList) {
        if(pa == null) {
            return null;
        }

        List<AuthorizationDTO> allow = null;
        List<AuthorizationDTO> deny = null;

        if(pa.getAllow() != null) {
            allow = pa.getAllow().stream().map(ObjectId::toString).filter(authList::containsKey)
                    .map(a -> AuthorizationDTO.of(authList.get(a))).collect(Collectors.toList());
        }

        if(pa.getDeny() != null) {
            deny = pa.getDeny().stream().map(ObjectId::toString).filter(authList::containsKey)
                    .map(a -> AuthorizationDTO.of(authList.get(a))).collect(Collectors.toList());
        }


        return PageAuthorizationRespDTO.builder()
                .allow(allow)
                .deny(deny)
                .build();
    }
}
