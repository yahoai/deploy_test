package com.skhynix.builder.dto.user;

import com.skhynix.builder.dto.validator.DocumentId;
import lombok.Data;
import org.openapitools.jackson.nullable.JsonNullable;

import javax.validation.Valid;
import java.util.Set;

@Data
public class UserPatchDTO {
    private JsonNullable<String> name;
    private JsonNullable<Set<@Valid @DocumentId String>> authorizationIdList;
}
