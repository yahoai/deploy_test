package com.skhynix.builder.controller;

import com.skhynix.builder.auth.CurrentUser;
import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.dto.application.ApplicationManagerDTO;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.user.AddApplicationManagerDTO;
import com.skhynix.builder.dto.user.ProtoTypeUserDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.UserService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/application/managers")
@Validated
public class ApplicationManagerController extends BuilderExceptionHandler {
    private UserService userService;

    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @GetMapping
    @ApiOperation(value = "getApplicationManagerList", notes = "어플리케이션 매니저 목록을 반환합니다.")
    public ResponseEntity<ListItemResponse<ApplicationManagerDTO>> getApplicationManagerList(
            @CurrentUser UserPrincipal currentUser,
            @RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        List<ApplicationManagerDTO> response = userService.getApplicationManagerList(applicationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @PostMapping
    @ApiOperation(value = "addApplicationManager", notes = "애플리케이션 매니저로 등록합니다.")
    public ResponseEntity<SingleItemResponse<ApplicationManagerDTO>> addApplicationManager(
            @CurrentUser UserPrincipal currentUser,
            @RequestBody @Valid AddApplicationManagerDTO addApplicationManagerDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", addApplicationManagerDTO.toString());

        ApplicationManagerDTO response = userService.joinApplicationManager(addApplicationManagerDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }
}
