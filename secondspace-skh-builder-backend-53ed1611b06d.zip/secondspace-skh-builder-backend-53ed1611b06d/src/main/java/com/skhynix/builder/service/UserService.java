package com.skhynix.builder.service;

import com.skhynix.builder.auth.UserType;
import com.skhynix.builder.document.*;
import com.skhynix.builder.document.embedded.ApplicationManagerType;
import com.skhynix.builder.document.embedded.ApplicationMember;
import com.skhynix.builder.document.embedded.AuthUpdateActionType;
import com.skhynix.builder.dto.application.ApplicationManagerDTO;
import com.skhynix.builder.dto.user.*;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.property.LoginProperty;
import com.skhynix.builder.repository.mongo.*;
import com.skhynix.builder.util.CommonUtil;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;


import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserService {
    private UserRepository userRepository;
    private ProtoTypeUserRepository protoTypeUserRepository;
    private ApplicationRepository applicationRepository;
    private AuthorizationRepository authorizationRepository;
    private LoginProperty loginProperty;
    private AuthorizationHistoryRepository authorizationHistoryRepository;

    @Autowired
    public void setAuthorizationHistoryRepository(AuthorizationHistoryRepository authorizationHistoryRepository) {
        this.authorizationHistoryRepository = authorizationHistoryRepository;
    }

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Autowired
    public void setLoginProperty(LoginProperty loginProperty) {
        this.loginProperty = loginProperty;
    }

    @Autowired
    public void setProtoTypeUserRepository(ProtoTypeUserRepository protoTypeUserRepository) {
        this.protoTypeUserRepository = protoTypeUserRepository;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Autowired
    public void setBuilderUserRepository(ProtoTypeUserRepository protoTypeUserRepository) {
        this.protoTypeUserRepository = protoTypeUserRepository;
    }

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public JoinUserRespDTO joinApplication(UserDTO userDTO) throws BuilderException {
        try {
            User user = userRepository.findByApplicationIdAndUserUniqId(new ObjectId(userDTO.getApplicationId()), userDTO.getEmployeeNumber());
            Date now = new Date();
            Date expiryDate = new Date(now.getTime() + loginProperty.getAuth().getTokenExpirationMsec());

            if(user == null) {
                user = User.of(userDTO);
                user = userRepository.save(user);
            }


            List<Authorization> authList = new ArrayList<>();
            if(user.getAuthorizations() != null && user.getAuthorizations().size() != 0) {
                List<String> authIdList = user.getAuthorizations().stream()
                        .map(ObjectId::toString).collect(Collectors.toList());
                authList = authorizationRepository.findAllByIdIn(authIdList);
                user.setLastAuthorizationUpdatedAt(System.currentTimeMillis());
                user = userRepository.save(user);

                try {
                    AuthorizationHistory ah = new AuthorizationHistory();
                    ah.setApplicationId(user.getApplicationId());
                    ah.setApplicationUserId(new ObjectId(user.getId()));
                    ah.setActionType(AuthUpdateActionType.update);
                    ah.setPreviousAuthNameList(new ArrayList<>());
                    ah.setNewAuthNameList(authList.stream().map(Authorization::getName).collect(Collectors.toList()));
                    ah.setUpdatedAt(System.currentTimeMillis());

                    authorizationHistoryRepository.save(ah);
                } catch (Exception e) {

                }

            }

            Map<String, Object> userTypeMap = new HashMap<>();
            userTypeMap.put("userType", UserType.application_user.toString());
            String token = Jwts.builder()
                    .setClaims(userTypeMap)
                    .setSubject(user.getId())
                    .setIssuedAt(now)
                    .setExpiration(expiryDate)
                    .signWith(SignatureAlgorithm.HS512, loginProperty.getAuth().getTokenSecret())
                    .compact();

            return JoinUserRespDTO.of(user, authList, token);

        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.EMPLOYEE_NUMBER_ALREADY_EXIST,
                    String.valueOf(userDTO.getEmployeeNumber()), e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public UserRespDTO getApplicationUserInfo(String applicationId, String userId) throws BuilderException {
        try {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new BuilderException(RCode.USER_NOT_EXISTS, userId));
            List<Authorization> authList = new ArrayList<>();
            if(user.getAuthorizations() != null && user.getAuthorizations().size() != 0) {
                List<String> authIdList = user.getAuthorizations().stream()
                        .map(ObjectId::toString).collect(Collectors.toList());
                authList = authorizationRepository.findAllByIdIn(authIdList);
            }
            return UserRespDTO.of(user, authList);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public UserRespDTO patchApplicationUser(String applicationId, String userId, UserPatchDTO userPatchDto) throws BuilderException {
        try {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new BuilderException(RCode.USER_NOT_EXISTS, userId));

            CommonUtil.changeIfPresent(userPatchDto.getName(), user::setName);
            if(userPatchDto.getAuthorizationIdList() != null && userPatchDto.getAuthorizationIdList().isPresent()) {
                if(userPatchDto.getAuthorizationIdList().get() == null) {
                    user.setAuthorizations(null);
                } else {
                    user.setAuthorizations(userPatchDto.getAuthorizationIdList().get().stream()
                            .map(ObjectId::new)
                            .collect(Collectors.toSet()));
                    user.setLastAuthorizationUpdatedAt(System.currentTimeMillis());
                }
            }
            userRepository.save(user);
            List<Authorization> authList = new ArrayList<>();
            if(user.getAuthorizations() != null && user.getAuthorizations().size() != 0) {
                List<String> authIdList = user.getAuthorizations().stream()
                        .map(ObjectId::toString).collect(Collectors.toList());
                authList = authorizationRepository.findAllByIdIn(authIdList);

                try {
                    AuthorizationHistory ah = new AuthorizationHistory();
                    ah.setApplicationId(user.getApplicationId());
                    ah.setApplicationUserId(new ObjectId(user.getId()));
                    ah.setActionType(AuthUpdateActionType.update);
                    ah.setPreviousAuthNameList(new ArrayList<>());
                    ah.setNewAuthNameList(authList.stream().map(Authorization::getName).collect(Collectors.toList()));
                    ah.setUpdatedAt(System.currentTimeMillis());

                    authorizationHistoryRepository.save(ah);
                } catch (Exception e) {

                }
            }

            return UserRespDTO.of(user, authList);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<UserRespDTO> getUserList(String appId) throws BuilderException {
        try {
            ObjectId appObjectId = new ObjectId(appId);
            List<User> users = userRepository.findAllByApplicationId(appObjectId);
            Map<ObjectId, Authorization> authCache = new HashMap<>();
            return users.stream().map(u -> {
                List<Authorization> auth = new ArrayList<>();
                if(u.getAuthorizations() != null) {
                    u.getAuthorizations().forEach(authId -> {
                        if (authCache.containsKey(authId)) {
                            auth.add(authCache.get(authId));
                        } else {
                            Authorization a = authorizationRepository.findById(authId.toString()).orElse(null);
                            if (a != null) {
                                auth.add(a);
                                authCache.put(authId, a);
                            }
                        }
                    });
                }
                return UserRespDTO.of(u, auth);
            }).collect(Collectors.toList());

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public JoinProtoTypeUserRespDTO joinProtoTypeUser(ProtoTypeUserDTO userDTO) {
        try {
            ProtoTypeUser user = protoTypeUserRepository.findByUserUniqId(userDTO.getEmployeeNumber());
            Date now = new Date();
            Date expiryDate = new Date(now.getTime() + loginProperty.getAuth().getTokenExpirationMsec());

            String token;

            if (user == null) {
                user = ProtoTypeUser.of(userDTO);
                user = protoTypeUserRepository.save(user);

            }

            Map<String, Object> userTypeMap = new HashMap<>();
            userTypeMap.put("userType", UserType.prototype_user.toString());
            token = Jwts.builder()
                    .setClaims(userTypeMap)
                    .setSubject(user.getId())
                    .setIssuedAt(now)
                    .setExpiration(expiryDate)
                    .signWith(SignatureAlgorithm.HS512, loginProperty.getAuth().getTokenSecret())
                    .compact();

            return JoinProtoTypeUserRespDTO.of(user, token);

        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.EMPLOYEE_NUMBER_ALREADY_EXIST,
                    String.valueOf(userDTO.getEmployeeNumber()), e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<ApplicationManagerDTO> getApplicationManagerList(String applicationId) {
        try {
            Application app = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, applicationId));

            List<ApplicationMember> members = app.getMembers();

            return members.stream()
                    .map(m -> {
                        ProtoTypeUser bu = protoTypeUserRepository.findById(m.getUserId().toString()).orElse(null);
                        if(bu == null)
                            return null;

                        return ApplicationManagerDTO.of(m, bu);
                    })
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public ApplicationManagerDTO joinApplicationManager(AddApplicationManagerDTO req) {
        try {
            Application app = applicationRepository.findById(req.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, req.getApplicationId()));
            ProtoTypeUser user = protoTypeUserRepository.findById(req.getProtoTypeUserId())
                    .orElseThrow(() -> new BuilderException(RCode.USER_NOT_EXISTS, req.getProtoTypeUserId()));

            List<ApplicationMember> members = app.getMembers();
            ObjectId protoTypeUserId = new ObjectId(req.getProtoTypeUserId());
            final ApplicationMember[] findMember = new ApplicationMember[1];
            boolean exist = members.stream()
                    .anyMatch(member -> {
                        findMember[0] = member;
                        return member.getUserId().equals(protoTypeUserId);
                    });
            ApplicationMember am;
            if(!exist) {
                am = new ApplicationMember();
                am.setUserId(new ObjectId(req.getProtoTypeUserId()));
                am.setApplicationManagerType(req.getType() == null ? ApplicationManagerType.USER : req.getType());
                am.setCreatedAt(System.currentTimeMillis());
                members.add(am);

                applicationRepository.save(app);
            } else {
                am = findMember[0];
            }

            return ApplicationManagerDTO.of(am, user);

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<ProtoTypeUserDTO> getProtoTypeUsers() throws BuilderException {
        try {
            return protoTypeUserRepository.findAll().stream()
                    .map(ProtoTypeUserDTO::of).collect(Collectors.toList());
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
