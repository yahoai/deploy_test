package com.skhynix.builder.controller;

import com.skhynix.builder.dto.authorization.*;
import com.skhynix.builder.dto.common.EmptyResponse;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.page.AuthorizationListDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.AuthorizationRequestService;
import com.skhynix.builder.service.AuthorizationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Email;
import java.util.List;

@RestController
@RequestMapping("/authorizations")
@Validated
public class AuthorizationController extends BuilderExceptionHandler {
    private AuthorizationService authorizationService;
    private AuthorizationRequestService authorizationRequestService;

    @Autowired
    public void setAuthorizationRequestService(AuthorizationRequestService authorizationRequestService) {
        this.authorizationRequestService = authorizationRequestService;
    }
    @Autowired
    public void setAuthorizationService(AuthorizationService authorizationService) {
        this.authorizationService = authorizationService;
    }

    @PostMapping
    public ResponseEntity<ListItemResponse<AuthorizationDTO>> setAuthorization(
            @Valid @RequestBody AuthorizationListDTO dto) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", dto.toString());

        List<AuthorizationDTO> response = authorizationService.setAuthorization(dto);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @GetMapping
    public ResponseEntity<ListItemResponse<AuthorizationDTO>> getAuthList(
           @RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        List<AuthorizationDTO> response = authorizationService.getAuthList(applicationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @GetMapping("/{authorizationId}")
    public ResponseEntity<SingleItemResponse<AuthorizationDTO>> getAuthorization(
            @PathVariable @DocumentId String authorizationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, authorizationId, "");

        AuthorizationDTO response = authorizationService.getAuthorization(authorizationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    //@PatchMapping("/{authorizationId}")
    public ResponseEntity<SingleItemResponse<AuthorizationDTO>> patchAuthorization(
            @PathVariable @DocumentId String authorizationId,
            @RequestBody @Valid AuthorizationPatchDTO authorizationDTO) throws BuilderException {
        return ResponseEntity.ok(SingleItemResponse.create(
                authorizationService.patchAuthorization(authorizationId, authorizationDTO)
        ));
    }

    //@PutMapping("/{authorizationId}")
    public ResponseEntity<SingleItemResponse<AuthorizationDTO>> replaceAuthorization(
            @PathVariable String authorizationId,
            @RequestBody AuthorizationDTO authorizationDTO) throws BuilderException {
        return ResponseEntity.ok(SingleItemResponse.create(
                authorizationService.replaceAuthorization(authorizationId, authorizationDTO)
        ));
    }

    //@DeleteMapping("/{authorizationId}")
    public ResponseEntity<EmptyResponse> deleteAuthorization(
            @PathVariable @DocumentId String authorizationId) throws BuilderException {

        authorizationService.deleteAuthorization(authorizationId);
        return ResponseEntity.ok(EmptyResponse.create());
    }

    @PostMapping("/authorizationRequest")
    public ResponseEntity<SingleItemResponse<AuthorizationReqRespDTO>> requestAuthorization(
            @RequestBody AuthorizationReqDTO authReqDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", authReqDTO.toString());

        AuthorizationReqRespDTO response = authorizationRequestService.createAuthRequest(authReqDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }
    @GetMapping("/authorizationRequest")
    public ResponseEntity<ListItemResponse<AuthorizationReqRespDTO>> getAuthorizationReqList(
            @RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        List<AuthorizationReqRespDTO> response = authorizationRequestService.getAuthorizationReqList(applicationId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @PostMapping("/authorizationRequest/accept")
    public ResponseEntity<EmptyResponse> acceptAuthorizationRequest(
            @RequestBody AuthorizationReqListDTO authReqDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", authReqDTO.toString());

        authorizationRequestService.acceptAuthorizationRequest(authReqDTO);
        return ResponseEntity.ok(EmptyResponse.create());
    }

    @GetMapping("/history")
    public ResponseEntity<ListItemResponse<AuthorizationHistoryDTO>> getAuthHistory(
            @RequestParam @DocumentId String applicationId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        List<AuthorizationHistoryDTO> response = authorizationService.getHistory(applicationId);
        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @PostMapping("/authorizationRequest/deny")
    public ResponseEntity<EmptyResponse> denyAuthorizationRequest(
            @RequestBody AuthorizationReqListDTO authReqDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", authReqDTO.toString());

        authorizationRequestService.denyAuthorizationRequest(authReqDTO);
        return ResponseEntity.ok(EmptyResponse.create());
    }
}
