package com.skhynix.builder.service;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.AuthorizationHistory;
import com.skhynix.builder.document.User;
import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import com.skhynix.builder.dto.authorization.AuthorizationHistoryDTO;
import com.skhynix.builder.dto.authorization.AuthorizationPatchDTO;
import com.skhynix.builder.dto.page.AuthorizationListDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.query.AuthReqQueryService;
import com.skhynix.builder.query.AuthorizationQueryService;
import com.skhynix.builder.query.UserQueryService;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.repository.mongo.AuthorizationHistoryRepository;
import com.skhynix.builder.repository.mongo.AuthorizationRepository;
import com.skhynix.builder.repository.mongo.UserRepository;
import com.skhynix.builder.util.CommonUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class AuthorizationService {
    private AuthorizationRepository authorizationRepository;
    private AuthorizationQueryService authorizationQueryService;
    private ApplicationRepository applicationRepository;
    private AuthReqQueryService authReqQueryService;
    private UserQueryService userQueryService;
    private AuthorizationHistoryRepository authorizationHistoryRepository;
    private UserRepository userRepository;

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Autowired
    public void setAuthorizationHistoryRepository(AuthorizationHistoryRepository authorizationHistoryRepository) {
        this.authorizationHistoryRepository = authorizationHistoryRepository;
    }

    @Autowired
    public void setUserQueryService(UserQueryService userQueryService) {
        this.userQueryService = userQueryService;
    }

    @Autowired
    public void setAuthReqQueryService(AuthReqQueryService authReqQueryService) {
        this.authReqQueryService = authReqQueryService;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Autowired
    public void setAuthorizationQueryService(AuthorizationQueryService authorizationQueryService) {
        this.authorizationQueryService = authorizationQueryService;
    }

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    public List<AuthorizationDTO> setAuthorization(AuthorizationListDTO dto) throws BuilderException {
        try {
            Application application = applicationRepository.findById(dto.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, dto.getApplicationId()));

            userQueryService.bulkWriteAuthorization(dto);

            return authorizationRepository.findAllByApplicationId(new ObjectId(dto.getApplicationId()))
                    .stream().map(AuthorizationDTO::of).collect(Collectors.toList());

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public AuthorizationDTO patchAuthorization(String id,
                                               AuthorizationPatchDTO authorizationDTO) throws BuilderException {
        try {
            Authorization auth = authorizationRepository.findById(id)
                    .orElseThrow(() -> new BuilderException(RCode.AUTHORIZATION_NOT_FOUND, id));

            CommonUtil.changeIfPresent(authorizationDTO.getName(), auth::setName);
            CommonUtil.changeIfPresent(authorizationDTO.getDescription(), auth::setDescription);

            Application application = applicationRepository.findById(auth.getApplicationId().toString())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, auth.getApplicationId().toString()));

            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            return AuthorizationDTO.of(authorizationRepository.save(auth));
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public AuthorizationDTO replaceAuthorization(String authorizationId,
                                       AuthorizationDTO authorizationDTO) throws BuilderException {
        try {
            Authorization auth = authorizationRepository.findById(authorizationId)
                    .orElseThrow(() -> new BuilderException(RCode.AUTHORIZATION_NOT_FOUND, authorizationId));
            Authorization newAuth = Authorization.of(authorizationDTO);

            Application application = applicationRepository.findById(auth.getApplicationId().toString())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, auth.getApplicationId().toString()));

            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            return AuthorizationDTO.of(authorizationQueryService.replaceAuthorization(authorizationId, newAuth));
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void deleteAuthorization(String authorizationId)  throws BuilderException {
        try {
            Authorization auth = authorizationRepository.findById(authorizationId)
                    .orElseThrow(() -> new BuilderException(RCode.AUTHORIZATION_NOT_FOUND, authorizationId));

            Application application = applicationRepository.findById(auth.getApplicationId().toString())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, auth.getApplicationId().toString()));

            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            authorizationRepository.delete(auth);
            authReqQueryService.deleteAuthorizationReqByAuthId(authorizationId);

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }


    public List<AuthorizationDTO> getAuthList(String applicationId) throws BuilderException {
        try {
            return authorizationRepository.findAllByApplicationId(new ObjectId(applicationId)).stream()
                    .map(AuthorizationDTO::of).collect(Collectors.toList());

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public AuthorizationDTO getAuthorization(String authorizationId) throws BuilderException {
        try {
            Authorization authorization = authorizationRepository.findById(authorizationId)
                    .orElseThrow(() -> new BuilderException(RCode.AUTHORIZATION_NOT_FOUND, authorizationId));

            return AuthorizationDTO.of(authorization);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public List<AuthorizationHistoryDTO> getHistory(String applicationId) throws BuilderException {
        try {
            Application application = applicationRepository.findById(applicationId)
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, applicationId));
            List<AuthorizationHistory> result = authorizationHistoryRepository
                    .findByApplicationIdOrderByUpdatedAtDesc(new ObjectId((applicationId)));

            return result.stream().map(ah -> {
                User user = userRepository.findById(ah.getApplicationUserId().toString()).orElse(null);
                if(user == null) {
                    return null;
                }

                return AuthorizationHistoryDTO.of(ah, user);
            }).filter(Objects::nonNull).collect(Collectors.toList());
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }
}
