package com.skhynix.builder.controller;

import com.skhynix.builder.auth.CurrentUser;
import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.document.Application;
import com.skhynix.builder.dto.application.ApplicationDTO;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.user.ProtoTypeUserDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.ApplicationService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/callback")
public class CallbackController extends BuilderExceptionHandler {
    private ApplicationService applicationService;

    @Autowired
    public void setApplicationService(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @PostMapping("/applications")
    public ResponseEntity<SingleItemResponse<ApplicationDTO>> createApplication(
            @CurrentUser UserPrincipal currentUser,
            @RequestBody @Valid ApplicationDTO applicationDTO) throws BuilderException {

        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", applicationDTO.toString());
        ApplicationDTO response = applicationService.createApplication(currentUser, applicationDTO);

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }
}
