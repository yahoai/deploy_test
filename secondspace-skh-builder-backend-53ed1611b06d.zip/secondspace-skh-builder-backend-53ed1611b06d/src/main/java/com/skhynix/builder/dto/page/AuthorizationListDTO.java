package com.skhynix.builder.dto.page;

import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Valid
public class AuthorizationListDTO {
   @NotNull
   @DocumentId
   private String applicationId;
   @Valid
   private List<AuthorizationDTO> authorizations;
}
