package com.skhynix.builder.dto.authorization;

import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.dto.validator.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Valid
public class AuthorizationDTO {
    @DocumentId
    private String id;
    @DocumentId
    private String applicationId;
    private String name;
    private Boolean needReason;
    private Boolean allowAuthRequest;
    private String title;
    private String placeHolder;
    @NotNull
    private String fid;
    private String description;

    public static AuthorizationDTO of(Authorization a) {
        return AuthorizationDTO.builder()
                .id(a.getId())
                .name(a.getName())
                .applicationId(a.getApplicationId().toString())
                .description(a.getDescription())
                .needReason(a.getNeedReason() != null && a.getNeedReason())
                .allowAuthRequest(a.getAllowAuthRequest() == null || a.getAllowAuthRequest())
                .fid(a.getFid())
                .title(a.getTitle())
                .placeHolder(a.getPlaceHolder())
                .build();
    }
}
