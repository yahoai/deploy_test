package com.skhynix.builder.dto.user;

import com.skhynix.builder.document.ProtoTypeUser;
import com.skhynix.builder.document.embedded.ProtoTypeUserType;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProtoTypeUserDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    @NotNull
    private String employeeNumber;
    private String name;
    private ProtoTypeUserType userType;
    private String organization;
    @ApiModelProperty(readOnly = true)
    private Boolean isActiveUser;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    @ApiModelProperty(readOnly = true)
    private Long updatedAt;

    public static ProtoTypeUserDTO of(ProtoTypeUser u) {

        return ProtoTypeUserDTO.builder()
                .id(u.getId())
                .employeeNumber(u.getUserUniqId())
                .name(u.getName())
                .isActiveUser(u.getIsActiveUser() == null || u.getIsActiveUser())
                .organization(u.getOrganization())
                .userType(u.getUserType() == null ? ProtoTypeUserType.user: u.getUserType())
                .createdAt(u.getCreatedAt())
                .updatedAt(u.getUpdatedAt() != null ? u.getUpdatedAt() : u.getCreatedAt())
                .build();
    }
}
