package com.skhynix.builder.dto.authorization;

import com.skhynix.builder.document.AuthorizationHistory;
import com.skhynix.builder.document.User;
import com.skhynix.builder.document.embedded.AuthUpdateActionType;
import com.skhynix.builder.dto.user.UserRespDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthorizationHistoryDTO {
    private String id;
    private UserRespDTO user;
    private AuthUpdateActionType type;
    private List<String> previousAuthList;
    private List<String> newAuthList;
    private Long updatedAt;

    public static AuthorizationHistoryDTO of(AuthorizationHistory ah, User user) {
        return AuthorizationHistoryDTO.builder()
                .id(ah.getId())
                .previousAuthList(ah.getPreviousAuthNameList())
                .newAuthList(ah.getNewAuthNameList())
                .user(UserRespDTO.of(user, null))
                .updatedAt(ah.getUpdatedAt())
                .build();
    }
}
