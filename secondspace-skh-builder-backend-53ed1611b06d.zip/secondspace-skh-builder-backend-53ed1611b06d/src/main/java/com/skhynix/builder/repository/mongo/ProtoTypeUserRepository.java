package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.ProtoTypeUser;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProtoTypeUserRepository extends MongoRepository<ProtoTypeUser, String> {
    ProtoTypeUser findByUserUniqId(String userUniqId);
}
