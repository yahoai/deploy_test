package com.skhynix.builder.document;

import com.skhynix.builder.document.embedded.ApplicationMember;
import com.skhynix.builder.dto.application.ApplicationDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import java.util.List;
import java.util.Set;

@Document("application")
@Data
@Builder
@CompoundIndex(def = "{'members.userId':1}")
@AllArgsConstructor
@NoArgsConstructor
public class Application {
    @Id
    private String id;
    @Indexed(unique = true, partialFilter = "{ emmpApplicationId : { $exists : true } }")
    private String emmpApplicationId;
    @Indexed(unique = true)
    private String uniqPath;
    private String title;
    private String bassAppId;
    private String description;
    //ProtoTypeUser Id
    @Indexed
    private ObjectId owner;
    private List<ApplicationMember> members;
    private Object customCss;
    private Object frontData;
    private Long createdAt;
    private Boolean allowPermission;
    private MasterPage masterPage;
    @Indexed
    private Long updatedAt;

    public static Application of(ApplicationDTO dto) {
        return Application.builder()
                .uniqPath(dto.getUniqPath())
                .title(dto.getTitle())
                .bassAppId(dto.getBassAppId())
                .description(dto.getDescription())
                .allowPermission(dto.getAllowPermission() != null ? dto.getAllowPermission() : true)
                .build();
    }

    public static Application of(ApplicationDTO dto, Long currTime) {

        return Application.builder()
                .uniqPath(dto.getUniqPath())
                .title(dto.getTitle())
                .bassAppId(dto.getBassAppId())
                .description(dto.getDescription())
                .customCss(dto.getCustomCss())
                .frontData(dto.getFrontData())
                .allowPermission(dto.getAllowPermission() != null ? dto.getAllowPermission() : true)
                .createdAt(currTime)
                .updatedAt(currTime)
                .build();
    }
}
