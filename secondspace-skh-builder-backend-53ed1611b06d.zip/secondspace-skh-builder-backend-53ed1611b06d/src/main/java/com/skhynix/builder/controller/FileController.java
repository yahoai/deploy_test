package com.skhynix.builder.controller;

import com.skhynix.builder.auth.CurrentUser;
import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.dto.common.EmptyResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.file.FileDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.service.FileUploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLConnection;

@RestController
@RequestMapping("/files")
public class FileController extends BuilderExceptionHandler {
    private FileUploadService fileUploadService;

    @Autowired
    public void setFileUploadService(FileUploadService fileUploadService) {
        this.fileUploadService = fileUploadService;
    }

    @PostMapping
    public ResponseEntity<SingleItemResponse<FileDTO>> uploadFile(
            @RequestParam @DocumentId String applicationId,
            @RequestParam("file") MultipartFile file) throws BuilderException {


        return ResponseEntity.ok(SingleItemResponse.create(
                fileUploadService.uploadFile(applicationId, file)
        ));
    }

    @GetMapping("/{fileName}")
    public ResponseEntity<Resource> uploadImages(@CurrentUser UserPrincipal currentUser,
                                                 @PathVariable String fileName) {
        try {

            return fileUploadService.getFile(currentUser, fileName);

        } catch (Exception e) {
            return null;
        }
    }
}
