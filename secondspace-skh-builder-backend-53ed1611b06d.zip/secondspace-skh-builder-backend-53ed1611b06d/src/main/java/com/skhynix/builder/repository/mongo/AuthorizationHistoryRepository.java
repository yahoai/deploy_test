package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.AuthorizationHistory;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface AuthorizationHistoryRepository extends MongoRepository<AuthorizationHistory, String> {
    List<AuthorizationHistory> findByApplicationIdOrderByUpdatedAtDesc(ObjectId appicationId) ;
}
