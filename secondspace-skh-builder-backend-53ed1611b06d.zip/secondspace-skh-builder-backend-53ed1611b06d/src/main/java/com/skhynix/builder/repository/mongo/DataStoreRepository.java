package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.DataStore;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface DataStoreRepository extends MongoRepository<DataStore, String> {
    List<DataStore> findAllByApplicationId(ObjectId appId);
    int deleteAllByIdIn(List<ObjectId> idList);
}
