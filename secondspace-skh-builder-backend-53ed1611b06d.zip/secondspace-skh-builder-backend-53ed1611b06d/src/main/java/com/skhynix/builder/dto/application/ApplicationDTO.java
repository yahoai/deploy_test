package com.skhynix.builder.dto.application;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.ProtoTypeUser;
import com.skhynix.builder.dto.user.ProtoTypeUserDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    private String emmpApplicationId;
    @NotNull
    private String uniqPath;
    @NotNull
    private String title;
    private String bassAppId;
    private String description;
    @ApiModelProperty(readOnly = true)
    private ProtoTypeUserDTO owner;
    @ApiModelProperty(readOnly = true)
    private Long numberOfMember;
    private Object customCss;
    private Object frontData;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    private Boolean allowPermission;
    @Indexed(direction = IndexDirection.DESCENDING)
    @ApiModelProperty(readOnly = true)
    private Long updatedAt;

    public static ApplicationDTO of(Application app, ProtoTypeUser owner) {
        return ApplicationDTO.builder()
                .id(app.getId())
                .uniqPath(app.getUniqPath())
                .title(app.getTitle())
                .bassAppId(app.getBassAppId())
                .description(app.getDescription())
                .customCss(app.getCustomCss())
                .owner(owner != null ? ProtoTypeUserDTO.of(owner) : null)
                .numberOfMember((app.getMembers() == null ? 0L : app.getMembers().size()))
                .allowPermission(app.getAllowPermission() != null ? app.getAllowPermission() : true)
                .frontData(app.getFrontData())
                .createdAt(app.getCreatedAt())
                .updatedAt(app.getUpdatedAt())
                .build();
    }

    public static ApplicationDTO of(Application app) {
        return ApplicationDTO.builder()
                .id(app.getId())
                .uniqPath(app.getUniqPath())
                .title(app.getTitle())
                .bassAppId(app.getBassAppId())
                .description(app.getDescription())
                .allowPermission(app.getAllowPermission() != null ? app.getAllowPermission() : true)
                .customCss(app.getCustomCss())
                .createdAt(app.getCreatedAt())
                .updatedAt(app.getUpdatedAt())
                .build();
    }
}
