package com.skhynix.builder.controller;

import com.skhynix.builder.auth.CurrentUser;
import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.dto.common.EmptyResponse;
import com.skhynix.builder.dto.common.ListItemResponse;
import com.skhynix.builder.dto.common.SingleItemResponse;
import com.skhynix.builder.dto.page.PageCheckRespDTO;
import com.skhynix.builder.dto.page.PageDTO;
import com.skhynix.builder.dto.page.PagePatchDTO;
import com.skhynix.builder.dto.page.PageRespDTO;
import com.skhynix.builder.dto.validator.DocumentId;
import com.skhynix.builder.logger.ApiAccLogger;
import com.skhynix.builder.service.PageService;
import com.skhynix.builder.exception.BuilderException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/pages")
@Validated
public class PageController extends BuilderExceptionHandler {
    private PageService pageService;

    @Autowired
    public void setPageService(PageService pageService) {
        this.pageService = pageService;
    }

    @PostMapping
    public ResponseEntity<SingleItemResponse<PageRespDTO>> createPage(
            @Valid @RequestBody PageDTO pageDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, "", pageDTO.toString());

        PageRespDTO response = pageService.createPage(pageDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @GetMapping
    public ResponseEntity<ListItemResponse<PageRespDTO>> getPages(
            @RequestParam(required = false) @DocumentId String applicationId,
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String applicationTitle,
            @RequestParam(required = false) String applicationUniqPath,
            @RequestParam(required = false) String pageUrl,
            @RequestParam(required = false) @DocumentId String componentId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        Map<String, Object> param = new HashMap<>();
        param.put("title", title);
        param.put("applicationTitle", applicationTitle);
        param.put("applicationUniqPath", applicationUniqPath);
        param.put("pageUrl", pageUrl);
        param.put("componentId", componentId);

        ApiAccLogger.api_req_acc_log(functionName, param.toString(), "");
        List<PageRespDTO> response = pageService.getPages(applicationId, title, applicationTitle, applicationUniqPath, pageUrl, componentId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(ListItemResponse.create(response));
    }

    @GetMapping("/{pageId}")
    public ResponseEntity<SingleItemResponse<PageRespDTO>> getPage(
            @PathVariable @DocumentId String pageId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, pageId, "");

        PageRespDTO response = pageService.getPage(pageId);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PatchMapping("/{pageId}")
    public ResponseEntity<SingleItemResponse<PageRespDTO>> patchPage(
            @PathVariable @DocumentId String pageId,
            @RequestBody @Valid PagePatchDTO pagePatchDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, pageId, pagePatchDTO.toString());

        PageRespDTO response = pageService.patchPage(pageId, pagePatchDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());
        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PutMapping("/{pageId}")
    public ResponseEntity<SingleItemResponse<PageRespDTO>> replacePage(
            @PathVariable @DocumentId String pageId,
            @RequestBody @Valid PageDTO pageDTO) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, pageId, pageDTO.toString());

        PageRespDTO response = pageService.replacePage(pageId, pageDTO);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @PostMapping("/publish")
    public ResponseEntity<EmptyResponse> publishPage(
            @CurrentUser UserPrincipal currentUser,
            @RequestParam @DocumentId String applicationId) throws BuilderException {

        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, applicationId, "");

        pageService.publishPage(applicationId);

        return ResponseEntity.ok(EmptyResponse.create());

    }

    @GetMapping("/pageCheck")
    public ResponseEntity<SingleItemResponse<PageCheckRespDTO>> pageCheck(
            @CurrentUser UserPrincipal userPrincipal,
            @RequestParam(required = false) Integer target,
            @RequestParam String applicationUniqPath,
            @RequestParam String pageUrl) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        Map<String, Object> param = new HashMap<>();
        param.put("target", target);
        param.put("applicationUniqPate", applicationUniqPath);
        param.put("pageUrl", pageUrl);
        ApiAccLogger.api_req_acc_log(functionName, param.toString(), "");

        PageCheckRespDTO response = pageService.pageCheck(userPrincipal, target, applicationUniqPath, pageUrl);

        ApiAccLogger.api_res_acc_log(functionName, response.toString());

        return ResponseEntity.ok(SingleItemResponse.create(response));
    }

    @DeleteMapping("{pageId}")
    public ResponseEntity<EmptyResponse> deletePage(
            @PathVariable @DocumentId String pageId) throws BuilderException {
        String functionName = new Object(){}.getClass().getEnclosingMethod().getName();
        ApiAccLogger.api_req_acc_log(functionName, pageId, "");

        pageService.deletePage(pageId);
        return ResponseEntity.ok(EmptyResponse.create());
    }
}
