package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.AuthorizationRequest;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface AuthorizationRequestRepository extends MongoRepository<AuthorizationRequest, String> {
    List<AuthorizationRequest> findAllByApplicationIdOrderByIdDesc(ObjectId applicationId);
    AuthorizationRequest findByApplicationIdAndApplicationUserIdAndAuthorizationId(
            ObjectId applicationId, ObjectId applicationUserId, ObjectId authorizationId);
}
