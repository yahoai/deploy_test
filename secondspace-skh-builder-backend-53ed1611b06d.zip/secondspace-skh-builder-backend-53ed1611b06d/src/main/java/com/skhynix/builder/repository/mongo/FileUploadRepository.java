package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.FileUpload;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FileUploadRepository extends MongoRepository<FileUpload, String> {
}
