package com.skhynix.builder.controller.interceptor;

import com.skhynix.builder.exception.BuilderException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

@Slf4j
@Service
public class ApiInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws BuilderException {
        MDC.put("requestURI", request.getMethod() + " " + request.getRequestURI());
        String requestId = request.getParameter("requestId");
        if(requestId == null) {
            requestId = UUID.randomUUID().toString();
        }
        MDC.put("requestId", requestId);
        MDC.put("userId", request.getRemoteUser());

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws BuilderException {
        MDC.put("status", String.valueOf(response.getStatus()));
        log.info("");
        MDC.remove("requestURI");
        MDC.remove("requestId");
        MDC.remove("userId");
        MDC.remove("status");

    }

}
