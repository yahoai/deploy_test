package com.skhynix.builder.query;

import com.mongodb.MongoBulkWriteException;
import com.mongodb.bulk.BulkWriteResult;
import com.skhynix.builder.document.DataStore;
import com.skhynix.builder.document.Page;
import com.skhynix.builder.dto.datastore.DataStoreDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.repository.mongo.DataStoreRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.BulkOperationException;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.FindAndReplaceOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class DataStoreQueryService {
    private MongoTemplate mongoTemplate;
    private DataStoreRepository dataStoreRepository;

    @Autowired
    public void setDataStoreRepository(DataStoreRepository dataStoreRepository) {
        this.dataStoreRepository = dataStoreRepository;
    }

    @Autowired
    public void setMongoTemplate(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    @Transactional
    public int bulkWriteDataStore4Upsert(String appId, List<DataStoreDTO> dataStoreDTOs) throws BuilderException {
        try {
            ObjectId appObjectId = new ObjectId(appId);
            boolean shouldBeExecuted = false;

            BulkOperations bulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.ORDERED, DataStore.class);
            Set<String> dataStoreList = dataStoreRepository.findAllByApplicationId(appObjectId).stream()
                    .map(DataStore::getId).collect(Collectors.toSet());
            Set<String> dataStoreParamList= dataStoreDTOs.stream()
                    .map(DataStoreDTO::getId).collect(Collectors.toSet());

            //Check to be removed!!
            for(String id : dataStoreList) {
                if(!dataStoreParamList.contains(id)) {
                    Query query = new Query();
                    Criteria criteria = Criteria.where("id").is(id);
                    query.addCriteria(criteria);
                    bulkOperations.remove(query);
                    shouldBeExecuted = true;
                }
            }

            for(DataStoreDTO dto : dataStoreDTOs) {
                if(dto.getId() != null) {
                    DataStore dataStore = dataStoreRepository.findById(dto.getId())
                            .orElseThrow(() -> new BuilderException(RCode.DATA_STORE_NOT_EXIST, dto.getId()));
                    Query query = new Query();

                    Criteria criteria = Criteria.where("id").is(dto.getId());

                    Update update = new Update()
                            .set("applicationId", appObjectId)
                            .set("keyName", dto.getKeyName())
                            .set("className", dto.getClassName())
                            .set("use", dto.getUse())
                            .set("fid", dto.getFid())
                            .set("edit", dto.getEdit());
                    query.addCriteria(criteria);
                    bulkOperations.updateOne(query, update);
                    shouldBeExecuted = true;
                } else {
                    DataStore dataStore = DataStore.of(appId, dto);
                    bulkOperations.insert(dataStore);
                    shouldBeExecuted = true;
                }
            }

            if (shouldBeExecuted) bulkOperations.execute();

            return 0;
        } catch (BulkOperationException e) {
            throw new BuilderException(RCode.DATA_STORE_KEY_EXIST, e);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    @Transactional
    public List<DataStore> bulkWriteDataStore4Create(String appId, List<DataStoreDTO> dataStoreDTOs) throws BuilderException {
        try {
            ObjectId appObjectId = new ObjectId(appId);
            boolean shouldBeExecuted = false;

            BulkOperations bulkOperations = mongoTemplate.bulkOps(BulkOperations.BulkMode.ORDERED, DataStore.class);


            for(DataStoreDTO dto : dataStoreDTOs) {
                DataStore dataStore = DataStore.of(appId, dto);
                bulkOperations.insert(dataStore);
                shouldBeExecuted = true;
            }

            List<DataStore> insertedList = new ArrayList<>();
            if (shouldBeExecuted) {
                BulkWriteResult result = bulkOperations.execute();
                insertedList = result.getInserts().stream()
                        .map(bulkWriteInsert -> {
                            String id = bulkWriteInsert.getId().asObjectId().getValue().toString();
                            DataStore ds = dataStoreRepository.findById(id).orElse(null);
                            return ds;
                        }).filter(Objects::nonNull).collect(Collectors.toList());
            }

            return insertedList;

        } catch (BulkOperationException e) {
            throw new BuilderException(RCode.DATA_STORE_KEY_EXIST, e);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public DataStore replaceDataStore(String dataStoreId, DataStore newDataStore) {
        Query query = new Query();

        Criteria criteria = Criteria.where("id").is(dataStoreId);
        query.addCriteria(criteria);

        FindAndReplaceOptions options = new FindAndReplaceOptions().returnNew();

       return mongoTemplate.findAndReplace(query, newDataStore, options);
    }
}
