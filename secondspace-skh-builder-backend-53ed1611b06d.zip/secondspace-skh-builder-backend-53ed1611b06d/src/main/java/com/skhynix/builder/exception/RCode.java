package com.skhynix.builder.exception;

import org.springframework.http.HttpStatus;

public enum RCode {
    OK(100000, "OK", HttpStatus.OK),

    // Common Validation
    HEADER_REQUIRED     (101001, "Parameter '%s' required", HttpStatus.BAD_REQUEST),
    HEADER_INVALID      (101002, "Header '%s' invalid", HttpStatus.BAD_REQUEST),
    PARAMETER_REQUIRED  (101011, "Parameter '%s' required", HttpStatus.BAD_REQUEST),
    PARAMETER_INVALID   (101012, "Parameter '%s' invalid", HttpStatus.BAD_REQUEST),
    PARAMETER_INVALID_W_ANY(101012, "%s", HttpStatus.BAD_REQUEST),
    BODY_REQUIRED       (101021, "Body '%s' required", HttpStatus.BAD_REQUEST),
    BODY_INVALID        (101022, "Body '%s' invalid", HttpStatus.BAD_REQUEST),

    HTTP_METHOD_NOT_ALLOWED        (101024, "Method Not Allowed", HttpStatus.METHOD_NOT_ALLOWED),
    JSON_PARSE_ERROR (101025, "JSON PARSE ERROR", HttpStatus.BAD_REQUEST),
    MEDIA_TYPE_NOT_SUPPORTED (101025, "Media type not supported", HttpStatus.BAD_REQUEST),
    MAX_FILE_SIZE (101026,"Max File size limit ('%s')",HttpStatus.BAD_REQUEST),
    VERSION_IS_NOT_ALLOW (101031, "This version is not allowed.", HttpStatus.BAD_REQUEST),
    TOKEN_EXPIRED(102001, "Token is expired", HttpStatus.UNAUTHORIZED),
    UNAUTHORIZED(102002, "Unauthorized", HttpStatus.UNAUTHORIZED),


    AUTHORIZATION_NOT_FOUND(30001, "Authorization [%s] does not exist", HttpStatus.BAD_REQUEST),
    AUTHORIZATION_REQ_NOT_FOUND(30002, "Authorization Request does not exist", HttpStatus.BAD_REQUEST),
    CAN_NOT_REQUEST_AUTH(30004, "Cannot request to add authorization", HttpStatus.BAD_REQUEST),
    USER_NOT_EXISTS     (10001, "UserId '%s' does not exist", HttpStatus.BAD_REQUEST),
    EMPLOYEE_NUMBER_ALREADY_EXIST(10002, "Employee number '%s' already exists", HttpStatus.BAD_REQUEST),

    //Service
    APPLICATION_NOT_FOUND(60001, "Application [%s] does not exist", HttpStatus.BAD_REQUEST),
    APPLICATION_UNIQ_PATH_EXIST(60002, "Application uniqPath '%s' already exist", HttpStatus.BAD_REQUEST),

    //Page
    PAGE_NOT_FOUND(70001, "Page '%s' does not exist", HttpStatus.BAD_REQUEST),
    PAGE_URL_EXIST(70002, "Page url '%s' already exist in service", HttpStatus.BAD_REQUEST),
    PAGE_URL_EXIST_NO_PARAM(70002, "Page url already exist in service", HttpStatus.BAD_REQUEST),
    MASTER_PAGE_NOT_FOUND(70003, "Master Page [%s] does not exist", HttpStatus.BAD_REQUEST),

    //API
    API_NOT_FOUND(80001, "Api [%s] does not exist", HttpStatus.BAD_REQUEST),

    //FILE
    FILE_NOT_FOUND(900001, "File %s does not exist", HttpStatus.NOT_FOUND),
    // Server Error
    INTERNAL_SERVER_ERROR   (101500, "Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR),
    INTERNAL_DATABASE_ERROR (101501, "Internal Database Error", HttpStatus.INTERNAL_SERVER_ERROR),
    REFERENCE_SERVER_ERROR  (101502, "Reference Server Error", HttpStatus.SERVICE_UNAVAILABLE),
    S3_UPLOAD_ERROR (101503, "Internal Database Error", HttpStatus.INTERNAL_SERVER_ERROR),

    //DataStore
    DATA_STORE_KEY_EXIST(80001, "DataStore Key Exist", HttpStatus.BAD_REQUEST),
    DATA_STORE_NOT_EXIST(80002, "DataStore [%s] does not exist", HttpStatus.BAD_REQUEST);

    private final int resultCode;
    private final HttpStatus httpStatus;
    private final String resultMessage;

    public int getResultCode() {
        return resultCode;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    RCode(int errorCode, String errorMessage, HttpStatus status) {
        this.resultCode = errorCode;
        this.resultMessage = errorMessage;
        this.httpStatus = status;
    }
}