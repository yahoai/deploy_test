package com.skhynix.builder.dto.user;

import com.skhynix.builder.document.ProtoTypeUser;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JoinProtoTypeUserRespDTO {
    @ApiModelProperty(readOnly = true)
    private String id;
    private String employeeNumber;
    private String name;
    private String organization;
    @ApiModelProperty(readOnly = true)
    private Boolean isActiveUser;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    private String token;

    public static JoinProtoTypeUserRespDTO of(ProtoTypeUser u, String token) {

        return JoinProtoTypeUserRespDTO.builder()
                .id(u.getId())
                .employeeNumber(u.getUserUniqId())
                .name(u.getName())
                .organization(u.getOrganization())
                .isActiveUser(u.getIsActiveUser() == null || u.getIsActiveUser())
                .createdAt(u.getCreatedAt())
                .token(token)
                .build();
    }
}
