package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.Page;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface PageRepository extends MongoRepository<Page, String> {
    List<Page> findByApplicationId(ObjectId applicationId);
    Page findByApplicationIdAndPageUrl(ObjectId applicationId, String pageUrl);
}
