package com.skhynix.builder.service;

import com.skhynix.builder.document.Application;
import com.skhynix.builder.document.Component;
import com.skhynix.builder.dto.component.ComponentDTO;
import com.skhynix.builder.dto.component.ComponentPatchDTO;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.query.ComponentQueryService;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.repository.mongo.ComponentRepository;
import com.skhynix.builder.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ComponentService {
    private ComponentRepository componentRepository;
    private ComponentQueryService componentQueryService;

    @Autowired
    public void setComponentRepository(ComponentRepository componentRepository) {
        this.componentRepository = componentRepository;
    }

    @Autowired
    public void setComponentQueryService(ComponentQueryService componentQueryService) {
        this.componentQueryService = componentQueryService;
    }


    public ComponentDTO patchComponent(String componentId, ComponentPatchDTO dto) {
        Component component = componentRepository
                .findById(componentId).orElse(null);

        if(component == null) {
            return new ComponentDTO();
        }

        CommonUtil.changeIfPresent(dto.getTitle(), component::setTitle);
        CommonUtil.changeIfPresent(dto.getDescription(), component::setDescription);
        CommonUtil.changeIfPresent(dto.getTags(), component::setTags);
        CommonUtil.changeIfPresent(dto.getComponentName(), component::setComponentName);
        CommonUtil.changeIfPresent(dto.getComponentData(), component::setComponentData);
        CommonUtil.changeIfPresent(dto.getComponentType(), component::setComponentType);
        CommonUtil.changeIfPresent(dto.getComponentConditionAction(), component::setComponentConditionAction);
        CommonUtil.changeIfPresent(dto.getComponentEvent(), component::setComponentEvent);
        CommonUtil.changeIfPresent(dto.getBuilderLayouts(), component::setBuilderLayouts);
        CommonUtil.changeIfPresent(dto.getChildLayoutsList(), component::setChildLayoutsList);
        CommonUtil.changeIfPresent(dto.getComponentInfo(), component::setComponentInfoFromDto);
        CommonUtil.changeIfPresent(dto.getOptions(), component::setOptions);

        componentRepository.save(component);
        return ComponentDTO.of(component);
    }

    public ComponentDTO replaceComponent(String componentId, ComponentDTO dto) {
        Component component = Component.of(dto);
        return ComponentDTO.of(componentQueryService.replaceComponent(componentId, component));
    }
}
