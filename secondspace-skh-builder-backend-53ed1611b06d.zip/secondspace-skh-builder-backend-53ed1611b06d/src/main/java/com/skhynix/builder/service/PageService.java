package com.skhynix.builder.service;

import com.skhynix.builder.auth.UserPrincipal;
import com.skhynix.builder.document.*;
import com.skhynix.builder.document.embedded.PageApi;
import com.skhynix.builder.dto.page.*;
import com.skhynix.builder.exception.BuilderException;
import com.skhynix.builder.exception.RCode;
import com.skhynix.builder.query.AuthorizationQueryService;
import com.skhynix.builder.query.PageQueryService;
import com.skhynix.builder.repository.ApiRepository;
import com.skhynix.builder.repository.mongo.AuthorizationRepository;
import com.skhynix.builder.repository.mongo.PageRepository;
import com.skhynix.builder.repository.mongo.ApplicationRepository;
import com.skhynix.builder.repository.mongo.ProductionPageRepository;
import com.skhynix.builder.util.CommonUtil;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class PageService {
    private PageRepository pageRepository;
    private PageQueryService pageQueryService;
    private ApplicationRepository applicationRepository;
    private AuthorizationQueryService authorizationQueryService;
    private ProductionPageRepository productionPageRepository;
    private AuthorizationRepository authorizationRepository;
    private ApiRepository apiRepository;
    private PermissionCheckService permissionCheckService;
    private PageResponseService pageResponseService;

    @Autowired
    public void setPageResponseService(PageResponseService pageResponseService) {
        this.pageResponseService = pageResponseService;
    }

    @Autowired
    public void setProductionPageRepository(ProductionPageRepository productionPageRepository) {
        this.productionPageRepository = productionPageRepository;
    }

    @Autowired
    public void setPermissionCheckService(PermissionCheckService permissionCheckService) {
        this.permissionCheckService = permissionCheckService;
    }
    @Autowired
    public void setApiRepository(ApiRepository apiRepository) {
        this.apiRepository = apiRepository;
    }

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Autowired
    public void setAuthorizationQueryService(AuthorizationQueryService authorizationQueryService) {
        this.authorizationQueryService = authorizationQueryService;
    }

    @Autowired
    public void setPageQueryService(PageQueryService pageQueryService) {
        this.pageQueryService = pageQueryService;
    }

    @Autowired
    public void setApplicationRepository(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    @Autowired
    public void setPageRepository(PageRepository pageRepository) {
        this.pageRepository = pageRepository;
    }


    public PageRespDTO createPage(PageDTO pageDTO) throws BuilderException {
        try {
            Application application =  applicationRepository.findById(pageDTO.getApplicationId())
                        .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND,
                                pageDTO.getApplicationId()));

            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            Page page = Page.of(pageDTO, application);
            Long currentTime = System.currentTimeMillis();
            page.setUpdatedAt(currentTime);
            page.setCreatedAt(currentTime);
            pageRepository.save(page);

            return pageResponseService.getPageRespDTO(page);
        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.PAGE_URL_EXIST, pageDTO.getPageUrl(), e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }



    public List<PageRespDTO> getPages(String applicationId,
                                      String title,
                                      String applicationTitle,
                                      String applicationUniqPath,
                                      String pageUrl,
                                      String componentId) throws BuilderException {
        try {
            List<Page> pageList =  pageQueryService.getPages(applicationId, title, applicationTitle, applicationUniqPath, pageUrl, componentId);
            List<String> authId = pageList.stream().flatMap(p -> {
                Set<ObjectId> idSet = new HashSet<>();
                if(p.getAuthorizations() != null && p.getAuthorizations().getAllow() != null)
                    idSet.addAll(p.getAuthorizations().getAllow());
                if(p.getAuthorizations() != null && p.getAuthorizations().getDeny() != null)
                    idSet.addAll(p.getAuthorizations().getDeny());

                return idSet.stream().map(ObjectId::toString).collect(Collectors.toSet()).stream();
            }).distinct().collect(Collectors.toList());


            Map<String, Authorization> authMap = authorizationRepository.findAllByIdIn(authId)
                    .stream().collect(Collectors.toMap(Authorization::getId, Function.identity()));


            return pageList.stream().map(p -> {
                if(p.getApiList() == null || p.getApiList().size() == 0) {
                    return PageRespDTO.of(p, authMap, null);
                } else {
                    List<PageApiRespDTO> apiList = p.getApiList().stream().map(api -> {
                        Api apiData = apiRepository.findById(api.getApiId().toString()).orElse(null);
                        if(apiData == null)
                            return null;
                        return PageApiRespDTO.of(apiData, api.getData());
                    }).filter(Objects::nonNull).collect(Collectors.toList());
                    return PageRespDTO.of(p, authMap, apiList);
                }
            }).collect(Collectors.toList());

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public PageRespDTO getPage(String pageId) throws BuilderException {
        try {
            Page page =pageRepository.findById(pageId)
                    .orElseThrow(() -> new BuilderException(RCode.PAGE_NOT_FOUND, pageId));

            return pageResponseService.getPageRespDTO(page);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }

    }

    public void deletePage(String pageId) throws BuilderException {
        try {
            Page page = pageRepository.findById(pageId)
                    .orElseThrow(() -> new BuilderException(RCode.PAGE_NOT_FOUND, pageId));

            Application application =  applicationRepository.findById(page.getApplicationId().toString())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND,
                            page.getApplicationId().toString()));
            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            pageRepository.delete(page);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public PageRespDTO patchPage(String pageId,
                            PagePatchDTO dto) throws BuilderException {
        try {
            Page p = pageRepository.findById(pageId)
                    .orElseThrow(() -> new BuilderException(RCode.PAGE_NOT_FOUND, pageId));

            CommonUtil.changeIfPresent(dto.getTitle(), p::setTitle);
            CommonUtil.changeIfPresent(dto.getDescription(), p::setDescription);
            CommonUtil.changeIfPresent(dto.getComponentData(), p::setComponentData);
            CommonUtil.changeIfPresent(dto.getComponentConditionAction(), p::setComponentConditionAction);
            CommonUtil.changeIfPresent(dto.getComponentEvent(), p::setComponentEvent);
            CommonUtil.changeIfPresent(dto.getBuilderLayouts(), p::setBuilderLayouts);
            CommonUtil.changeIfPresent(dto.getChildLayoutsList(), p::setChildLayoutsList);

            if(dto.getApplicationId() != null && dto.getApplicationId().isPresent()) {
                String beforeId = p.getApplicationId() != null
                        ? p.getApplicationId().toString() : null;

                String willBeUpdatedId = dto.getApplicationId().get();
                if(beforeId == null) {
                    if(willBeUpdatedId != null) {
                        Application a = applicationRepository.findById(willBeUpdatedId)
                                .orElseThrow(
                                        () -> new BuilderException(RCode.APPLICATION_NOT_FOUND, willBeUpdatedId)
                                );
                        p.setApplicationId(new ObjectId(willBeUpdatedId));
                        p.setApplicationTitle(a.getTitle());
                        p.setApplicationUniqPath(a.getUniqPath());
                    }
                } else {
                    if(willBeUpdatedId == null) {
                        p.setApplicationId(null);
                        p.setApplicationTitle(null);
                        p.setApplicationUniqPath(null);
                    } else {
                        if(!beforeId.equals(willBeUpdatedId)) {
                            Application a = applicationRepository.findById(willBeUpdatedId)
                                    .orElseThrow(
                                            () -> new BuilderException(RCode.APPLICATION_NOT_FOUND, willBeUpdatedId)
                                    );
                            p.setApplicationId(new ObjectId(willBeUpdatedId));
                            p.setApplicationTitle(a.getTitle());
                            p.setApplicationUniqPath(a.getUniqPath());
                        }
                    }
                }
            }
            CommonUtil.changeIfPresent(dto.getPageUrl(), p::setPageUrl);
            CommonUtil.changeIfPresent(dto.getComponentInfo(), p::updateComponentInfo);
            CommonUtil.changeIfPresent(dto.getPageParam(), p::setPageParam);
            CommonUtil.changeIfPresent(dto.getAllowAnyUser(), p::setAllowAnyUser);
            CommonUtil.changeIfPresent(dto.getOptions(), p::setOptions);
            CommonUtil.changeIfPresent(dto.getMasterPage(), p::setMasterPageByStringId);
            CommonUtil.changeIfPresent(dto.getAuthorizations(), p::setAuthorizationsByAuthorizationDTO);
            CommonUtil.changeIfPresent(dto.getFrontData(), p::setFrontData);

            if(dto.getApiList() != null && dto.getApiList().isPresent()) {
                List<PageApi> api = dto.getApiList().get().stream()
                        .map(apiDto -> new PageApi(new ObjectId(apiDto.getApiId()), apiDto.getData()))
                        .collect(Collectors.toList());
                p.setApiList(api);
            }


            Application application =  applicationRepository.findById(p.getApplicationId().toString())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND,
                            p.getApplicationId().toString()));
            application.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(application);

            Page newPage = pageRepository.save(p);

            List<String> authId = new ArrayList<>();

            if(p.getAuthorizations() != null) {
                if(p.getAuthorizations().getAllow() != null) {
                    authId.addAll(p.getAuthorizations().getAllow()
                            .stream().map(ObjectId::toString).collect(Collectors.toList()));
                }
                if(p.getAuthorizations().getDeny() != null) {
                    authId.addAll(p.getAuthorizations().getDeny()
                            .stream().map(ObjectId::toString).collect(Collectors.toList()));
                }

            }

            Map<String, Authorization> authMap = new HashMap<>();
            if(authId.size() != 0) {
                authMap = authorizationRepository.findAllByIdIn(authId)
                        .stream().collect(Collectors.toMap(Authorization::getId, Function.identity()));
            }

            List<PageApiRespDTO> apiList = null;

            if(newPage.getApiList() != null && newPage.getApiList().size() != 0) {
                apiList = newPage.getApiList().stream().map(api -> {
                    Api apiData = apiRepository.findById(api.getApiId().toString()).orElse(null);
                    if(apiData == null) {
                        return null;
                    }
                    return PageApiRespDTO.of(apiData, api.getData());
                }).filter(Objects::nonNull).collect(Collectors.toList());
            }

            return PageRespDTO.of(newPage, authMap, apiList);
        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.PAGE_URL_EXIST_NO_PARAM, e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public PageRespDTO replacePage(String pageId, PageDTO pageDTO) throws BuilderException {
        try {
            Page p = pageRepository.findById(pageId)
                    .orElseThrow(() -> new BuilderException(RCode.PAGE_NOT_FOUND, pageId));

            Application a = applicationRepository.findById(pageDTO.getApplicationId())
                    .orElseThrow(() -> new BuilderException(RCode.APPLICATION_NOT_FOUND, pageDTO.getApplicationId()));

            a.setUpdatedAt(System.currentTimeMillis());
            applicationRepository.save(a);

            Long curr = System.currentTimeMillis();
            Page newPage = Page.of(pageDTO, a);
            newPage.setUpdatedAt(curr);
            newPage = pageQueryService.replacePage(pageId, newPage);


            return pageResponseService.getPageRespDTO(newPage);
        } catch (BuilderException e) {
            throw e;
        } catch (DuplicateKeyException e) {
            throw new BuilderException(RCode.PAGE_URL_EXIST_NO_PARAM, e);
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    public void publishPage(String applicationId) throws BuilderException {
        try {
            pageQueryService.replaceAllPage(applicationId);
        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }
    }

    private PageCheckRespDTO pageCheck4Dev(UserPrincipal currentUser,
                                           String applicationUniqPath,
                                           String pageUrl) throws BuilderException {
        try {
            Application app = applicationRepository.findByUniqPath(applicationUniqPath);
            if(app == null) {
                throw new BuilderException(RCode.PAGE_NOT_FOUND, applicationUniqPath+"/"+pageUrl);
            }

            String appId = app.getId();

            Page page = pageRepository.findByApplicationIdAndPageUrl(new ObjectId(appId), pageUrl);

            if(page == null) {
                throw new BuilderException(RCode.PAGE_NOT_FOUND, applicationUniqPath+"/"+pageUrl);
            }

            if(page.getAllowAnyUser() != null && page.getAllowAnyUser()) {
                MasterPage masterPage = null;
                if(page.getMasterPage() != null) {
                    masterPage = app.getMasterPage();
                }
                List<PageApiRespDTO> apiList = null;

                if(page.getApiList() != null && page.getApiList().size() != 0) {
                    apiList = page.getApiList().stream().map(api -> {
                        Api apiData = apiRepository.findById(api.getApiId().toString()).orElse(null);
                        if(apiData == null) {
                            return null;
                        }
                        return PageApiRespDTO.of(apiData, api.getData());
                    }).filter(Objects::nonNull).collect(Collectors.toList());
                }

                return PageCheckRespDTO.of(page, masterPage, apiList);
            }

            if(currentUser == null) {
                throw new BuilderException(RCode.UNAUTHORIZED);
            }

            if (!permissionCheckService.isPermitted4Dev(currentUser.getId(), page))
                throw new BuilderException(RCode.UNAUTHORIZED);

            MasterPage masterPage = null;
            if(page.getMasterPage() != null) {
                masterPage = app.getMasterPage();
            }

            List<PageApiRespDTO> apiList = null;

            if(page.getApiList() != null && page.getApiList().size() != 0) {
                apiList = page.getApiList().stream().map(api -> {
                    Api apiData = apiRepository.findById(api.getApiId().toString()).orElse(null);
                    if(apiData == null) {
                        return null;
                    }
                    return PageApiRespDTO.of(apiData, api.getData());
                }).filter(Objects::nonNull).collect(Collectors.toList());
            }

            return PageCheckRespDTO.of(page, masterPage, apiList);

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }

    }

    private PageCheckRespDTO pageCheck4Production(UserPrincipal currentUser,
                                           String applicationUniqPath,
                                           String pageUrl) throws BuilderException {
        try {
            Application app = applicationRepository.findByUniqPath(applicationUniqPath);
            if(app == null) {
                throw new BuilderException(RCode.PAGE_NOT_FOUND, applicationUniqPath+"/"+pageUrl);
            }

            String appId = app.getId();

            ProductionPage page = productionPageRepository.findByApplicationIdAndPageUrl(new ObjectId(appId), pageUrl);

            if(page == null) {
                throw new BuilderException(RCode.PAGE_NOT_FOUND, applicationUniqPath+"/"+pageUrl);
            }

            if(page.getAllowAnyUser() != null && page.getAllowAnyUser()) {
                MasterPage masterPage = null;
                if(page.getMasterPage() != null) {
                    masterPage = app.getMasterPage();
                }
                List<PageApiRespDTO> apiList = null;

                if(page.getApiList() != null && page.getApiList().size() != 0) {
                    apiList = page.getApiList().stream().map(api -> {
                        Api apiData = apiRepository.findById(api.getApiId().toString()).orElse(null);
                        if(apiData == null) {
                            return null;
                        }
                        return PageApiRespDTO.of(apiData, api.getData());
                    }).filter(Objects::nonNull).collect(Collectors.toList());
                }

                return PageCheckRespDTO.of(page, masterPage, apiList);
            }

            if(currentUser == null) {
                throw new BuilderException(RCode.UNAUTHORIZED);
            }

            if (!permissionCheckService.isPermitted4Prod(currentUser.getId(), page))
                throw new BuilderException(RCode.UNAUTHORIZED);

            MasterPage masterPage = null;
            if(page.getMasterPage() != null) {
                masterPage = app.getMasterPage();
            }
            List<PageApiRespDTO> apiList = null;

            if(page.getApiList() != null && page.getApiList().size() != 0) {
                apiList = page.getApiList().stream().map(api -> {
                    Api apiData = apiRepository.findById(api.getApiId().toString()).orElse(null);
                    if(apiData == null) {
                        return null;
                    }
                    return PageApiRespDTO.of(apiData, api.getData());
                }).filter(Objects::nonNull).collect(Collectors.toList());
            }

            return PageCheckRespDTO.of(page, masterPage, apiList);

        } catch (BuilderException e) {
            throw e;
        } catch (Exception e) {
            throw new BuilderException(RCode.INTERNAL_DATABASE_ERROR, e);
        }

    }

    public PageCheckRespDTO pageCheck(UserPrincipal currentUser,
                                      Integer target,
                                      String applicationUniqPath,
                                      String pageUrl) throws BuilderException {

       if (target != null && target == 1)
           return pageCheck4Dev(currentUser, applicationUniqPath, pageUrl);
       else
           return pageCheck4Production(currentUser, applicationUniqPath, pageUrl);
    }
}
