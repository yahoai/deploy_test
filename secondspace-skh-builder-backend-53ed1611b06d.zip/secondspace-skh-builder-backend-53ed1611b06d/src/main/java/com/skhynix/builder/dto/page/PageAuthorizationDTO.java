package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.embedded.PageAuthorization;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageAuthorizationDTO {
    private Set<String> allow;
    private Set<String> deny;

    public static PageAuthorizationDTO of(PageAuthorization pa) {
        if(pa == null)
            return null;
        return PageAuthorizationDTO.builder()
                .allow(pa.getAllow() != null ?
                        pa.getAllow().stream().map(ObjectId::toString).collect(Collectors.toSet()) : null)
                .deny(pa.getDeny() != null ?
                        pa.getDeny().stream().map(ObjectId::toString).collect(Collectors.toSet()) : null)
                .build();
    }
}
