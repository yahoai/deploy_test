package com.skhynix.builder.dto.page;

import com.skhynix.builder.document.MasterPage;
import com.skhynix.builder.document.embedded.Footer;
import com.skhynix.builder.document.embedded.Menu;
import com.skhynix.builder.dto.validator.DocumentId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MasterPageDTO {
    @NotNull
    @DocumentId
    private String applicationId;
    private Boolean isDefault;
    private String title;
    private String desc;
    private Boolean usePermission;
    private Object header;
    private Object design;
    private Footer footer;
    private Menu menu;
    private Object frontData;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    @ApiModelProperty(readOnly = true)
    private Long updatedAt;

    public static MasterPageDTO of(MasterPage mp, String applicationId) {
        return MasterPageDTO.builder()
                .applicationId(applicationId)
                .isDefault(mp.getIsDefault())
                .title(mp.getTitle())
                .header(mp.getHeader())
                .desc(mp.getDesc())
                .usePermission(mp.getUsePermission())
                .design(mp.getDesign())
                .footer(mp.getFooter())
                .menu(mp.getMenu())
                .frontData(mp.getFrontData())
                .createdAt(mp.getCreatedAt())
                .updatedAt(mp.getUpdatedAt())
                .build();
    }
}
