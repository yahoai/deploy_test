package com.skhynix.builder.document.embedded;

public enum ProtoTypeUserType {
    admin,
    manager,
    user,
}
