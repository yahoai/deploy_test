package com.skhynix.builder.document.embedded;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FooterLink {
    private String title;
    private Boolean externalLink;
    private String link;
}
