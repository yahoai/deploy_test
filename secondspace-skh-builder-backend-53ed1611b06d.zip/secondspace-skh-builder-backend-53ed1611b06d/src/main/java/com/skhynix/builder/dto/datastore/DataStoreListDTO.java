package com.skhynix.builder.dto.datastore;

import com.skhynix.builder.dto.validator.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DataStoreListDTO {
    @NotNull
    @DocumentId
    private String applicationId;
    @Valid
    private List<DataStoreDTO> dataStoreDTOList;

}
