package com.skhynix.builder.dto.datastore;

import com.skhynix.builder.document.DataStore;
import com.skhynix.builder.dto.validator.DocumentId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DataStoreDTO {
    @DocumentId
    String id;
    @DocumentId
    String applicationId;
    String keyName;
    String name;
    String className;
    String use;
    String fid;
    Boolean edit;

    public static DataStoreDTO of(DataStore ds) {
        return DataStoreDTO.builder()
                .id(ds.getId())
                .keyName(ds.getKeyName())
                .className(ds.getClassName())
                .use(ds.getUse())
                .edit(ds.getEdit())
                .applicationId(ds.getApplicationId().toString())
                .fid(ds.getFid())
                .name(ds.getName())
                .build();
    }
}
