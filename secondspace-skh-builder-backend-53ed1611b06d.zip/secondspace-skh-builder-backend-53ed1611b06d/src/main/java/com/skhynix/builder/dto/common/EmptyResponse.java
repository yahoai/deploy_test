package com.skhynix.builder.dto.common;

import com.skhynix.builder.exception.RCode;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class EmptyResponse extends BaseResponse {
    Map<String, Object> data;

    public static EmptyResponse create() {
        EmptyResponse response = new EmptyResponse();
        response.errorCode = RCode.OK.getResultCode();
        response.errorMessage = RCode.OK.getResultMessage();

        response.data = new HashMap<>();

        return response;

    }
}
