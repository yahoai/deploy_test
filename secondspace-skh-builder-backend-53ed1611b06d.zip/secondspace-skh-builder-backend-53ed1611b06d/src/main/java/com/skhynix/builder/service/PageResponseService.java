package com.skhynix.builder.service;

import com.skhynix.builder.document.Api;
import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.Page;
import com.skhynix.builder.dto.page.PageApiRespDTO;
import com.skhynix.builder.dto.page.PageRespDTO;
import com.skhynix.builder.repository.ApiRepository;
import com.skhynix.builder.repository.mongo.AuthorizationRepository;
import com.skhynix.builder.repository.mongo.PageRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class PageResponseService {
    private AuthorizationRepository authorizationRepository;
    private ApiRepository apiRepository;

    @Autowired
    public void setAuthorizationRepository(AuthorizationRepository authorizationRepository) {
        this.authorizationRepository = authorizationRepository;
    }

    @Autowired
    public void setApiRepository(ApiRepository apiRepository) {
        this.apiRepository = apiRepository;
    }

    public PageRespDTO getPageRespDTO(Page page) {
        List<String> authId = new ArrayList<>();

        if(page.getAuthorizations() != null) {
            if(page.getAuthorizations().getAllow() != null) {
                authId.addAll(page.getAuthorizations().getAllow()
                        .stream().map(ObjectId::toString).collect(Collectors.toList()));
            }
            if(page.getAuthorizations().getDeny() != null) {
                authId.addAll(page.getAuthorizations().getDeny()
                        .stream().map(ObjectId::toString).collect(Collectors.toList()));
            }

        }


        Map<String, Authorization> authMap = new HashMap<>();
        if(authId.size() != 0) {
            authMap = authorizationRepository.findAllByIdIn(authId)
                    .stream().collect(Collectors.toMap(Authorization::getId, Function.identity()));
        }

        List<PageApiRespDTO> apiList = null;

        if(page.getApiList() != null && page.getApiList().size() != 0) {
            apiList = page.getApiList().stream().map(api -> {
                Api apiData = apiRepository.findById(api.getApiId().toString()).orElse(null);
                if(apiData == null) {
                    return null;
                }
                return PageApiRespDTO.of(apiData, api.getData());
            }).filter(Objects::nonNull).collect(Collectors.toList());
        }

        return PageRespDTO.of(page, authMap, apiList);
    }
}
