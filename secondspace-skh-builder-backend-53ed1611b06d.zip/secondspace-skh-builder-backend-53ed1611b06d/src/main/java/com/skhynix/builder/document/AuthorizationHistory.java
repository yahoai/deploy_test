package com.skhynix.builder.document;

import com.skhynix.builder.document.embedded.AuthUpdateActionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import java.util.List;

@Document("authorization_history")
@Data
@CompoundIndex(
        def = "{applicationId:-1, updatedAt:-1}", unique = true
)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AuthorizationHistory {
    @Id
    private String id;
    @Indexed
    private ObjectId applicationId;
    private ObjectId applicationUserId;
    private AuthUpdateActionType actionType;
    private List<String> previousAuthNameList;
    private List<String> newAuthNameList;
    private String requestAuthorizationName;
    private String acceptAuthorizationName;
    private String denyAuthorizationName;
    private Long updatedAt;
}
