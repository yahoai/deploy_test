package com.skhynix.builder.logger;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class InfoLogger {
    public static void log_info(String msg, Object ... vars) {
        log.info(msg, vars);
    }

    public static void log_debug(String msg, Object ... vars) {
        log.debug(msg, vars);
    }

    public static void log_error(String msg, Object ... vars) {
        log.error(msg, vars);
    }
}
