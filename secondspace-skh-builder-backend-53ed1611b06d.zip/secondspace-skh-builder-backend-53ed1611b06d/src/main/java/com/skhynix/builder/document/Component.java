package com.skhynix.builder.document;

import com.skhynix.builder.document.embedded.ComponentInfo;
import com.skhynix.builder.dto.component.ComponentDTO;
import com.skhynix.builder.dto.component.ComponentInfoDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import java.util.List;

@Document("component")
@Data
@CompoundIndex(def = "{'componentInfo.i': 1}")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Component {
    @Id
    private String id;
    @Indexed
    private String title;
    private String description;
    @Indexed
    private List<String> tags;
    @Indexed
    private String componentName;
    private Object componentData;
    @Indexed
    private Integer componentType;
    private ObjectId ownerId;
    private Object componentConditionAction;
    private Object componentEvent;
    private Object builderLayouts;
    private Object childLayoutsList;
    private ComponentInfo componentInfo;
    private Object options;
    private Long createdAt;
    private Long updatedAt;

    public void setComponentInfoFromDto(ComponentInfoDTO dto) {
        ComponentInfo info = new ComponentInfo();
        info.setI(dto.getI());
        info.setId(dto.getId() != null ? new ObjectId(dto.getId()) : null);
        this.componentInfo = info;
    }

    public static Component of(ComponentDTO c) {
        ComponentInfo componentInfo = new ComponentInfo();

        if(c.getComponentInfo() != null) {
            componentInfo.setI(c.getComponentInfo().getI());
            componentInfo.setId(c.getComponentInfo().getId() != null ?
                    new ObjectId(c.getComponentInfo().getId()) : null);
        }

        return Component.builder()
                .title(c.getTitle())
                .description(c.getDescription())
                .tags(c.getTags())
                .componentName(c.getComponentName())
                .componentData(c.getComponentData())
                .componentType(c.getComponentType())
                .componentConditionAction(c.getComponentConditionAction())
                .componentEvent(c.getComponentEvent())
                .builderLayouts(c.getBuilderLayouts())
                .childLayoutsList(c.getChildLayoutsList())
                .componentInfo(componentInfo)
                .options(c.getOptions())
                .createdAt(c.getCreatedAt())
                .build();
    }
}
