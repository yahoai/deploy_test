package com.skhynix.builder.dto.api;

import com.skhynix.builder.dto.validator.DocumentId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateApiListDTO {
    @NotNull
    @DocumentId
    private String applicationId;
    private List<@Valid ApiDTO> apiList;
}
