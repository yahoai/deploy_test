package com.skhynix.builder.document.embedded;

import com.skhynix.builder.dto.component.ComponentInfoDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComponentInfo {
    private String i;
    private ObjectId id;

    public static ComponentInfo of(ComponentInfoDTO dto) {
        return ComponentInfo.builder()
                .i(dto.getI())
                .id(dto.getId() == null ? null : new ObjectId(dto.getId()))
                .build();
    }
}
