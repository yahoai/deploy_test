package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.Authorization;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Set;

public interface AuthorizationRepository extends MongoRepository<Authorization, String> {
    List<Authorization> findAll();
    List<Authorization> findAllByApplicationId(ObjectId applicationId);
    List<Authorization> findAllByIdIn(List<String> idList);
}
