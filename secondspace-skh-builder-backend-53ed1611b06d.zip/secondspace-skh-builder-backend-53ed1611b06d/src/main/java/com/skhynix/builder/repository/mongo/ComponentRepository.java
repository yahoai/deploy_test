package com.skhynix.builder.repository.mongo;

import com.skhynix.builder.document.Component;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface ComponentRepository extends MongoRepository<Component, String> {
    Optional<Component> findById(String id);
    List<Component> findByComponentType(int componentType);
}
