package com.skhynix.builder.dto.user;

import com.skhynix.builder.document.Authorization;
import com.skhynix.builder.document.User;
import com.skhynix.builder.dto.authorization.AuthorizationDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class JoinUserRespDTO {
    private String id;
    private String applicationId;
    private String employeeNumber;
    private String name;
    private List<AuthorizationDTO> authorizations;
    private Long lastAuthorizationUpdatedAt;
    private String token;
    @ApiModelProperty(readOnly = true)
    private Long createdAt;
    @ApiModelProperty(readOnly = true)
    private Long updatedAt;


    public static JoinUserRespDTO of(User u, List<Authorization> authorizations, String token) {
        return JoinUserRespDTO.builder()
                .id(u.getId())
                .applicationId(u.getApplicationId().toString())
                .employeeNumber(u.getUserUniqId())
                .name(u.getName())
                .authorizations(authorizations != null ?
                        authorizations.stream().map(AuthorizationDTO::of).collect(Collectors.toList()) : null)
                .token(token)
                .lastAuthorizationUpdatedAt(u.getLastAuthorizationUpdatedAt())
                .createdAt(u.getCreatedAt())
                .updatedAt(u.getUpdatedAt() != null ? u.getUpdatedAt() : u.getCreatedAt())
                .build();
    }
}
