package com.skhynix.builder.document;

import com.skhynix.builder.dto.datastore.DataStoreDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;

@Document("datastore")
@Data
@CompoundIndex(def = "{'applicationId':1, 'keyName':1}", unique = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataStore {
    @Id
    private String id;
    private ObjectId applicationId;
    private String keyName;
    private String name;
    private String className;
    private String use;
    private String fid;
    private Boolean edit;

    public static DataStore of(String appId, DataStoreDTO dto) {
        return DataStore.builder()
                .applicationId(new ObjectId(appId))
                .keyName(dto.getKeyName())
                .name(dto.getName())
                .className(dto.getClassName())
                .use(dto.getUse())
                .edit(dto.getEdit())
                .fid(dto.getFid())
                .build();
    }
}
